import React, { useState } from 'react';
import axios from 'axios';
import { Copy, Check, Key, UserCheck, Activity, EyeOff, ChevronDown, ChevronUp } from 'lucide-react';
import { API_BASE_URL } from '../../config';
import { NetworkBackground } from '../NetworkBackground/NetworkBackground';
import { useLanguage } from '../../i18n/LanguageContext';
import { usePrivacy } from '../../context/PrivacyContext';
import './Settings.css';

interface SettingsProps {
  userId: number;
  gateKey: string;
}

export const Settings: React.FC<SettingsProps> = ({ userId, gateKey }) => {
  const { t } = useLanguage();
  const { privacyMode, togglePrivacyMode } = usePrivacy();
  const [newUsername, setNewUsername] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [isAccountExpanded, setIsAccountExpanded] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [networkAnimEnabled, setNetworkAnimEnabled] = useState<boolean>(() => {
    return localStorage.getItem('show_network_bg') !== 'false';
  });

  const triggerToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2000);
  };

  const handleToggleNetworkAnim = () => {
    const nextState = !networkAnimEnabled;
    setNetworkAnimEnabled(nextState);
    localStorage.setItem('show_network_bg', nextState ? 'true' : 'false');
    window.dispatchEvent(new Event('network_bg_toggle'));
    triggerToast(nextState ? 'Ağ animasyonu açıldı' : 'Ağ animasyonu kapatıldı');
  };

  const handleTogglePrivacy = () => {
    togglePrivacyMode();
    triggerToast(!privacyMode ? t('settings.privacy_enabled_toast') : t('settings.privacy_disabled_toast'));
  };

  const handleCopy = () => {
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(gateKey);
    } else {
      const textArea = document.createElement('textarea');
      textArea.value = gateKey;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      try {
        document.execCommand('copy');
      } catch (err) {
        console.error('Kopyalama hatası:', err);
      }
      document.body.removeChild(textArea);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    triggerToast('Gate Key panoya kopyalandı!');
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const res = await axios.post(
        `${API_BASE_URL}/api/auth/change-password`,
        { userId, currentPassword, newUsername, newPassword },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (res.data.success) {
        triggerToast('Bilgileriniz güncellendi! Yeniden giriş yapılıyor...');
        setNewUsername('');
        setCurrentPassword('');
        setNewPassword('');
        setTimeout(() => {
          localStorage.removeItem('token');
          window.location.reload();
        }, 1500);
      }
    } catch (err: any) {
      triggerToast(err.response?.data?.message || 'Hata oluştu.');
    }
  };

  return (
    <div className="settings-section">
      <NetworkBackground />

      <div className="settings-unified-card">
        {/* GATE KEY BÖLÜMÜ */}
        <div className="settings-row">
          <div className="settings-row-label">
            <Key size={16} color="#ffffff" />
            <span>Gate Key</span>
          </div>
          <div className="gatekey-display">
            <span className={privacyMode ? 'privacy-blur' : ''}>{gateKey}</span>
            <button onClick={handleCopy} title="Kopyala" className="trash-btn" style={{ padding: '0.3rem 0.5rem' }}>
              {copied ? <Check size={14} color="#22c55e" /> : <Copy size={14} />}
            </button>
          </div>
        </div>

        <div className="settings-divider" />

        {/* GİZLİ MOD (PRIVACY / STEALTH MODE) */}
        <div className="settings-row">
          <div className="settings-row-label">
            <EyeOff size={16} color="#ffffff" />
            <span>{t('settings.privacy_mode')}</span>
          </div>
          <div
            className={`toggle-switch ${privacyMode ? 'active' : ''}`}
            onClick={handleTogglePrivacy}
            title={t('settings.privacy_mode')}
          >
            <div className="toggle-switch-handle" />
          </div>
        </div>

        <div className="settings-divider" />

        {/* AĞ ANİMASYONU BÖLÜMÜ */}
        <div className="settings-row">
          <div className="settings-row-label">
            <Activity size={16} color="#ffffff" />
            <span>{t('settings.network_anim')}</span>
          </div>
          <div
            className={`toggle-switch ${networkAnimEnabled ? 'active' : ''}`}
            onClick={handleToggleNetworkAnim}
            title={networkAnimEnabled ? "Ağ Animasyonunu Kapat" : "Ağ Animasyonunu Aç"}
          >
            <div className="toggle-switch-handle" />
          </div>
        </div>

        <div className="settings-divider" />

        {/* HESAP / ŞİFRE DEĞİŞTİRME ACCORDION BÖLÜMÜ */}
        <div className="settings-accordion-wrapper">
          <div
            className="settings-accordion-header"
            onClick={() => setIsAccountExpanded(prev => !prev)}
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              cursor: 'pointer',
              userSelect: 'none'
            }}
          >
            <div className="settings-row-label">
              <UserCheck size={16} color="#ffffff" />
              <span>{t('settings.account_settings')}</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', color: '#a1a1aa' }}>
              {isAccountExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
            </div>
          </div>

          {isAccountExpanded && (
            <form onSubmit={handleChangePassword} style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginTop: '1.25rem' }}>
              <div className="settings-form-group">
                <label>{t('settings.new_username')}</label>
                <input type="text" className="settings-form-control" value={newUsername} onChange={(e) => setNewUsername(e.target.value)} placeholder={t('settings.new_username_placeholder')} />
              </div>
              <div className="settings-form-group">
                <label>{t('settings.current_password')}</label>
                <input type="password" className="settings-form-control" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} placeholder={t('settings.current_password_placeholder')} required />
              </div>
              <div className="settings-form-group">
                <label>{t('settings.new_password')}</label>
                <input type="password" className="settings-form-control" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder={t('settings.new_password_placeholder')} />
              </div>
              <button type="submit" className="settings-btn">{t('settings.update_btn')}</button>
            </form>
          )}
        </div>
      </div>

      {/* FLOATING SAĞ ALT BİLDİRİM TOAST */}
      {toastMsg && (
        <div className="bottom-right-toast">
          <Check size={18} color="#22c55e" />
          <span>{toastMsg}</span>
        </div>
      )}
    </div>
  );
};
