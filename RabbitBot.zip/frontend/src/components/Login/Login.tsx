import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Login.css';
import { API_BASE_URL } from '../../config';
import logoImg from '../../assets/logo.png';
import { useLanguage, LANGUAGES } from '../../i18n/LanguageContext';

interface UserData {
  id: number;
  username: string;
  role: string;
  gateKey: string;
}

interface LoginProps {
  onLoginSuccess: (user: UserData, token: string) => void;
}

export const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const { language, setLanguage, t } = useLanguage();
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [username, setUsername] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  const currentLangObj = LANGUAGES.find(l => l.code === language) || LANGUAGES[0];

  useEffect(() => {
    const closeDropdown = () => setLangMenuOpen(false);
    if (langMenuOpen) {
      window.addEventListener('click', closeDropdown);
    }
    return () => window.removeEventListener('click', closeDropdown);
  }, [langMenuOpen]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await axios.post(`${API_BASE_URL}/api/auth/login`, {
        username,
        password
      });

      if (response.data.success) {
        onLoginSuccess(response.data.user, response.data.token);
      }
    } catch (err: any) {
      if (err.response && err.response.data && err.response.data.message) {
        setError(err.response.data.message);
      } else {
        setError(t('login.error_server'));
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fullscreen-login-layout">
      {/* SAĞ ÜST DİL SEÇİM MENÜSÜ */}
      <div className="login-top-right-lang" onClick={(e) => e.stopPropagation()}>
        <button
          type="button"
          className="custom-lang-btn login-lang-btn"
          onClick={() => setLangMenuOpen(prev => !prev)}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <img src={currentLangObj.flag} alt={currentLangObj.name} className="lang-flag-img" />
            <span className="lang-name">{currentLangObj.name}</span>
          </div>
          <span className={`lang-arrow ${langMenuOpen ? 'open' : ''}`}>▾</span>
        </button>

        {langMenuOpen && (
          <div className="custom-lang-menu login-lang-menu">
            {LANGUAGES.map((l) => (
              <div
                key={l.code}
                className={`custom-lang-item ${language === l.code ? 'active' : ''}`}
                onClick={() => {
                  setLanguage(l.code);
                  setLangMenuOpen(false);
                }}
              >
                <img src={l.flag} alt={l.name} className="lang-flag-img" />
                <span className="lang-name">{l.name}</span>
                {language === l.code && <span className="lang-check">✓</span>}
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="login-left-panel">
        <div className="login-form-wrapper">
          {error && <div className="error-banner">{error}</div>}

          <form onSubmit={handleLogin}>
            <div className="form-group">
              <label htmlFor="username">{t('login.username')}</label>
              <input
                id="username"
                type="text"
                className="form-control"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                autoComplete="off"
              />
            </div>

            <div className="form-group">
              <label htmlFor="password">{t('login.password')}</label>
              <input
                id="password"
                type="password"
                className="form-control"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            <button type="submit" className="btn-primary" disabled={loading}>
              {loading ? t('login.logging_in') : t('login.submit')}
            </button>
          </form>
        </div>
      </div>

      <div className="login-right-panel">
        <div className="logo-box">
          <img src={logoImg} alt="Rabbit Bot Logo" className="login-right-logo" />
          <div className="login-credits-box">
            <p className="credits-main">
              Bu Proje <a href="https://t.me/El_bahram" target="_blank" rel="noopener noreferrer" className="telegram-link">@El_bahram</a> tarafından geliştirilmiştir.
            </p>
            <p className="credits-warning">
              Ücretsiz ve açık kaynaktır. Lütfen satan kişilerden ve projeyi çalıp kendi gibi gösterenlerden uzak durun.
            </p>
            <p className="credits-youtube">
              YouTube: <a href="https://www.youtube.com/@orucdemiros" target="_blank" rel="noopener noreferrer" className="youtube-link">@orucdemiros</a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
