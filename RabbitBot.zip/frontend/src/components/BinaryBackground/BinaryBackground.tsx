import React, { useEffect, useRef } from 'react';

export const BinaryBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Fullscreen 3D Mesh Grid
    const cols = 28;
    const rows = 20;
    const spacing = 120;

    let time = 0;

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      time += 0.012;

      ctx.lineWidth = 1;

      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const x = (c - cols / 2) * spacing;
          const y = (r - rows / 2) * spacing;
          const z = Math.sin(time + c * 0.3 + r * 0.2) * 35;

          // 3D Perspective calculation
          const scale = 600 / (600 + z + 150);
          const px = canvas.width / 2 + x * scale;
          const py = canvas.height / 2 + y * scale;

          // Right neighbor line
          if (c < cols - 1) {
            const nextX = (c + 1 - cols / 2) * spacing;
            const nextZ = Math.sin(time + (c + 1) * 0.3 + r * 0.2) * 35;
            const nextScale = 600 / (600 + nextZ + 150);
            const npx = canvas.width / 2 + nextX * nextScale;
            const npy = canvas.height / 2 + y * nextScale;

            ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
            ctx.beginPath();
            ctx.moveTo(px, py);
            ctx.lineTo(npx, npy);
            ctx.stroke();
          }

          // Bottom neighbor line
          if (r < rows - 1) {
            const nextY = (r + 1 - rows / 2) * spacing;
            const nextZ = Math.sin(time + c * 0.3 + (r + 1) * 0.2) * 35;
            const nextScale = 600 / (600 + nextZ + 150);
            const npx = canvas.width / 2 + x * nextScale;
            const npy = canvas.height / 2 + nextY * nextScale;

            ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
            ctx.beginPath();
            ctx.moveTo(px, py);
            ctx.lineTo(npx, npy);
            ctx.stroke();
          }

          // Node dot
          ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
          ctx.beginPath();
          ctx.arc(px, py, 1.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return <canvas ref={canvasRef} className="matrix-canvas" />;
};
