import { useState, useEffect } from 'react';
import axios from 'axios';
import './styles/global.css';
import { Login } from './components/Login/Login';
import { Dashboard } from './components/Dashboard/Dashboard';
import { BinaryBackground } from './components/BinaryBackground/BinaryBackground';
import { LanguageProvider } from './i18n/LanguageContext';
import { PrivacyProvider } from './context/PrivacyContext';
import { API_BASE_URL } from './config';

interface UserData {
  id: number;
  username: string;
  role: string;
  gateKey: string;
}

export default function App() {
  const [user, setUser] = useState<UserData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const restoreSession = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        setLoading(false);
        return;
      }

      try {
        const res = await axios.get(`${API_BASE_URL}/api/auth/me`, {
          headers: { Authorization: `Bearer ${token}` }
        });

        if (res.data.success && res.data.user) {
          setUser({
            id: res.data.user.id,
            username: res.data.user.username,
            role: res.data.user.role,
            gateKey: res.data.user.gate_key || res.data.user.gateKey
          });
        } else {
          localStorage.removeItem('token');
        }
      } catch (err) {
        localStorage.removeItem('token');
      } finally {
        setLoading(false);
      }
    };

    restoreSession();
  }, []);

  const handleLoginSuccess = (userData: UserData, token: string) => {
    localStorage.setItem('token', token);
    setUser(userData);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setUser(null);
  };

  if (loading && !user) {
    return null;
  }

  return (
    <LanguageProvider>
      <PrivacyProvider>
        {!user ? (
          <div className="app-wrapper">
            <BinaryBackground />
            <Login onLoginSuccess={handleLoginSuccess} />
          </div>
        ) : (
          <Dashboard user={user} onLogout={handleLogout} />
        )}
      </PrivacyProvider>
    </LanguageProvider>
  );
}
