import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { pool, generateGateKey } from '../db';

const router = Router();

const failedAttemptsMap = new Map<string, { count: number; lockUntil: number }>();

interface UserRow {
  id: number;
  username: string;
  password: string;
  role: string;
  gate_key: string;
}

router.post('/login', async (req: Request, res: Response): Promise<Response> => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ success: false, message: 'Kullanıcı adı ve şifre gereklidir.' });
  }

  const cleanUsername = String(username).trim();
  const cleanPassword = String(password);

  const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
  const trackerKey = `${clientIp}_${cleanUsername.toLowerCase()}`;
  const now = Date.now();

  const attemptInfo = failedAttemptsMap.get(trackerKey);
  if (attemptInfo && attemptInfo.count >= 5) {
    if (now < attemptInfo.lockUntil) {
      const remainingSeconds = Math.ceil((attemptInfo.lockUntil - now) / 1000);
      return res.status(429).json({
        success: false,
        message: `Çok fazla hatalı deneme! Lütfen ${remainingSeconds} saniye sonra tekrar deneyin.`
      });
    } else {
      failedAttemptsMap.delete(trackerKey);
    }
  }

  try {
    const result = await pool.query<UserRow>(
      'SELECT * FROM users WHERE LOWER(TRIM(username)) = LOWER(TRIM($1))',
      [cleanUsername]
    );
    
    if (result.rows.length === 0) {
      const currentCount = (attemptInfo?.count || 0) + 1;
      failedAttemptsMap.set(trackerKey, {
        count: currentCount,
        lockUntil: currentCount >= 5 ? Date.now() + 15 * 60 * 1000 : 0
      });
      return res.status(401).json({
        success: false,
        message: currentCount >= 5
          ? '5 kez hatalı giriş yapıldı. Hesabınız 15 dakika kilitlendi.'
          : `Geçersiz kullanıcı adı veya şifre. (Kalan hak: ${5 - currentCount})`
      });
    }

    const user = result.rows[0];
    const isMatch = await bcrypt.compare(cleanPassword, user.password) || await bcrypt.compare(cleanPassword.trim(), user.password);

    if (!isMatch) {
      const currentCount = (attemptInfo?.count || 0) + 1;
      failedAttemptsMap.set(trackerKey, {
        count: currentCount,
        lockUntil: currentCount >= 5 ? Date.now() + 15 * 60 * 1000 : 0
      });
      return res.status(401).json({
        success: false,
        message: currentCount >= 5
          ? '5 kez hatalı giriş yapıldı. Hesabınız 15 dakika kilitlendi.'
          : `Geçersiz kullanıcı adı veya şifre. (Kalan hak: ${5 - currentCount})`
      });
    }

    failedAttemptsMap.delete(trackerKey);

    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role, gate_key: user.gate_key },
      process.env.JWT_SECRET || 'fallback_secret',
      { expiresIn: '24h' }
    );

    return res.json({
      success: true,
      message: 'Giriş başarılı!',
      token,
      user: {
        id: user.id,
        username: user.username,
        role: user.role,
        gateKey: user.gate_key
      }
    });
  } catch (error) {
    console.error('Login Error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});
router.get('/me', async (req: Request, res: Response): Promise<Response> => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, message: 'Yetkisiz erişim.' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback_secret') as any;
    
    const result = await pool.query<UserRow>('SELECT * FROM users WHERE id = $1', [decoded.id]);
    if (result.rows.length === 0) {
      return res.status(401).json({ success: false, message: 'Kullanıcı bulunamadı.' });
    }

    const user = result.rows[0];

    return res.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        role: user.role,
        gateKey: user.gate_key
      }
    });
  } catch (err) {
    return res.status(401).json({ success: false, message: 'Geçersiz veya süresi dolmuş token.' });
  }
});

import { authenticateToken, AuthRequest } from '../middleware/auth';

router.post('/change-password', authenticateToken, async (req: AuthRequest, res: Response): Promise<Response> => {
  const userId = req.user?.id;
  const { currentPassword, newUsername, newPassword } = req.body;

  if (!userId || !currentPassword) {
    return res.status(400).json({ success: false, message: 'Mevcut şifreniz gereklidir.' });
  }

  const cleanCurrentPass = String(currentPassword);
  const cleanNewUsername = newUsername ? String(newUsername).trim() : '';
  const cleanNewPass = newPassword ? String(newPassword).trim() : '';

  if (!cleanNewUsername && !cleanNewPass) {
    return res.status(400).json({ success: false, message: 'En az bir alanı (yeni kullanıcı adı veya yeni şifre) doldurmalısınız.' });
  }

  try {
    const userRes = await pool.query<UserRow>('SELECT * FROM users WHERE id = $1', [userId]);
    if (userRes.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Kullanıcı bulunamadı.' });
    }

    const user = userRes.rows[0];
    const isMatch = await bcrypt.compare(cleanCurrentPass, user.password) || await bcrypt.compare(cleanCurrentPass.trim(), user.password);

    if (!isMatch) {
      return res.status(400).json({ success: false, message: 'Mevcut şifreniz hatalı.' });
    }

    let updatedUsername = user.username;
    if (cleanNewUsername !== '' && cleanNewUsername.toLowerCase() !== user.username.toLowerCase()) {
      const existingUser = await pool.query(
        'SELECT id FROM users WHERE LOWER(TRIM(username)) = LOWER(TRIM($1)) AND id != $2',
        [cleanNewUsername, userId]
      );
      if (existingUser.rows.length > 0) {
        return res.status(400).json({ success: false, message: 'Bu kullanıcı adı zaten başka biri tarafından kullanılıyor.' });
      }
      await pool.query('UPDATE users SET username = $1 WHERE id = $2', [cleanNewUsername, userId]);
      updatedUsername = cleanNewUsername;
    }

    if (cleanNewPass !== '') {
      const hashedNew = await bcrypt.hash(cleanNewPass, 10);
      await pool.query('UPDATE users SET password = $1 WHERE id = $2', [hashedNew, userId]);
    }

    failedAttemptsMap.clear();

    return res.json({ 
      success: true, 
      message: 'Hesap bilgileri başarıyla güncellendi.',
      username: updatedUsername
    });
  } catch (error) {
    console.error('Change password error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

export default router;