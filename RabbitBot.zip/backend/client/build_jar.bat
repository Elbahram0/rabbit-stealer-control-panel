@echo off
echo ==============================================
echo [Rabbit Bot] Client JAR Builder
echo ==============================================

echo [*] Calısan Java süreçleri sonlandırılıyor...
taskkill /F /IM javaw.exe /IM java.exe 2>nul

echo [*] Eski derleme dosyaları temizleniyor...
del /q *.class 2>nul
del /q Client.jar 2>nul

echo [*] ce.exe ve payload.dll kontrol ediliyor...
if not exist "ce.exe" (
    if exist "EverestCPP\build\ce.exe" (
        copy /Y "EverestCPP\build\ce.exe" "ce.exe" >nul
        echo [+] ce.exe EverestCPP\build altından kopyalandı.
    )
)

if not exist "payload.dll" (
    if exist "EverestCPP\build\payload.dll" (
        copy /Y "EverestCPP\build\payload.dll" "payload.dll" >nul
        echo [+] payload.dll EverestCPP\build altından kopyalandı.
    )
)

if not exist "ce.exe" (
    echo [!] UYARI: ce.exe bulunamadı!
) else (
    echo [✓] ce.exe mevcut.
)

if not exist "payload.dll" (
    echo [!] UYARI: payload.dll bulunamadı!
) else (
    echo [✓] payload.dll mevcut.
)

echo [*] Tüm Java kaynak dosyaları derleniyor...
javac -encoding UTF-8 *.java

if %errorlevel% neq 0 (
    echo [!] Derleme hatası olustu! Lütfen Java kodlarını kontrol edin.
    pause
    exit /b %errorlevel%
)

set EXTRA_FILES=
if exist "ce.exe" set EXTRA_FILES=%EXTRA_FILES% ce.exe
if exist "payload.dll" set EXTRA_FILES=%EXTRA_FILES% payload.dll

echo [*] Client.jar paketi olusturuluyor...
jar cvfe Client.jar Client *.class%EXTRA_FILES%

if %errorlevel% neq 0 (
    echo [!] JAR paketleme hatası olustu!
    pause
    exit /b %errorlevel%
)

echo [*] Derleme kalıntıları (.class) temizleniyor...
del /q *.class 2>nul

echo.
echo [+] Basarılı! Client.jar dosyası kusursuz şekilde olusturuldu.
echo [i] İçindeki exe/dll kaynakları doğrulandı.
echo [i] Çalıştırmak için: java -jar Client.jar
pause
